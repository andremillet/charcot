#!/usr/bin/env python3
"""
Sistema de Tipos para a Linguagem Charcot

Este módulo implementa o sistema de tipos para a linguagem Charcot,
responsável por verificar e inferir tipos em programas Charcot.
"""

from typing import Dict, List, Optional, Set, Union, Any, Tuple
from dataclasses import dataclass
from enum import Enum, auto

from lexer import Token, TokenType
from parser import Node, NodeType, Expression, Statement, Binary, Unary, Literal, Grouping
from parser import Variable, Assign, Call, Get, Set, Logical, Block, ExpressionStmt
from parser import Function, If, Return, Let, While, For, Struct, Import, Procedure, Match


class TypeKind(Enum):
    """Tipos de dados suportados pela linguagem Charcot."""
    PRIMITIVE = auto()    # Tipos primitivos (int, float, bool, str)
    STRUCT = auto()       # Tipos de estrutura definidos pelo usuário
    FUNCTION = auto()     # Tipos de função
    OPTION = auto()       # Tipo Option<T>
    RESULT = auto()       # Tipo Result<T, E>
    LIST = auto()         # Tipo list<T>
    DICT = auto()         # Tipo dict<K, V>
    SET = auto()          # Tipo set<T>
    TUPLE = auto()        # Tipo tuple<T1, T2, ...>
    
    # Tipos específicos para medicina
    PATIENT = auto()      # Tipo Patient
    MEDICATION = auto()   # Tipo Medication
    DOSE = auto()         # Tipo Dose
    DATE = auto()         # Tipo Date
    TIME = auto()         # Tipo Time
    DATETIME = auto()     # Tipo DateTime
    DURATION = auto()     # Tipo Duration
    VITAL_SIGNS = auto()  # Tipo VitalSigns
    
    # Tipo especial para representar qualquer tipo
    ANY = auto()          # Tipo Any (usado para inferência)
    
    # Tipo para representar ausência de valor
    NONE = auto()         # Tipo None
    
    # Tipo para representar erro
    ERROR = auto()        # Tipo Error (usado para reportar erros)


@dataclass
class Type:
    """Classe base para representar tipos na linguagem Charcot."""
    kind: TypeKind
    
    def __eq__(self, other):
        if not isinstance(other, Type):
            return False
        return self.kind == other.kind
    
    def __str__(self):
        return f"Type({self.kind})"


@dataclass
class PrimitiveType(Type):
    """Representa um tipo primitivo."""
    name: str
    
    def __init__(self, name: str):
        super().__init__(TypeKind.PRIMITIVE)
        self.name = name
    
    def __eq__(self, other):
        if not isinstance(other, PrimitiveType):
            return False
        return self.name == other.name
    
    def __str__(self):
        return self.name


@dataclass
class StructType(Type):
    """Representa um tipo de estrutura definido pelo usuário."""
    name: str
    fields: Dict[str, 'Type']
    methods: Dict[str, 'FunctionType']
    
    def __init__(self, name: str, fields: Dict[str, 'Type'], methods: Dict[str, 'FunctionType']):
        super().__init__(TypeKind.STRUCT)
        self.name = name
        self.fields = fields
        self.methods = methods
    
    def __eq__(self, other):
        if not isinstance(other, StructType):
            return False
        return self.name == other.name
    
    def __str__(self):
        return self.name


@dataclass
class FunctionType(Type):
    """Representa um tipo de função."""
    param_types: List[Type]
    return_type: Type
    
    def __init__(self, param_types: List[Type], return_type: Type):
        super().__init__(TypeKind.FUNCTION)
        self.param_types = param_types
        self.return_type = return_type
    
    def __eq__(self, other):
        if not isinstance(other, FunctionType):
            return False
        if len(self.param_types) != len(other.param_types):
            return False
        for i in range(len(self.param_types)):
            if self.param_types[i] != other.param_types[i]:
                return False
        return self.return_type == other.return_type
    
    def __str__(self):
        params = ", ".join(str(t) for t in self.param_types)
        return f"fn({params}) -> {self.return_type}"


@dataclass
class GenericType(Type):
    """Representa um tipo genérico."""
    base_type: Type
    type_args: List[Type]
    
    def __init__(self, kind: TypeKind, base_type: Type, type_args: List[Type]):
        super().__init__(kind)
        self.base_type = base_type
        self.type_args = type_args
    
    def __eq__(self, other):
        if not isinstance(other, GenericType):
            return False
        if self.kind != other.kind:
            return False
        if self.base_type != other.base_type:
            return False
        if len(self.type_args) != len(other.type_args):
            return False
        for i in range(len(self.type_args)):
            if self.type_args[i] != other.type_args[i]:
                return False
        return True
    
    def __str__(self):
        args = ", ".join(str(t) for t in self.type_args)
        return f"{self.base_type}<{args}>"


@dataclass
class OptionType(GenericType):
    """Representa um tipo Option<T>."""
    def __init__(self, value_type: Type):
        super().__init__(TypeKind.OPTION, PrimitiveType("Option"), [value_type])
    
    def __str__(self):
        return f"Option<{self.type_args[0]}>"


@dataclass
class ResultType(GenericType):
    """Representa um tipo Result<T, E>."""
    def __init__(self, value_type: Type, error_type: Type):
        super().__init__(TypeKind.RESULT, PrimitiveType("Result"), [value_type, error_type])
    
    def __str__(self):
        return f"Result<{self.type_args[0]}, {self.type_args[1]}>"


@dataclass
class ListType(GenericType):
    """Representa um tipo list<T>."""
    def __init__(self, element_type: Type):
        super().__init__(TypeKind.LIST, PrimitiveType("list"), [element_type])
    
    def __str__(self):
        return f"list[{self.type_args[0]}]"


@dataclass
class DictType(GenericType):
    """Representa um tipo dict<K, V>."""
    def __init__(self, key_type: Type, value_type: Type):
        super().__init__(TypeKind.DICT, PrimitiveType("dict"), [key_type, value_type])
    
    def __str__(self):
        return f"dict[{self.type_args[0]}, {self.type_args[1]}]"


@dataclass
class SetType(GenericType):
    """Representa um tipo set<T>."""
    def __init__(self, element_type: Type):
        super().__init__(TypeKind.SET, PrimitiveType("set"), [element_type])
    
    def __str__(self):
        return f"set[{self.type_args[0]}]"


@dataclass
class TupleType(Type):
    """Representa um tipo tuple<T1, T2, ...>."""
    element_types: List[Type]
    
    def __init__(self, element_types: List[Type]):
        super().__init__(TypeKind.TUPLE)
        self.element_types = element_types
    
    def __eq__(self, other):
        if not isinstance(other, TupleType):
            return False
        if len(self.element_types) != len(other.element_types):
            return False
        for i in range(len(self.element_types)):
            if self.element_types[i] != other.element_types[i]:
                return False
        return True
    
    def __str__(self):
        elements = ", ".join(str(t) for t in self.element_types)
        return f"tuple[{elements}]"


@dataclass
class MedicalType(Type):
    """Classe base para tipos específicos para medicina."""
    name: str
    
    def __init__(self, kind: TypeKind, name: str):
        super().__init__(kind)
        self.name = name
    
    def __eq__(self, other):
        if not isinstance(other, MedicalType):
            return False
        return self.kind == other.kind and self.name == other.name
    
    def __str__(self):
        return self.name


@dataclass
class PatientType(MedicalType):
    """Representa o tipo Patient."""
    def __init__(self):
        super().__init__(TypeKind.PATIENT, "Patient")


@dataclass
class MedicationType(MedicalType):
    """Representa o tipo Medication."""
    def __init__(self):
        super().__init__(TypeKind.MEDICATION, "Medication")


@dataclass
class DoseType(MedicalType):
    """Representa o tipo Dose."""
    def __init__(self):
        super().__init__(TypeKind.DOSE, "Dose")


@dataclass
class DateType(MedicalType):
    """Representa o tipo Date."""
    def __init__(self):
        super().__init__(TypeKind.DATE, "Date")


@dataclass
class TimeType(MedicalType):
    """Representa o tipo Time."""
    def __init__(self):
        super().__init__(TypeKind.TIME, "Time")


@dataclass
class DateTimeType(MedicalType):
    """Representa o tipo DateTime."""
    def __init__(self):
        super().__init__(TypeKind.DATETIME, "DateTime")


@dataclass
class DurationType(MedicalType):
    """Representa o tipo Duration."""
    def __init__(self):
        super().__init__(TypeKind.DURATION, "Duration")


@dataclass
class VitalSignsType(MedicalType):
    """Representa o tipo VitalSigns."""
    def __init__(self):
        super().__init__(TypeKind.VITAL_SIGNS, "VitalSigns")


@dataclass
class AnyType(Type):
    """Representa o tipo Any."""
    def __init__(self):
        super().__init__(TypeKind.ANY)
    
    def __eq__(self, other):
        # Any é compatível com qualquer tipo
        return True
    
    def __str__(self):
        return "Any"


@dataclass
class NoneType(Type):
    """Representa o tipo None."""
    def __init__(self):
        super().__init__(TypeKind.NONE)
    
    def __str__(self):
        return "None"


@dataclass
class ErrorType(Type):
    """Representa um tipo de erro."""
    message: str
    
    def __init__(self, message: str):
        super().__init__(TypeKind.ERROR)
        self.message = message
    
    def __str__(self):
        return f"Error: {self.message}"


class TypeChecker:
    """
    Verificador de tipos para a linguagem Charcot.
    
    Responsável por verificar e inferir tipos em programas Charcot.
    """
    
    def __init__(self):
        # Tipos primitivos predefinidos
        self.int_type = PrimitiveType("int")
        self.float_type = PrimitiveType("float")
        self.bool_type = PrimitiveType("bool")
        self.str_type = PrimitiveType("str")
        self.none_type = NoneType()
        
        # Tipos específicos para medicina
        self.patient_type = PatientType()
        self.medication_type = MedicationType()
        self.dose_type = DoseType()
        self.date_type = DateType()
        self.time_type = TimeType()
        self.datetime_type = DateTimeType()
        self.duration_type = DurationType()
        self.vital_signs_type = VitalSignsType()
        
        # Ambiente de tipos
        self.globals: Dict[str, Type] = {}
        self.locals: List[Dict[str, Type]] = [{}]
        
        # Tipos definidos pelo usuário
        self.user_types: Dict[str, Type] = {}
        
        # Erros de tipo
        self.errors: List[str] = []
        
        # Inicializar ambiente global com tipos primitivos
        self._init_globals()
    
    def _init_globals(self):
        """Inicializa o ambiente global com tipos primitivos."""
        self.globals["int"] = self.int_type
        self.globals["float"] = self.float_type
        self.globals["bool"] = self.bool_type
        self.globals["str"] = self.str_type
        self.globals["None"] = self.none_type
        
        # Tipos específicos para medicina
        self.globals["Patient"] = self.patient_type
        self.globals["Medication"] = self.medication_type
        self.globals["Dose"] = self.dose_type
        self.globals["Date"] = self.date_type
        self.globals["Time"] = self.time_type
        self.globals["DateTime"] = self.datetime_type
        self.globals["Duration"] = self.duration_type
        self.globals["VitalSigns"] = self.vital_signs_type
    
    def check(self, statements: List[Statement]) -> List[str]:
        """
        Verifica os tipos em uma lista de declarações.
        
        Args:
            statements (List[Statement]): A lista de declarações a ser verificada.
            
        Returns:
            List[str]: A lista de erros de tipo encontrados.
        """
        self.errors = []
        
        # Primeira passagem: coletar declarações de tipos
        for stmt in statements:
            if isinstance(stmt, Struct):
                self._declare_struct(stmt)
        
        # Segunda passagem: verificar tipos
        for stmt in statements:
            self._check_statement(stmt)
        
        return self.errors
    
    def _declare_struct(self, stmt: Struct):
        """
        Declara um tipo de estrutura.
        
        Args:
            stmt (Struct): A declaração de estrutura.
        """
        name = stmt.name.lexeme
        
        if name in self.user_types:
            self._error(stmt.name, f"Tipo '{name}' já declarado.")
            return
        
        # Criar tipo de estrutura vazio inicialmente
        struct_type = StructType(name, {}, {})
        self.user_types[name] = struct_type
        self.globals[name] = struct_type
        
        # Preencher campos
        fields = {}
        for i, field in enumerate(stmt.fields):
            field_name = field.lexeme
            field_type_expr = stmt.field_types[i]
            field_type = self._resolve_type_expression(field_type_expr)
            fields[field_name] = field_type
        
        # Preencher métodos
        methods = {}
        for method in stmt.methods:
            method_name = method.name.lexeme
            param_types = []
            for i, _ in enumerate(method.params):
                if method.param_types[i] is not None:
                    param_type = self._resolve_type_expression(method.param_types[i])
                else:
                    param_type = AnyType()
                param_types.append(param_type)
            
            return_type = self.none_type
            if method.return_type is not None:
                return_type = self._resolve_type_expression(method.return_type)
            
            methods[method_name] = FunctionType(param_types, return_type)
        
        # Atualizar tipo de estrutura
        struct_type.fields = fields
        struct_type.methods = methods
    
    def _check_statement(self, stmt: Statement):
        """
        Verifica os tipos em uma declaração.
        
        Args:
            stmt (Statement): A declaração a ser verificada.
        """
        if isinstance(stmt, ExpressionStmt):
            self._check_expression(stmt.expression)
        elif isinstance(stmt, Let):
            self._check_let(stmt)
        elif isinstance(stmt, Block):
            self._begin_scope()
            for s in stmt.statements:
                self._check_statement(s)
            self._end_scope()
        elif isinstance(stmt, If):
            self._check_if(stmt)
        elif isinstance(stmt, While):
            self._check_while(stmt)
        elif isinstance(stmt, For):
            self._check_for(stmt)
        elif isinstance(stmt, Function):
            self._check_function(stmt)
        elif isinstance(stmt, Return):
            self._check_return(stmt)
        elif isinstance(stmt, Struct):
            # Já processado na primeira passagem
            pass
        elif isinstance(stmt, Import):
            # Ignorar por enquanto
            pass
        elif isinstance(stmt, Procedure):
            self._check_procedure(stmt)
        elif isinstance(stmt, Match):
            self._check_match(stmt)
        else:
            self._error_node(stmt, f"Tipo de declaração não suportado: {type(stmt).__name__}")
    
    def _check_let(self, stmt: Let):
        """
        Verifica os tipos em uma declaração de variável.
        
        Args:
            stmt (Let): A declaração de variável a ser verificada.
        """
        var_type = None
        
        # Verificar tipo explícito
        if stmt.type_annotation is not None:
            var_type = self._resolve_type_expression(stmt.type_annotation)
        
        # Verificar inicializador
        if stmt.initializer is not None:
            init_type = self._check_expression(stmt.initializer)
       
(Content truncated due to size limit. Use line ranges to read in chunks)