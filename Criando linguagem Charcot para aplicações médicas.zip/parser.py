#!/usr/bin/env python3
"""
Analisador Sintático para a Linguagem Charcot

Este módulo implementa o analisador sintático (parser) para a linguagem Charcot,
responsável por transformar a sequência de tokens em uma árvore sintática abstrata (AST).
"""

from typing import List, Optional, Any, Dict, Union, Callable
from dataclasses import dataclass
from enum import Enum, auto

from lexer import Token, TokenType


class NodeType(Enum):
    """Tipos de nós na árvore sintática abstrata."""
    # Expressões
    BINARY = auto()        # Expressão binária (a + b)
    GROUPING = auto()      # Expressão agrupada ((a + b))
    LITERAL = auto()       # Literal (123, "texto", true)
    UNARY = auto()         # Expressão unária (-a, !b)
    VARIABLE = auto()      # Referência a variável (nome)
    ASSIGN = auto()        # Atribuição (a = b)
    CALL = auto()          # Chamada de função (f(x))
    GET = auto()           # Acesso a propriedade (obj.prop)
    SET = auto()           # Definição de propriedade (obj.prop = val)
    LOGICAL = auto()       # Operação lógica (a and b, a or b)
    
    # Declarações
    BLOCK = auto()         # Bloco de código { ... }
    EXPRESSION = auto()    # Declaração de expressão
    FUNCTION = auto()      # Declaração de função
    IF = auto()            # Declaração if
    RETURN = auto()        # Declaração return
    LET = auto()           # Declaração de variável
    WHILE = auto()         # Declaração while
    FOR = auto()           # Declaração for
    STRUCT = auto()        # Declaração de struct
    IMPORT = auto()        # Declaração import
    PROCEDURE = auto()     # Declaração de procedimento médico
    MATCH = auto()         # Declaração match
    
    # Específicos para medicina
    PATIENT = auto()       # Declaração de paciente
    MEDICATION = auto()    # Declaração de medicamento
    PRESCRIPTION = auto()  # Declaração de prescrição
    WORKFLOW = auto()      # Declaração de workflow


@dataclass
class Node:
    """Nó base para a árvore sintática abstrata."""
    type: NodeType
    
    def accept(self, visitor):
        """
        Implementa o padrão Visitor para percorrer a AST.
        
        Args:
            visitor: O visitante que processará o nó.
            
        Returns:
            O resultado do processamento pelo visitante.
        """
        method_name = f"visit_{self.type.name.lower()}_node"
        method = getattr(visitor, method_name, visitor.visit_node)
        return method(self)


@dataclass
class Expression(Node):
    """Classe base para nós de expressão."""
    pass


@dataclass
class Binary(Expression):
    """Expressão binária (a + b)."""
    left: Expression
    operator: Token
    right: Expression
    
    def __init__(self, left: Expression, operator: Token, right: Expression):
        super().__init__(NodeType.BINARY)
        self.left = left
        self.operator = operator
        self.right = right


@dataclass
class Grouping(Expression):
    """Expressão agrupada ((a + b))."""
    expression: Expression
    
    def __init__(self, expression: Expression):
        super().__init__(NodeType.GROUPING)
        self.expression = expression


@dataclass
class Literal(Expression):
    """Literal (123, "texto", true)."""
    value: Any
    
    def __init__(self, value: Any):
        super().__init__(NodeType.LITERAL)
        self.value = value


@dataclass
class Unary(Expression):
    """Expressão unária (-a, !b)."""
    operator: Token
    right: Expression
    
    def __init__(self, operator: Token, right: Expression):
        super().__init__(NodeType.UNARY)
        self.operator = operator
        self.right = right


@dataclass
class Variable(Expression):
    """Referência a variável (nome)."""
    name: Token
    
    def __init__(self, name: Token):
        super().__init__(NodeType.VARIABLE)
        self.name = name


@dataclass
class Assign(Expression):
    """Atribuição (a = b)."""
    name: Token
    value: Expression
    
    def __init__(self, name: Token, value: Expression):
        super().__init__(NodeType.ASSIGN)
        self.name = name
        self.value = value


@dataclass
class Call(Expression):
    """Chamada de função (f(x))."""
    callee: Expression
    paren: Token
    arguments: List[Expression]
    
    def __init__(self, callee: Expression, paren: Token, arguments: List[Expression]):
        super().__init__(NodeType.CALL)
        self.callee = callee
        self.paren = paren
        self.arguments = arguments


@dataclass
class Get(Expression):
    """Acesso a propriedade (obj.prop)."""
    object: Expression
    name: Token
    
    def __init__(self, object: Expression, name: Token):
        super().__init__(NodeType.GET)
        self.object = object
        self.name = name


@dataclass
class Set(Expression):
    """Definição de propriedade (obj.prop = val)."""
    object: Expression
    name: Token
    value: Expression
    
    def __init__(self, object: Expression, name: Token, value: Expression):
        super().__init__(NodeType.SET)
        self.object = object
        self.name = name
        self.value = value


@dataclass
class Logical(Expression):
    """Operação lógica (a and b, a or b)."""
    left: Expression
    operator: Token
    right: Expression
    
    def __init__(self, left: Expression, operator: Token, right: Expression):
        super().__init__(NodeType.LOGICAL)
        self.left = left
        self.operator = operator
        self.right = right


@dataclass
class Statement(Node):
    """Classe base para nós de declaração."""
    pass


@dataclass
class Block(Statement):
    """Bloco de código { ... }."""
    statements: List[Statement]
    
    def __init__(self, statements: List[Statement]):
        super().__init__(NodeType.BLOCK)
        self.statements = statements


@dataclass
class ExpressionStmt(Statement):
    """Declaração de expressão."""
    expression: Expression
    
    def __init__(self, expression: Expression):
        super().__init__(NodeType.EXPRESSION)
        self.expression = expression


@dataclass
class Function(Statement):
    """Declaração de função."""
    name: Token
    params: List[Token]
    param_types: List[Optional[Expression]]
    return_type: Optional[Expression]
    body: List[Statement]
    
    def __init__(self, name: Token, params: List[Token], param_types: List[Optional[Expression]],
                 return_type: Optional[Expression], body: List[Statement]):
        super().__init__(NodeType.FUNCTION)
        self.name = name
        self.params = params
        self.param_types = param_types
        self.return_type = return_type
        self.body = body


@dataclass
class If(Statement):
    """Declaração if."""
    condition: Expression
    then_branch: Statement
    else_branch: Optional[Statement]
    
    def __init__(self, condition: Expression, then_branch: Statement, else_branch: Optional[Statement]):
        super().__init__(NodeType.IF)
        self.condition = condition
        self.then_branch = then_branch
        self.else_branch = else_branch


@dataclass
class Return(Statement):
    """Declaração return."""
    keyword: Token
    value: Optional[Expression]
    
    def __init__(self, keyword: Token, value: Optional[Expression]):
        super().__init__(NodeType.RETURN)
        self.keyword = keyword
        self.value = value


@dataclass
class Let(Statement):
    """Declaração de variável."""
    name: Token
    type_annotation: Optional[Expression]
    initializer: Optional[Expression]
    is_mutable: bool
    
    def __init__(self, name: Token, type_annotation: Optional[Expression],
                 initializer: Optional[Expression], is_mutable: bool):
        super().__init__(NodeType.LET)
        self.name = name
        self.type_annotation = type_annotation
        self.initializer = initializer
        self.is_mutable = is_mutable


@dataclass
class While(Statement):
    """Declaração while."""
    condition: Expression
    body: Statement
    
    def __init__(self, condition: Expression, body: Statement):
        super().__init__(NodeType.WHILE)
        self.condition = condition
        self.body = body


@dataclass
class For(Statement):
    """Declaração for."""
    variable: Token
    iterable: Expression
    body: Statement
    
    def __init__(self, variable: Token, iterable: Expression, body: Statement):
        super().__init__(NodeType.FOR)
        self.variable = variable
        self.iterable = iterable
        self.body = body


@dataclass
class Struct(Statement):
    """Declaração de struct."""
    name: Token
    fields: List[Token]
    field_types: List[Expression]
    methods: List[Function]
    
    def __init__(self, name: Token, fields: List[Token], field_types: List[Expression], methods: List[Function]):
        super().__init__(NodeType.STRUCT)
        self.name = name
        self.fields = fields
        self.field_types = field_types
        self.methods = methods


@dataclass
class Import(Statement):
    """Declaração import."""
    module: Token
    alias: Optional[Token]
    
    def __init__(self, module: Token, alias: Optional[Token]):
        super().__init__(NodeType.IMPORT)
        self.module = module
        self.alias = alias


@dataclass
class Procedure(Statement):
    """Declaração de procedimento médico."""
    name: Token
    params: List[Token]
    param_types: List[Optional[Expression]]
    body: List[Statement]
    verifications: List[Expression]
    
    def __init__(self, name: Token, params: List[Token], param_types: List[Optional[Expression]],
                 body: List[Statement], verifications: List[Expression]):
        super().__init__(NodeType.PROCEDURE)
        self.name = name
        self.params = params
        self.param_types = param_types
        self.body = body
        self.verifications = verifications


@dataclass
class Match(Statement):
    """Declaração match."""
    value: Expression
    cases: List[tuple[Expression, Statement]]
    
    def __init__(self, value: Expression, cases: List[tuple[Expression, Statement]]):
        super().__init__(NodeType.MATCH)
        self.value = value
        self.cases = cases


class ParseError(Exception):
    """Exceção lançada quando ocorre um erro de análise sintática."""
    pass


class Parser:
    """
    Analisador sintático para a linguagem Charcot.
    
    Converte uma sequência de tokens em uma árvore sintática abstrata (AST).
    """
    
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.current = 0
        self.errors: List[str] = []
    
    def parse(self) -> List[Statement]:
        """
        Analisa a sequência de tokens e retorna a AST.
        
        Returns:
            List[Statement]: A lista de declarações que formam o programa.
        """
        statements = []
        
        while not self.is_at_end():
            try:
                stmt = self.declaration()
                if stmt:
                    statements.append(stmt)
            except ParseError as e:
                self.synchronize()
        
        return statements
    
    def declaration(self) -> Optional[Statement]:
        """
        Analisa uma declaração.
        
        Returns:
            Optional[Statement]: A declaração analisada ou None em caso de erro.
        """
        try:
            if self.match(TokenType.FN):
                return self.function_declaration("function")
            if self.match(TokenType.LET):
                return self.var_declaration()
            if self.match(TokenType.STRUCT):
                return self.struct_declaration()
            if self.match(TokenType.IMPORT):
                return self.import_declaration()
            if self.match(TokenType.PROCEDURE):
                return self.procedure_declaration()
            
            return self.statement()
        except ParseError:
            self.synchronize()
            return None
    
    def function_declaration(self, kind: str) -> Function:
        """
        Analisa uma declaração de função.
        
        Args:
            kind (str): O tipo de função ("function", "method").
            
        Returns:
            Function: A declaração de função analisada.
        """
        name = self.consume(TokenType.IDENTIFIER, f"Esperado nome de {kind}.")
        
        self.consume(TokenType.LEFT_PAREN, f"Esperado '(' após o nome de {kind}.")
        
        parameters = []
        param_types = []
        
        if not self.check(TokenType.RIGHT_PAREN):
            while True:
                if len(parameters) >= 255:
                    self.error(self.peek(), "Não pode ter mais de 255 parâmetros.")
                
                param_name = self.consume(TokenType.IDENTIFIER, "Esperado nome de parâmetro.")
                
                # Verificar anotação de tipo
                param_type = None
                if self.match(TokenType.COLON):
                    param_type = self.type_expression()
                
                parameters.append(param_name)
                param_types.append(param_type)
                
                if not self.match(TokenType.COMMA):
                    break
        
        self.consume(TokenType.RIGHT_PAREN, "Esperado ')' após parâmetros.")
        
        # Verificar tipo de retorno
        return_type = None
        if self.match(TokenType.ARROW):
            return_type = self.type_expression()
        
        # Corpo da função
        self.consume(TokenType.COLON, f"Esperado ':' antes do corpo de {kind}.")
        self.consume(TokenType.NEWLINE, f"Esperado nova linha após ':' em {kind}.")
        self.consume(TokenType.INDENT, f"Esperado indentação no corpo de {kind}.")
        
        body = []
        while not self.check(TokenType.DEDENT) and not self.is_at_end():
            body.append(self.declaration())
        
        self.consume(TokenType.DEDENT, f"Esperado dedentação após o corpo de {kind}.")
        
        return Function(name, parameters, param_types, return_type, body)
    
    def var_declaration(self) -> Let:
        """
        Analisa uma declaração de variável.
        
        Returns:
            Let: A declaração de variável analisada.
        """
        is_mutable = False
        if self.match(TokenType.MUT):
            is_mutable = True
        
        name = self.consume(TokenType.IDENTIFIER, "Esperado nome de variável.")
        
        # Verificar anotação de tipo
        type_annotation = None
        if self.match(TokenType.COLON):
            type_annotation = self.type_expression()
        
        # Verificar inicializador
        initializer = None
        if self.match(TokenType.EQUAL):
            initializer = self.expression()
        
        self.consume_end_of_statement("Esperado fim de declaração de variável.")
        
        return Let(name, type_annotation, initializer, is_mutable)
    
    def struct_declaration(self) -> Struct:
        """
        Analisa uma declaração de struct.
        
        Returns:
            Struct: A declaração de struct analisada.
        """
        name = self.consume(TokenType.IDENTIFIER, "Esperado nome de struct.")
        
        self.consume(TokenType.COLON, "Esperado ':' após nome de struct.")
        self.consume(TokenType.NEWLINE, "Esperado nova linha após ':'.")
        self.consume(TokenType.INDENT, "Esperado indentação no corpo de struct.")
        
        fields = []
        field_types = []
        methods = []
        
        while not self.check(TokenType.DEDENT) and not self.is_at_end():
            if self.match(TokenType.FN):
                methods.append(self.function_declaration("method"))
            else:
                field_name = self.consume(TokenType.IDENTIFIER, "Esperado nome de campo ou método.")
                self.consume(TokenType.COLON, "Esperado ':' após nome de campo.")
                field_type = self.type_expression()
                
                fields
(Content truncated due to size limit. Use line ranges to read in chunks)