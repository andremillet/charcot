# Linguagem de Programação Charcot - Guia do Usuário

## Introdução

A linguagem Charcot é uma linguagem de programação projetada especificamente para aplicações médicas. Ela combina a sintaxe intuitiva do Python com a segurança e desempenho do Rust, além de incorporar nativamente conceitos médicos e padrões como FHIR (Fast Healthcare Interoperability Resources).

Este guia do usuário fornece uma visão abrangente da linguagem Charcot, incluindo sua sintaxe, recursos, exemplos e melhores práticas para desenvolvimento de aplicações médicas.

## Índice

1. [Visão Geral](#visão-geral)
2. [Instalação](#instalação)
3. [Sintaxe Básica](#sintaxe-básica)
4. [Tipos de Dados](#tipos-de-dados)
5. [Estruturas de Controle](#estruturas-de-controle)
6. [Funções](#funções)
7. [Módulos e Pacotes](#módulos-e-pacotes)
8. [Tipos Específicos para Medicina](#tipos-específicos-para-medicina)
9. [Workflows Hospitalares](#workflows-hospitalares)
10. [Sistema de Prescrição](#sistema-de-prescrição)
11. [Integração FHIR](#integração-fhir)
12. [Segurança e Privacidade](#segurança-e-privacidade)
13. [Ambiente REPL](#ambiente-repl)
14. [Exemplos](#exemplos)
15. [Melhores Práticas](#melhores-práticas)
16. [Referência da API](#referência-da-api)
17. [Solução de Problemas](#solução-de-problemas)
18. [Contribuindo](#contribuindo)

## Visão Geral

A linguagem Charcot foi projetada para atender às necessidades específicas de aplicações médicas, oferecendo recursos que facilitam o desenvolvimento de software seguro, eficiente e interoperável para o setor de saúde.

### Características Principais

- **Sintaxe Simples e Intuitiva**: Inspirada em Python, fácil de aprender e usar.
- **Segurança de Tipos**: Sistema de tipos estático que previne erros comuns.
- **Gerenciamento de Memória Seguro**: Inspirado em Rust, evita vazamentos de memória e acesso inválido.
- **Recursos Específicos para Medicina**: Tipos de dados e funções específicas para o domínio médico.
- **Integração FHIR**: Suporte nativo ao padrão FHIR para interoperabilidade.
- **Workflows Hospitalares**: Funções para gerenciar processos hospitalares e ambulatoriais.
- **Sistema de Prescrição**: Verificações de segurança automáticas para prescrições médicas.
- **Segurança e Privacidade**: Recursos avançados para proteção de dados sensíveis.

### Por que Charcot?

A linguagem Charcot foi nomeada em homenagem a Jean-Martin Charcot, um neurologista francês considerado um dos fundadores da neurologia moderna. Assim como Charcot revolucionou a medicina com sua abordagem metódica e científica, a linguagem Charcot busca revolucionar o desenvolvimento de software médico com uma abordagem segura, eficiente e específica para o domínio.

Charcot oferece vantagens significativas para o desenvolvimento de aplicações médicas:

1. **Redução de Erros**: Verificações de segurança automáticas para prescrições médicas, dosagens e interações medicamentosas.
2. **Interoperabilidade**: Integração nativa com o padrão FHIR para comunicação com outros sistemas de saúde.
3. **Produtividade**: Sintaxe intuitiva e recursos específicos para medicina que aceleram o desenvolvimento.
4. **Segurança**: Sistema de tipos forte e gerenciamento de memória seguro que previnem erros comuns.
5. **Conformidade**: Recursos para garantir conformidade com regulamentações de privacidade e segurança de dados médicos.

## Instalação

### Requisitos do Sistema

- Python 3.8 ou superior
- Pip (gerenciador de pacotes Python)
- 100 MB de espaço em disco

### Instalação via Pip

A maneira mais simples de instalar a linguagem Charcot é usando o pip:

```bash
pip install charcot
```

### Instalação a partir do Código-Fonte

Para instalar a partir do código-fonte:

```bash
git clone https://github.com/charcot-lang/charcot.git
cd charcot
pip install -e .
```

### Verificando a Instalação

Para verificar se a instalação foi bem-sucedida, execute o comando:

```bash
charcot --version
```

Você deve ver a versão da linguagem Charcot instalada.

## Sintaxe Básica

A sintaxe da linguagem Charcot é inspirada em Python, com algumas adições específicas para medicina.

### Comentários

Comentários de linha única começam com `#`:

```
# Este é um comentário de linha única
```

Comentários de múltiplas linhas são delimitados por `"""`:

```
"""
Este é um comentário
de múltiplas linhas
"""
```

### Variáveis e Atribuição

A atribuição de variáveis é feita com o operador `=`:

```
nome = "João Silva"
idade = 42
peso = 70.5
ativo = true
```

### Tipos Básicos

- **int**: Números inteiros
- **float**: Números de ponto flutuante
- **string**: Sequências de caracteres
- **bool**: Valores booleanos (true/false)
- **list**: Listas de valores
- **dict**: Dicionários (mapas chave-valor)

### Operadores

Operadores aritméticos:

```
soma = 5 + 3
subtracao = 5 - 3
multiplicacao = 5 * 3
divisao = 5 / 3
divisao_inteira = 5 // 3
resto = 5 % 3
potencia = 5 ** 3
```

Operadores de comparação:

```
igual = 5 == 3
diferente = 5 != 3
maior = 5 > 3
menor = 5 < 3
maior_igual = 5 >= 3
menor_igual = 5 <= 3
```

Operadores lógicos:

```
e = true and false
ou = true or false
nao = not true
```

## Tipos de Dados

### Tipos Básicos

#### Números

```
# Inteiros
idade = 42
ano = 2023

# Ponto flutuante
peso = 70.5
altura = 1.75
```

#### Strings

```
nome = "João Silva"
endereco = 'Rua das Flores, 123'
texto_longo = """
Este é um texto
de múltiplas linhas
"""
```

Formatação de strings:

```
nome = "João"
idade = 42
mensagem = f"Olá, {nome}! Você tem {idade} anos."
```

#### Booleanos

```
ativo = true
internado = false
```

#### Listas

```
alergias = ["penicilina", "sulfa", "aspirina"]
valores = [1, 2, 3, 4, 5]
```

Acesso a elementos:

```
primeira_alergia = alergias[0]  # "penicilina"
```

#### Dicionários

```
paciente = {
    "nome": "João Silva",
    "idade": 42,
    "alergias": ["penicilina"]
}
```

Acesso a elementos:

```
nome_paciente = paciente["nome"]  # "João Silva"
```

### Tipos Específicos para Medicina

Além dos tipos básicos, a linguagem Charcot inclui tipos específicos para medicina, que serão detalhados na seção [Tipos Específicos para Medicina](#tipos-específicos-para-medicina).

## Estruturas de Controle

### Condicionais

#### If-Elif-Else

```
if idade > 65:
    print("Paciente idoso")
elif idade < 18:
    print("Paciente pediátrico")
else:
    print("Paciente adulto")
```

#### Match (Switch)

```
match status_paciente:
    case "internado":
        print("Paciente está internado")
    case "alta":
        print("Paciente recebeu alta")
    case "transferido":
        print("Paciente foi transferido")
    case _:
        print("Status desconhecido")
```

### Loops

#### For

```
for alergia in alergias:
    print(f"Paciente alérgico a {alergia}")
```

Iteração com índice:

```
for i, alergia in enumerate(alergias):
    print(f"Alergia {i+1}: {alergia}")
```

#### While

```
i = 0
while i < len(alergias):
    print(f"Alergia: {alergias[i]}")
    i += 1
```

### Controle de Fluxo

#### Break e Continue

```
for medicamento in medicamentos:
    if medicamento.contraindicado_para(paciente):
        print(f"{medicamento.nome} é contraindicado para o paciente")
        continue
    
    if medicamento.requer_autorizacao and not medico.autorizado:
        print(f"{medicamento.nome} requer autorização especial")
        break
    
    print(f"{medicamento.nome} pode ser prescrito")
```

#### Try-Except

```
try:
    prescrever(paciente, medicamento, dose)
except ContraindicacaoError as e:
    print(f"Erro de contraindicação: {e}")
except DosagemError as e:
    print(f"Erro de dosagem: {e}")
except Exception as e:
    print(f"Erro desconhecido: {e}")
else:
    print("Prescrição realizada com sucesso")
finally:
    print("Processo de prescrição concluído")
```

## Funções

### Definição de Funções

```
def calcular_imc(peso, altura):
    return peso / (altura ** 2)
```

### Parâmetros Nomeados

```
def prescrever(paciente, medicamento, dose, frequencia, duracao=7, instrucoes=null):
    # Implementação
    return prescricao
```

Chamada com parâmetros nomeados:

```
prescricao = prescrever(
    paciente: paciente1,
    medicamento: paracetamol,
    dose: "500 mg",
    frequencia: "8/8h",
    duracao: 5,
    instrucoes: "Tomar com água"
)
```

### Funções com Tipos

```
def calcular_imc(peso: float, altura: float) -> float:
    return peso / (altura ** 2)
```

### Funções Anônimas (Lambda)

```
calcular_dose = lambda peso, dose_por_kg: peso * dose_por_kg
```

## Módulos e Pacotes

### Importação de Módulos

```
import fhir
import prescription
```

### Importação Seletiva

```
from fhir import Patient, Medication
from prescription import create_prescription, verify_safety
```

### Importação com Alias

```
import fhir_integration as fhir
```

### Criação de Módulos

Um módulo é simplesmente um arquivo Python com extensão `.ch`:

```
# arquivo: utils.ch
def calcular_imc(peso, altura):
    return peso / (altura ** 2)

def classificar_imc(imc):
    if imc < 18.5:
        return "Abaixo do peso"
    elif imc < 25:
        return "Peso normal"
    elif imc < 30:
        return "Sobrepeso"
    else:
        return "Obesidade"
```

Importação do módulo:

```
import utils

imc = utils.calcular_imc(70, 1.75)
classificacao = utils.classificar_imc(imc)
```

## Tipos Específicos para Medicina

A linguagem Charcot inclui tipos específicos para medicina, que são fundamentais para o desenvolvimento de aplicações médicas seguras e eficientes.

### Patient (Paciente)

O tipo `patient` representa um paciente no sistema:

```
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175,
    allergies: ["penicillin"],
    conditions: ["hypertension"]
}
```

Atributos:
- **name**: Nome completo do paciente
- **birth_date**: Data de nascimento (formato ISO: YYYY-MM-DD)
- **gender**: Gênero (male, female, other, unknown)
- **weight**: Peso em kg (opcional)
- **height**: Altura em cm (opcional)
- **allergies**: Lista de alergias (opcional)
- **conditions**: Lista de condições médicas (opcional)

Métodos:
- **calculate_bmi()**: Calcula o IMC (Índice de Massa Corporal)
- **calculate_age()**: Calcula a idade atual
- **has_allergy(allergen)**: Verifica se o paciente tem alergia a um determinado alérgeno
- **has_condition(condition)**: Verifica se o paciente tem uma determinada condição médica

### Medication (Medicamento)

O tipo `medication` representa um medicamento no sistema:

```
medication Paracetamol {
    active_ingredient: "Acetaminophen",
    strength: "500 mg",
    form: "tablet",
    route: "oral",
    max_daily_dose: "4000 mg",
    contraindications: ["liver failure"],
    interactions: {
        "Warfarin": "Pode aumentar o efeito anticoagulante"
    }
}
```

Atributos:
- **active_ingredient**: Princípio ativo
- **strength**: Concentração (ex: "500 mg")
- **form**: Forma farmacêutica (ex: "tablet", "solution")
- **route**: Via de administração (ex: "oral", "intravenous")
- **max_daily_dose**: Dose máxima diária (opcional)
- **contraindications**: Lista de contraindicações (opcional)
- **interactions**: Dicionário de interações medicamentosas (opcional)
- **requires_prescription**: Se requer prescrição (opcional, padrão: true)
- **controlled_substance**: Se é substância controlada (opcional, padrão: false)

Métodos:
- **is_contraindicated_for(patient)**: Verifica se o medicamento é contraindicado para um paciente
- **check_interaction(medication)**: Verifica interação com outro medicamento
- **calculate_max_dose(weight)**: Calcula a dose máxima com base no peso do paciente

### Prescription (Prescrição)

O tipo `prescription` representa uma prescrição médica:

```
prescription new_rx {
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    frequency: "every 6 hours",
    duration: 5,
    instructions: "Take with water for pain relief",
    prescriber: Doctor1
}
```

Atributos:
- **patient**: Paciente
- **medication**: Medicamento
- **dose**: Dose (ex: "500 mg")
- **frequency**: Frequência (ex: "every 6 hours")
- **duration**: Duração em dias (opcional)
- **instructions**: Instruções para o paciente (opcional)
- **prescriber**: Prescritor (opcional)

Métodos:
- **is_safe()**: Verifica se a prescrição é segura
- **calculate_total_dose()**: Calcula a dose total com base na frequência e duração
- **is_within_max_dose()**: Verifica se a dose está dentro do limite máximo

### Encounter (Encontro)

O tipo `encounter` representa um encontro clínico (consulta, internação):

```
encounter Encounter1 {
    patient: Patient1,
    class_code: "inpatient",
    status: "in-progress",
    start_time: "2023-05-01T10:00:00",
    location: Room101,
    practitioner: Doctor1,
    reason: "Pneumonia"
}
```

Atributos:
- **patient**: Paciente
- **class_code**: Tipo de encontro (inpatient, outpatient, emergency, etc.)
- **status**: Status (in-progress, finished, cancelled, etc.)
- **start_time**: Data/hora de início
- **end_time**: Data/hora de término (opcional)
- **location**: Localização (opcional)
- **practitioner**: Profissional responsável (opcional)
- **reason**: Motivo do encontro (opcional)

Métodos:
- **duration()**: Calcula a duração do encontro
- **add_diagnosis(diagnosis)**: Adiciona um diagnóstico ao encontro
- **add_procedure(procedure)**: Adiciona um procedimento ao encontro

### Observation (Observação)

O tipo `observation` representa uma observação clínica (sinais vitais, resultados de exames):

```
observation BloodPressure1 {
    patient: Patient1,
    code: "8480-6",
    code_system: "LOINC",
    value: "120/80",
    unit: "mmHg",
    time: "2023-05-01T10:30:00",
    performer: Nurse1
}
```

Atributos:
- **patient**: Paciente
- **code**: Código da observação
- **code_system**: Sistema de codificação (ex: LOINC, SNOMED CT)
- **value**: Valor da observação
- **unit**: Unidade de medida (opcional)
- **time**: Data/hora da observação
- **performer**: Profissional que realizou a observação (opcional)

Métodos:
- **is_abnormal()**: Verifica se o valor está fora dos limites normais
- **trend(observations)**: Calcula a tendência com base em observações anteriores

## Workflows Hospitalares

A linguagem Charcot suporta nativamente workflows hospitalares e ambulatoriais, permitindo a automação de processos clínicos.

### Internação

#### Admissão de Paciente

```
encounter = admit_patient(
    patient: Patient1,
    location: Room101,
    reason: "Pneumonia",
    attending: Doctor1
)
```

#### Transferência de Paciente

```
transfer_patient(
    encounter: encounter,
    new_location: Room202,
    reason: "Necessidade de monitoramento mais próximo"
)
```

#### Alta de Paciente

```
discharge_patient(
    encounter: encounter,
    notes: "Paciente recuperado. Seguimento em 1 semana."
)
```

### Ambulatorial

#### Agendamento de Consulta

```
appointment = schedule_appointment(
    patient: Patient1,
    practitioner: Doctor1,
    time: "2023-05-15T14:00:00",
    reason: "Consulta de rotina"
)
```

#### Check-in de Paciente

```
check_in_patient(
    appointment: appointment,
    time: "2023-05-15T13:45:00"
)
```

#### Início e Fim de Consulta

```
start_appointment(appointment)

# Realizar consulta...

end_appointment(
    appointment: appointment,
    notes: "Paciente estável. Retorno em 3 meses."
)
```

### Medicação

#### Prescrição de Medicamento

```
prescription = prescribe(
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    frequency: "every 6 hours",
    duration: 5,
    instructions: "Take with water for pain relief",
    prescriber: Doctor1
)
```

#### Dispensação de Medicamento

```
dispense_medication(
    prescription: prescription,
    quantity: 20,
    pharmacist: Pharmacist1
)
```

#### Administração de Medicamento

```
administer_medication(
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    route: "oral",
    time: now(),
    administrator: Nurse1
)
```

## Sistema de Prescrição

A linguagem Charcot inclui um sistema de prescri
(Content truncated due to size limit. Use line ranges to read in chunks)