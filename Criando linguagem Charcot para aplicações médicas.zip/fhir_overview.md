# FHIR (Fast Healthcare Interoperability Resources)

## Visão Geral

FHIR (Fast Healthcare Interoperability Resources) é um padrão de dados de saúde desenvolvido pela HL7 International para facilitar a troca de informações em saúde de forma interoperável. O FHIR é projetado para ser:

- Baseado em padrões web modernos
- Focado em implementação prática
- Desenvolvido por uma comunidade aberta
- Disponível gratuitamente para uso

O FHIR utiliza uma abordagem baseada em recursos, onde cada recurso representa uma entidade ou conceito no domínio da saúde. Esses recursos são definidos com uma estrutura clara e podem ser trocados entre sistemas usando formatos como JSON e XML.

## Estrutura do FHIR

O FHIR é organizado em níveis:

1. **Nível 1**: Framework básico sobre o qual a especificação é construída
2. **Nível 2**: Implementação e vinculação a especificações externas
3. **Nível 3**: Vinculação a conceitos do mundo real no sistema de saúde
4. **Nível 4**: Registro e troca de dados para o processo de saúde
5. **Nível 5**: Capacidade de raciocinar sobre o processo de saúde

## API RESTful

O FHIR define uma API RESTful que permite a interação com recursos de saúde. As principais interações incluem:

### Interações em Nível de Instância
- **read**: Ler o estado atual do recurso
- **vread**: Ler o estado de uma versão específica do recurso
- **update**: Atualizar um recurso existente por seu ID (ou criá-lo se for novo)
- **patch**: Atualizar um recurso existente postando um conjunto de alterações
- **delete**: Excluir um recurso
- **history**: Recuperar o histórico de alterações de um recurso específico

### Interações em Nível de Tipo
- **create**: Criar um novo recurso com um ID atribuído pelo servidor
- **search**: Pesquisar o tipo de recurso com base em critérios de filtro
- **delete**: Exclusão condicional em um tipo de recurso específico
- **history**: Recuperar o histórico de alterações de um tipo de recurso específico

### Interações em Nível de Sistema
- **capabilities**: Obter uma declaração de capacidade para o sistema
- **batch/transaction**: Realizar múltiplas operações em uma única interação
- **delete**: Exclusão condicional em todos os tipos de recursos
- **history**: Recuperar o histórico de alterações de todos os recursos

## Recursos Principais para Aplicações Médicas

### Recurso Patient
O recurso Patient contém informações demográficas e administrativas sobre um indivíduo ou animal que recebe cuidados ou outros serviços relacionados à saúde. Abrange:

- Dados demográficos básicos
- Contatos e relacionamentos
- Informações de comunicação
- Identificadores do paciente
- Status ativo/inativo

### Recurso Medication
O recurso Medication é usado para a identificação e definição de um medicamento, incluindo ingredientes, para fins de prescrição, dispensação e administração. Características:

- Código e identificação do medicamento
- Forma de dosagem
- Ingredientes e suas concentrações
- Informações de lote e validade
- Status do medicamento

### Workflow no FHIR
O FHIR define padrões para fluxos de trabalho em saúde, categorizando recursos em:

1. **Definições**: Recursos que definem algo que pode potencialmente acontecer de maneira independente do paciente e do tempo (ActivityDefinition, PlanDefinition)
2. **Solicitações**: Recursos que pedem ou expressam um desejo/intenção para que algo seja feito (MedicationRequest, ServiceRequest)
3. **Eventos**: Recursos que expressam que algo foi feito e que potencialmente pode ser feito devido a uma solicitação (MedicationAdministration, Observation)

## Relevância para a Linguagem Charcot

O padrão FHIR oferece uma base sólida para a linguagem Charcot por:

1. Fornecer modelos de dados padronizados para entidades médicas
2. Definir fluxos de trabalho clínicos e administrativos
3. Estabelecer padrões de interoperabilidade para troca de informações
4. Oferecer uma API RESTful que pode ser incorporada nativamente na linguagem
5. Definir terminologias e vocabulários controlados para conceitos médicos

A incorporação do FHIR na linguagem Charcot permitirá que aplicações desenvolvidas nessa linguagem sejam naturalmente interoperáveis com outros sistemas de saúde, facilitando a integração em ambientes hospitalares e ambulatoriais existentes.
