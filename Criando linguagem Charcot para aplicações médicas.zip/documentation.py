#!/usr/bin/env python3
"""
Módulo de Documentação Interativa para o REPL da Linguagem Charcot

Este módulo implementa recursos de ajuda e documentação para o ambiente REPL da linguagem Charcot,
incluindo exemplos, tutoriais e referências para os recursos específicos de medicina.
"""

import os
import sys
import textwrap
import json
from typing import Dict, List, Any, Optional
import colorama
from colorama import Fore, Back, Style

# Inicializar colorama para formatação de texto colorido
colorama.init()


class CharcotDocumentation:
    """Gerencia a documentação interativa para o REPL da linguagem Charcot."""
    
    def __init__(self, docs_dir: Optional[str] = None):
        """
        Inicializa o sistema de documentação.
        
        Args:
            docs_dir (Optional[str]): Diretório contendo arquivos de documentação.
        """
        self.docs_dir = docs_dir or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "docs")
        
        # Carregar documentação
        self.topics = self._load_topics()
        self.examples = self._load_examples()
        self.tutorials = self._load_tutorials()
        self.references = self._load_references()
    
    def _load_topics(self) -> Dict[str, str]:
        """
        Carrega tópicos de documentação.
        
        Returns:
            Dict[str, str]: Dicionário de tópicos.
        """
        topics = {
            "language": """
# Linguagem Charcot

A linguagem Charcot é uma linguagem de programação projetada especificamente para aplicações médicas.
Ela combina a sintaxe intuitiva do Python com a segurança e desempenho do Rust, além de incorporar
nativamente conceitos médicos e padrões como FHIR.

## Características Principais

- **Sintaxe Simples e Intuitiva**: Inspirada em Python, fácil de aprender e usar.
- **Segurança de Tipos**: Sistema de tipos estático que previne erros comuns.
- **Recursos Específicos para Medicina**: Tipos de dados e funções específicas para o domínio médico.
- **Integração FHIR**: Suporte nativo ao padrão FHIR para interoperabilidade.
- **Workflows Hospitalares**: Funções para gerenciar processos hospitalares e ambulatoriais.
- **Sistema de Prescrição**: Verificações de segurança automáticas para prescrições médicas.
- **Segurança e Privacidade**: Recursos avançados para proteção de dados sensíveis.

## Começando

Para começar a usar a linguagem Charcot, experimente os exemplos disponíveis digitando `examples`
e carregue um exemplo com `example <nome>`. Consulte a documentação específica com `help <tópico>`.
""",
            
            "types": """
# Tipos de Dados na Linguagem Charcot

A linguagem Charcot inclui tipos de dados básicos e tipos específicos para medicina.

## Tipos Básicos

- **int**: Números inteiros
- **float**: Números de ponto flutuante
- **string**: Sequências de caracteres
- **bool**: Valores booleanos (true/false)
- **list**: Listas de valores
- **dict**: Dicionários (mapas chave-valor)

## Tipos Específicos para Medicina

- **patient**: Representa um paciente no sistema
- **medication**: Representa um medicamento
- **prescription**: Representa uma prescrição médica
- **encounter**: Representa um encontro clínico (consulta, internação)
- **observation**: Representa uma observação clínica
- **condition**: Representa uma condição médica
- **procedure**: Representa um procedimento médico

## Exemplo de Uso

```
# Definir um paciente
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175
}

# Definir um medicamento
medication Paracetamol {
    active_ingredient: "Acetaminophen",
    strength: "500 mg",
    form: "tablet",
    route: "oral"
}
```
""",
            
            "functions": """
# Funções na Linguagem Charcot

A linguagem Charcot inclui funções básicas e funções específicas para medicina.

## Funções Básicas

- **print()**: Exibe valores na tela
- **input()**: Lê entrada do usuário
- **len()**: Retorna o tamanho de uma coleção
- **str()**, **int()**, **float()**, **bool()**: Conversão de tipos
- **min()**, **max()**, **sum()**: Operações em coleções

## Funções Específicas para Medicina

### Pacientes
- **calculate_bmi(patient)**: Calcula o IMC de um paciente
- **calculate_age(patient)**: Calcula a idade de um paciente

### Workflows Hospitalares
- **admit_patient()**: Interna um paciente
- **discharge_patient()**: Dá alta a um paciente
- **transfer_patient()**: Transfere um paciente
- **schedule_appointment()**: Agenda uma consulta

### Prescrições
- **prescribe()**: Cria uma prescrição
- **safety_check()**: Verifica a segurança de uma prescrição
- **issue()**: Emite uma prescrição
- **cancel()**: Cancela uma prescrição

### Medicamentos
- **administer_medication()**: Administra um medicamento
- **check_interaction()**: Verifica interações medicamentosas

## Exemplo de Uso

```
# Internar paciente
encounter = admit_patient(
    patient: Patient1,
    location: "Room 101",
    reason: "Pneumonia"
)

# Verificar segurança de prescrição
safety_result = safety_check(new_rx)
if safety_result.is_safe:
    issue(new_rx)
```
""",
            
            "fhir": """
# Integração FHIR na Linguagem Charcot

A linguagem Charcot integra nativamente o padrão FHIR (Fast Healthcare Interoperability Resources)
para garantir interoperabilidade com sistemas de saúde.

## Recursos FHIR Suportados

- **Patient**: Informações demográficas e clínicas de pacientes
- **Practitioner**: Profissionais de saúde
- **Medication**: Medicamentos
- **MedicationRequest**: Prescrições de medicamentos
- **Encounter**: Encontros clínicos (consultas, internações)
- **Observation**: Observações clínicas (sinais vitais, resultados de exames)
- **Condition**: Condições médicas (diagnósticos)
- **Procedure**: Procedimentos médicos

## Funções FHIR

- **fhir_create()**: Cria um recurso FHIR
- **fhir_read()**: Lê um recurso FHIR
- **fhir_update()**: Atualiza um recurso FHIR
- **fhir_delete()**: Exclui um recurso FHIR
- **fhir_search()**: Pesquisa recursos FHIR

## Exemplo de Uso

```
# Criar paciente FHIR
patient_fhir = fhir_create(
    resourceType: "Patient",
    name: [{
        given: ["João"],
        family: "Silva"
    }],
    gender: "male",
    birthDate: "1980-05-15"
)

# Pesquisar medicamentos
medications = fhir_search(
    resourceType: "Medication",
    params: {
        "code": "acetaminophen"
    }
)
```
""",
            
            "workflows": """
# Workflows Hospitalares na Linguagem Charcot

A linguagem Charcot suporta nativamente workflows hospitalares e ambulatoriais,
permitindo a automação de processos clínicos.

## Workflows Suportados

- **Internação**: Admissão, transferência e alta de pacientes
- **Ambulatorial**: Agendamento, check-in e conclusão de consultas
- **Medicação**: Prescrição, dispensação e administração de medicamentos
- **Exames**: Solicitação, coleta, análise e resultados de exames

## Funções de Workflow

### Internação
- **admit_patient()**: Interna um paciente
- **transfer_patient()**: Transfere um paciente para outra localização
- **discharge_patient()**: Dá alta a um paciente

### Ambulatorial
- **schedule_appointment()**: Agenda uma consulta
- **check_in_patient()**: Registra a chegada do paciente
- **start_appointment()**: Inicia uma consulta
- **end_appointment()**: Finaliza uma consulta

### Medicação
- **prescribe()**: Cria uma prescrição
- **dispense_medication()**: Dispensa um medicamento
- **administer_medication()**: Administra um medicamento

## Exemplo de Uso

```
# Workflow de internação
encounter = admit_patient(
    patient: Patient1,
    location: "Room 101",
    reason: "Pneumonia"
)

# Administrar medicação
administer_medication(
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    route: "oral"
)

# Transferir paciente
transfer_patient(
    encounter: encounter,
    new_location: "Room 202",
    reason: "Necessidade de monitoramento"
)

# Dar alta
discharge_patient(
    encounter: encounter,
    notes: "Paciente recuperado. Seguimento em 1 semana."
)
```
""",
            
            "prescription": """
# Sistema de Prescrição na Linguagem Charcot

A linguagem Charcot inclui um sistema de prescrição médica com verificações
de segurança automáticas.

## Componentes do Sistema de Prescrição

- **Medicamentos**: Definição de medicamentos com informações completas
- **Pacientes**: Informações clínicas relevantes para prescrições
- **Prescritores**: Médicos e outros profissionais com direitos de prescrição
- **Prescrições**: Instruções detalhadas para uso de medicamentos
- **Verificações de Segurança**: Validações automáticas de segurança

## Verificações de Segurança

- **Alergias**: Verifica se o paciente tem alergia ao medicamento
- **Interações**: Verifica interações com outros medicamentos ativos
- **Contraindicações**: Verifica contraindicações com base nas condições do paciente
- **Dose**: Verifica se a dose está dentro dos limites seguros
- **Direitos de Prescrição**: Verifica se o prescritor tem autorização

## Funções de Prescrição

- **prescribe()**: Cria uma prescrição
- **safety_check()**: Verifica a segurança de uma prescrição
- **issue()**: Emite uma prescrição
- **cancel()**: Cancela uma prescrição
- **renew()**: Renova uma prescrição existente

## Exemplo de Uso

```
# Criar prescrição
prescription new_rx {
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    frequency: "every 6 hours",
    duration: 5,
    instructions: "Take with water for pain relief"
}

# Verificar segurança
safety_result = safety_check(new_rx)

# Emitir prescrição se segura
if safety_result.is_safe:
    issue(new_rx)
    print("Prescrição emitida com sucesso")
else:
    print(f"Prescrição não emitida: {safety_result.notes}")
```
""",
            
            "security": """
# Segurança e Privacidade na Linguagem Charcot

A linguagem Charcot inclui recursos avançados de segurança e privacidade
para proteção de dados sensíveis de saúde.

## Recursos de Segurança

- **Criptografia**: Proteção de dados sensíveis
- **Controle de Acesso**: Baseado em papéis e permissões
- **Auditoria**: Registro detalhado de ações
- **Anonimização**: Remoção de identificadores para uso em pesquisa
- **Proteção de PHI**: Detecção e mascaramento de informações de saúde protegidas

## Funções de Segurança

- **encrypt_data()**: Criptografa dados sensíveis
- **decrypt_data()**: Descriptografa dados
- **authenticate()**: Autentica um usuário
- **check_permission()**: Verifica permissões de acesso
- **audit_log()**: Registra ações no log de auditoria
- **anonymize_data()**: Anonimiza dados para pesquisa
- **mask_phi()**: Mascara informações de saúde protegidas
- **detect_phi()**: Detecta possíveis informações de saúde protegidas

## Exemplo de Uso

```
# Autenticar usuário
if authenticate(username: "dr.silva", password: "senha123"):
    # Verificar permissão
    if check_permission("prescription:create"):
        # Criar prescrição
        rx = prescribe(...)
        
        # Registrar no log de auditoria
        audit_log(
            action: "create",
            resource: "prescription",
            resource_id: rx.id
        )
    else:
        print("Permissão negada")
```
"""
        }
        
        return topics
    
    def _load_examples(self) -> Dict[str, str]:
        """
        Carrega exemplos de código Charcot.
        
        Returns:
            Dict[str, str]: Dicionário de exemplos.
        """
        examples = {
            "hello_world": """
# Exemplo: Hello World
# Um simples programa "Olá, Mundo" na linguagem Charcot

print("Olá, mundo da medicina!")
""",
            
            "patient_bmi": """
# Exemplo: Cálculo de IMC
# Demonstra a criação de um paciente e cálculo de IMC

# Definir um paciente
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175
}

# Calcular IMC
bmi = Patient1.weight / ((Patient1.height / 100) ** 2)
print(f"Paciente: {Patient1.name}")
print(f"IMC: {bmi:.1f}")

# Classificar IMC
if bmi < 18.5:
    print("Classificação: Abaixo do peso")
elif bmi < 25:
    print("Classificação: Peso normal")
elif bmi < 30:
    print("Classificação: Sobrepeso")
else:
    print("Classificação: Obesidade")
""",
            
            "medication_safety": """
# Exemplo: Segurança de Medicamentos
# Demonstra a verificação de segurança de medicamentos

# Definir um medicamento
medication Paracetamol {
    active_ingredient: "Acetaminophen",
    strength: "500 mg",
    form: "tablet",
    route: "oral",
    max_daily_dose: "4000 mg",
    contraindications: ["liver failure"]
}

# Definir um paciente
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175,
    conditions: ["hypertension"]
}

# Verificar dose
dose = 2 * 500  # 2 comprimidos de 500mg
frequency = 4   # 4 vezes ao dia
daily_dose = dose * frequency

print(f"Medicamento: {Paracetamol.active_ingredient} {Paracetamol.strength}")
print(f"Dose prescrita: {dose} mg, {frequency} vezes ao dia")
print(f"Dose diária total: {daily_dose} mg")
print(f"Dose máxima diária: {Paracetamol.max_daily_dose}")

if daily_dose > 4000:
    print("ALERTA: Dose diária excede o máximo recomendado!")
else:
    print("Dose diária dentro do limite seguro.")

# Verificar contraindicações
for condition in Patient1.conditions:
    if condition in Paracetamol.contraindications:
        print(f"ALERTA: Medicamento contraindicado para pacientes com {condition}!")
""",
            
            "prescription_workflow": """
# Exemplo: Workflow de Prescrição
# Demonstra o processo completo de prescrição médica

# Definir um paciente
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175,
    allergies: ["penicillin"],
    conditions: ["hypertension"]
}

# Definir um medicamento
medication Paracetamol {
    active_ingredient: "Acetaminophen",
    strength: "500 mg",
    form: "tablet",
    route: "oral",
    max_daily_dose: "4000 mg"
}

# Definir um prescritor
prescriber Doctor1 {
    name: "Dra. Maria Oliveira",
    license: "CRM12345",
    specialty: "Clínica Médica"
}

# Criar uma prescrição
prescription new_rx {
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    frequency: "every 6 hours",
    duration: 5,  # dias
    instructions: "Take with water for pain relief",
    prescriber: Doctor1
}

# Verificar segurança
safety_result = safety_check(new_rx)

# Exibir resultado da verificação
print(f"Prescrição: {Paracetamol.active_ingredient} {new_rx.dose}, {new_rx.frequency}")
print(f"Paciente: {Patient1.name}")
print(f"Prescritor: {Doctor1.name}")
print(f"Resultado da verificação: {safety_result.status}")

# Emitir prescrição se segura
if safety_result.is_safe:
    issue(new_rx)
    print("Prescrição emitida com sucesso")
    
    # Simular administração do medicamento
    administer_medication(
        patient: Patient1,
        medication: Paracetamol,
        dose: "500 mg",
        route: "oral",
        time: now()
    )
    print("Medicamento administrado")
else:
    print(f"Prescrição não emitida: {safety_result.notes}")
""",
            
            "hospital_workflow": """
# Exemplo: Workflow Hospitalar
# Demonstra o processo de internação, transferência e alta

# Definir um paciente
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175,
    conditions: ["pneumonia"]
}

# Definir localizações
location Ward_A {
    name: "Ala A",
    type: "ward",
    capacity: 10
}

location Room_101 {
    name: "Quarto 101",
    type: "room",
    parent: Ward_A,
    capacity: 2
}

location Room_202 {
    name: "Quarto 202",
    type: "room",
    parent: Ward_A,
    capacity: 1
}

# Definir médico
prescriber Doctor1 {
    name: "Dra. Maria Oliveira",
    license: "CRM12345",
    specialty: "Pneumologia"
}

(Content truncated due to size limit. Use line ranges to read in chunks)