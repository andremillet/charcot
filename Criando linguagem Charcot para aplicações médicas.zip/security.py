#!/usr/bin/env python3
"""
Módulo de Segurança e Privacidade para a Linguagem Charcot

Este módulo implementa recursos de segurança e privacidade para a linguagem Charcot,
incluindo criptografia, anonimização, controle de acesso e auditoria para dados médicos.
"""

from typing import Dict, List, Any, Optional, Union, Callable, Set, Tuple
from dataclasses import dataclass, field
import datetime
import uuid
import json
import hashlib
import base64
import os
import re
import logging
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC


@dataclass
class User:
    """Representa um usuário do sistema."""
    id: str
    username: str
    role: str  # admin, doctor, nurse, pharmacist, patient, etc.
    password_hash: str
    salt: str
    permissions: List[str] = field(default_factory=list)
    active: bool = True
    last_login: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte o usuário para um dicionário."""
        return {
            "id": self.id,
            "username": self.username,
            "role": self.role,
            "password_hash": self.password_hash,
            "salt": self.salt,
            "permissions": self.permissions,
            "active": self.active,
            "last_login": self.last_login
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'User':
        """Cria um usuário a partir de um dicionário."""
        return cls(
            id=data["id"],
            username=data["username"],
            role=data["role"],
            password_hash=data["password_hash"],
            salt=data["salt"],
            permissions=data.get("permissions", []),
            active=data.get("active", True),
            last_login=data.get("last_login")
        )


@dataclass
class AuditLog:
    """Representa um registro de auditoria."""
    id: str
    timestamp: str
    user_id: str
    action: str  # create, read, update, delete, login, logout, etc.
    resource_type: str  # patient, medication, prescription, etc.
    resource_id: Optional[str] = None
    details: Optional[str] = None
    ip_address: Optional[str] = None
    success: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte o registro de auditoria para um dicionário."""
        return {
            "id": self.id,
            "timestamp": self.timestamp,
            "user_id": self.user_id,
            "action": self.action,
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "details": self.details,
            "ip_address": self.ip_address,
            "success": self.success
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AuditLog':
        """Cria um registro de auditoria a partir de um dicionário."""
        return cls(
            id=data["id"],
            timestamp=data["timestamp"],
            user_id=data["user_id"],
            action=data["action"],
            resource_type=data["resource_type"],
            resource_id=data.get("resource_id"),
            details=data.get("details"),
            ip_address=data.get("ip_address"),
            success=data.get("success", True)
        )


class SecurityException(Exception):
    """Exceção lançada quando ocorre um erro de segurança."""
    pass


class SecurityManager:
    """Gerencia a segurança e privacidade do sistema."""
    
    def __init__(self, key_file: Optional[str] = None, log_file: Optional[str] = None):
        """
        Inicializa o gerenciador de segurança.
        
        Args:
            key_file (Optional[str]): Caminho para o arquivo de chave de criptografia.
            log_file (Optional[str]): Caminho para o arquivo de log de auditoria.
        """
        self.users: Dict[str, User] = {}
        self.audit_logs: List[AuditLog] = []
        self.current_user: Optional[User] = None
        
        # Configurar criptografia
        if key_file and os.path.exists(key_file):
            with open(key_file, 'rb') as f:
                self.key = f.read()
        else:
            self.key = Fernet.generate_key()
            if key_file:
                with open(key_file, 'wb') as f:
                    f.write(self.key)
        
        self.cipher = Fernet(self.key)
        
        # Configurar logging
        self.logger = logging.getLogger("charcot.security")
        self.logger.setLevel(logging.INFO)
        
        if log_file:
            handler = logging.FileHandler(log_file)
            handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
            self.logger.addHandler(handler)
        
        # Definir regras de acesso por papel
        self.role_permissions = {
            "admin": [
                "user:create", "user:read", "user:update", "user:delete",
                "patient:create", "patient:read", "patient:update", "patient:delete",
                "medication:create", "medication:read", "medication:update", "medication:delete",
                "prescription:create", "prescription:read", "prescription:update", "prescription:delete",
                "audit:read"
            ],
            "doctor": [
                "patient:read", "patient:update",
                "medication:read",
                "prescription:create", "prescription:read", "prescription:update", "prescription:delete"
            ],
            "nurse": [
                "patient:read", "patient:update",
                "medication:read",
                "prescription:read"
            ],
            "pharmacist": [
                "patient:read",
                "medication:read", "medication:update",
                "prescription:read", "prescription:update"
            ],
            "patient": [
                "patient:read_own",
                "prescription:read_own"
            ]
        }
    
    def register_user(self, username: str, password: str, role: str) -> str:
        """
        Registra um novo usuário.
        
        Args:
            username (str): Nome de usuário.
            password (str): Senha.
            role (str): Papel do usuário.
            
        Returns:
            str: ID do usuário criado.
            
        Raises:
            ValueError: Se o nome de usuário já existir ou o papel for inválido.
        """
        # Verificar se o nome de usuário já existe
        for user in self.users.values():
            if user.username == username:
                raise ValueError(f"Nome de usuário '{username}' já existe.")
        
        # Verificar se o papel é válido
        if role not in self.role_permissions:
            raise ValueError(f"Papel '{role}' inválido.")
        
        # Gerar salt e hash da senha
        salt = os.urandom(16)
        salt_b64 = base64.b64encode(salt).decode('utf-8')
        password_hash = self._hash_password(password, salt)
        
        # Criar usuário
        user_id = str(uuid.uuid4())
        
        user = User(
            id=user_id,
            username=username,
            role=role,
            password_hash=password_hash,
            salt=salt_b64,
            permissions=self.role_permissions[role]
        )
        
        # Adicionar usuário ao sistema
        self.users[user_id] = user
        
        # Registrar ação no log de auditoria
        self._audit_log(
            user_id=self.current_user.id if self.current_user else "system",
            action="create",
            resource_type="user",
            resource_id=user_id,
            details=f"Criado usuário '{username}' com papel '{role}'"
        )
        
        return user_id
    
    def authenticate(self, username: str, password: str) -> bool:
        """
        Autentica um usuário.
        
        Args:
            username (str): Nome de usuário.
            password (str): Senha.
            
        Returns:
            bool: True se a autenticação for bem-sucedida, False caso contrário.
        """
        # Encontrar usuário pelo nome de usuário
        user = None
        for u in self.users.values():
            if u.username == username:
                user = u
                break
        
        if not user:
            self._audit_log(
                user_id="anonymous",
                action="login",
                resource_type="user",
                details=f"Tentativa de login com nome de usuário inexistente: '{username}'",
                success=False
            )
            return False
        
        # Verificar se o usuário está ativo
        if not user.active:
            self._audit_log(
                user_id=user.id,
                action="login",
                resource_type="user",
                details=f"Tentativa de login com usuário inativo: '{username}'",
                success=False
            )
            return False
        
        # Verificar senha
        salt = base64.b64decode(user.salt)
        password_hash = self._hash_password(password, salt)
        
        if password_hash != user.password_hash:
            self._audit_log(
                user_id=user.id,
                action="login",
                resource_type="user",
                details=f"Tentativa de login com senha incorreta para usuário: '{username}'",
                success=False
            )
            return False
        
        # Autenticação bem-sucedida
        self.current_user = user
        user.last_login = datetime.datetime.now().isoformat()
        
        self._audit_log(
            user_id=user.id,
            action="login",
            resource_type="user",
            details=f"Login bem-sucedido para usuário: '{username}'",
            success=True
        )
        
        return True
    
    def logout(self) -> None:
        """Encerra a sessão do usuário atual."""
        if self.current_user:
            self._audit_log(
                user_id=self.current_user.id,
                action="logout",
                resource_type="user",
                details=f"Logout para usuário: '{self.current_user.username}'",
                success=True
            )
            
            self.current_user = None
    
    def check_permission(self, permission: str, resource_id: Optional[str] = None) -> bool:
        """
        Verifica se o usuário atual tem a permissão especificada.
        
        Args:
            permission (str): A permissão a ser verificada.
            resource_id (Optional[str]): ID do recurso, para permissões específicas.
            
        Returns:
            bool: True se o usuário tem a permissão, False caso contrário.
        """
        if not self.current_user:
            return False
        
        # Verificar permissão específica
        if permission in self.current_user.permissions:
            return True
        
        # Verificar permissão para recursos próprios
        if permission.endswith("_own") and resource_id:
            base_permission = permission.replace("_own", "")
            if base_permission in self.current_user.permissions:
                # Verificar se o recurso pertence ao usuário
                # Isso depende da lógica específica da aplicação
                # Por exemplo, verificar se o ID do paciente corresponde ao ID do usuário
                return True
        
        return False
    
    def require_permission(self, permission: str, resource_id: Optional[str] = None) -> None:
        """
        Exige que o usuário atual tenha a permissão especificada.
        
        Args:
            permission (str): A permissão exigida.
            resource_id (Optional[str]): ID do recurso, para permissões específicas.
            
        Raises:
            SecurityException: Se o usuário não tiver a permissão.
        """
        if not self.check_permission(permission, resource_id):
            action = permission.split(":")[1] if ":" in permission else permission
            resource = permission.split(":")[0] if ":" in permission else "resource"
            
            error_msg = f"Acesso negado: usuário não tem permissão para {action} {resource}"
            
            self._audit_log(
                user_id=self.current_user.id if self.current_user else "anonymous",
                action=action,
                resource_type=resource,
                resource_id=resource_id,
                details=error_msg,
                success=False
            )
            
            raise SecurityException(error_msg)
    
    def encrypt_data(self, data: str) -> str:
        """
        Criptografa dados sensíveis.
        
        Args:
            data (str): Dados a serem criptografados.
            
        Returns:
            str: Dados criptografados em formato base64.
        """
        encrypted = self.cipher.encrypt(data.encode('utf-8'))
        return base64.b64encode(encrypted).decode('utf-8')
    
    def decrypt_data(self, encrypted_data: str) -> str:
        """
        Descriptografa dados sensíveis.
        
        Args:
            encrypted_data (str): Dados criptografados em formato base64.
            
        Returns:
            str: Dados descriptografados.
            
        Raises:
            Exception: Se ocorrer um erro na descriptografia.
        """
        try:
            encrypted_bytes = base64.b64decode(encrypted_data)
            decrypted = self.cipher.decrypt(encrypted_bytes)
            return decrypted.decode('utf-8')
        except Exception as e:
            raise Exception(f"Erro ao descriptografar dados: {e}")
    
    def anonymize_patient_data(self, patient_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Anonimiza dados de paciente para uso em pesquisa ou relatórios.
        
        Args:
            patient_data (Dict[str, Any]): Dados do paciente.
            
        Returns:
            Dict[str, Any]: Dados anonimizados.
        """
        # Criar cópia para não modificar o original
        anonymized = patient_data.copy()
        
        # Remover identificadores diretos
        if "id" in anonymized:
            anonymized["id"] = self._hash_identifier(anonymized["id"])
        
        if "name" in anonymized:
            anonymized["name"] = "REDACTED"
        
        # Generalizar data de nascimento para apenas o ano
        if "birth_date" in anonymized:
            try:
                year = anonymized["birth_date"].split("-")[0]
                anonymized["birth_year"] = year
                del anonymized["birth_date"]
            except:
                anonymized["birth_year"] = "UNKNOWN"
                if "birth_date" in anonymized:
                    del anonymized["birth_date"]
        
        # Remover outros identificadores
        for field in ["address", "phone", "email", "ssn", "medical_record_number"]:
            if field in anonymized:
                del anonymized[field]
        
        return anonymized
    
    def _hash_password(self, password: str, salt: bytes) -> str:
        """
        Gera um hash seguro para uma senha.
        
        Args:
            password (str): A senha.
            salt (bytes): O salt para o hash.
            
        Returns:
            str: O hash da senha em formato base64.
        """
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000
        )
        
        key = kdf.derive(password.encode('utf-8'))
        return base64.b64encode(key).decode('utf-8')
    
    def _hash_identifier(self, identifier: str) -> str:
        """
        Gera um hash para um identificador.
        
        Args:
            identifier (str): O identificador.
            
        Returns:
            str: O hash do identificador.
        """
        hash_obj = hashlib.sha256(identifier.encode('utf-8'))
        return hash
(Content truncated due to size limit. Use line ranges to read in chunks)