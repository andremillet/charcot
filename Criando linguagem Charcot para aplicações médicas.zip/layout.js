import Link from 'next/link'

export default function DocsLayout({ children }) {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row gap-10">
        {/* Sidebar */}
        <div className="md:w-1/4">
          <div className="sticky top-24 bg-white p-6 rounded-xl shadow-sm">
            <h3 className="text-xl font-bold mb-6">Documentação</h3>
            <nav className="space-y-6">
              <div>
                <h4 className="font-medium text-gray-900 mb-3">Introdução</h4>
                <ul className="space-y-2 pl-4">
                  <li>
                    <Link href="/docs" className="text-blue-600 hover:text-blue-800">
                      Visão Geral
                    </Link>
                  </li>
                  <li>
                    <Link href="/docs/getting-started" className="text-blue-600 hover:text-blue-800">
                      Primeiros Passos
                    </Link>
                  </li>
                  <li>
                    <Link href="/docs/installation" className="text-blue-600 hover:text-blue-800">
                      Instalação
                    </Link>
                  </li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 mb-3">Fundamentos</h4>
                <ul className="space-y-2 pl-4">
                  <li>
                    <Link href="/docs/syntax" className="text-blue-600 hover:text-blue-800">
                      Sintaxe Básica
                    </Link>
                  </li>
                  <li>
                    <Link href="/docs/data-types" className="text-blue-600 hover:text-blue-800">
                      Tipos de Dados
                    </Link>
                  </li>
                  <li>
                    <Link href="/docs/control-structures" className="text-blue-600 hover:text-blue-800">
                      Estruturas de Controle
                    </Link>
                  </li>
                  <li>
                    <Link href="/docs/functions" className="text-blue-600 hover:text-blue-800">
                      Funções
                    </Link>
                  </li>
                  <li>
                    <Link href="/docs/modules" className="text-blue-600 hover:text-blue-800">
                      Módulos e Pacotes
                    </Link>
                  </li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 mb-3">Recursos Médicos</h4>
                <ul className="space-y-2 pl-4">
                  <li>
                    <Link href="/docs/medical-types" className="text-blue-600 hover:text-blue-800">
                      Tipos Específicos para Medicina
                    </Link>
                  </li>
                  <li>
                    <Link href="/docs/hospital-workflows" className="text-blue-600 hover:text-blue-800">
                      Workflows Hospitalares
                    </Link>
                  </li>
                  <li>
                    <Link href="/docs/prescription-system" className="text-blue-600 hover:text-blue-800">
                      Sistema de Prescrição
                    </Link>
                  </li>
                  <li>
                    <Link href="/docs/fhir-integration" className="text-blue-600 hover:text-blue-800">
                      Integração FHIR
                    </Link>
                  </li>
                  <li>
                    <Link href="/docs/security" className="text-blue-600 hover:text-blue-800">
                      Segurança e Privacidade
                    </Link>
                  </li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 mb-3">Ferramentas</h4>
                <ul className="space-y-2 pl-4">
                  <li>
                    <Link href="/docs/repl" className="text-blue-600 hover:text-blue-800">
                      Ambiente REPL
                    </Link>
                  </li>
                  <li>
                    <Link href="/docs/debugging" className="text-blue-600 hover:text-blue-800">
                      Depuração
                    </Link>
                  </li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 mb-3">Referência</h4>
                <ul className="space-y-2 pl-4">
                  <li>
                    <Link href="/docs/api" className="text-blue-600 hover:text-blue-800">
                      API
                    </Link>
                  </li>
                  <li>
                    <Link href="/docs/best-practices" className="text-blue-600 hover:text-blue-800">
                      Melhores Práticas
                    </Link>
                  </li>
                  <li>
                    <Link href="/docs/troubleshooting" className="text-blue-600 hover:text-blue-800">
                      Solução de Problemas
                    </Link>
                  </li>
                </ul>
              </div>
            </nav>
          </div>
        </div>
        
        {/* Main Content */}
        <div className="md:w-3/4">
          {children}
        </div>
      </div>
    </div>
  )
}
