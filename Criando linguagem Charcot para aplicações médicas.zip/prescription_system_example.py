#!/usr/bin/env python3
"""
Exemplo de Sistema de Prescrição Médica usando a Linguagem Charcot

Este exemplo demonstra a implementação de um sistema completo de prescrição médica
usando a linguagem Charcot, incluindo verificações de segurança, interações medicamentosas
e gerenciamento do ciclo de vida das prescrições.
"""

import os
import sys
import json
import datetime
from typing import Dict, List, Any, Optional

# Adicionar diretório de implementação ao path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Importar módulos da linguagem Charcot
from implementation.src.fhir_integration import FHIRClient, FHIRPatient, FHIRMedication, FHIRMedicationRequest
from implementation.src.prescription_system import (
    PrescriptionSystem, Patient, Medication, Prescriber, 
    Prescription, DosageSchedule, Dose, VerificationError
)
from implementation.src.hospital_workflow import HospitalWorkflow, Location, Encounter
from implementation.src.security import SecurityManager, DataProtection


def create_test_data():
    """
    Cria dados de teste para o sistema de prescrição.
    
    Returns:
        tuple: (prescription_system, patients, medications, prescribers)
    """
    # Criar sistema de prescrição
    prescription_system = PrescriptionSystem()
    
    # Criar pacientes
    patients = {}
    
    patients["P001"] = Patient(
        id="P001",
        name="João Silva",
        birth_date="1980-05-15",
        gender="male",
        weight=70.5,
        height=175,
        allergies=["penicillin"],
        conditions=["hypertension"]
    )
    
    patients["P002"] = Patient(
        id="P002",
        name="Maria Oliveira",
        birth_date="1975-10-20",
        gender="female",
        weight=65.0,
        height=160,
        allergies=["sulfa"],
        conditions=["diabetes", "asthma"]
    )
    
    patients["P003"] = Patient(
        id="P003",
        name="Carlos Santos",
        birth_date="1990-03-10",
        gender="male",
        weight=80.0,
        height=180,
        allergies=[],
        conditions=["peptic ulcer"]
    )
    
    # Adicionar pacientes ao sistema
    for patient in patients.values():
        prescription_system.add_patient(patient)
    
    # Criar medicamentos
    medications = {}
    
    medications["M001"] = Medication(
        id="M001",
        name="Paracetamol",
        active_ingredient="Acetaminophen",
        strength="500 mg",
        form="tablet",
        route="oral",
        atc_code="N02BE01",
        max_daily_dose="4000 mg"
    )
    
    medications["M002"] = Medication(
        id="M002",
        name="Ibuprofeno",
        active_ingredient="Ibuprofen",
        strength="400 mg",
        form="tablet",
        route="oral",
        atc_code="M01AE01",
        contraindications=["peptic ulcer", "asthma"],
        max_daily_dose="2400 mg",
        interactions={"Warfarin": "Aumenta o risco de sangramento"}
    )
    
    medications["M003"] = Medication(
        id="M003",
        name="Amoxicilina",
        active_ingredient="Amoxicillin",
        strength="500 mg",
        form="capsule",
        route="oral",
        atc_code="J01CA04",
        contraindications=["penicillin allergy"],
        max_daily_dose="3000 mg"
    )
    
    medications["M004"] = Medication(
        id="M004",
        name="Morfina",
        active_ingredient="Morphine",
        strength="10 mg",
        form="tablet",
        route="oral",
        atc_code="N02AA01",
        max_daily_dose="60 mg",
        controlled_substance=True
    )
    
    # Adicionar medicamentos ao sistema
    for medication in medications.values():
        prescription_system.add_medication(medication)
    
    # Criar prescritores
    prescribers = {}
    
    prescribers["DR001"] = Prescriber(
        id="DR001",
        name="Dra. Ana Pereira",
        license_number="CRM12345",
        specialty="Clínica Médica",
        prescribing_rights=["controlled_substances"]
    )
    
    prescribers["DR002"] = Prescriber(
        id="DR002",
        name="Dr. Roberto Almeida",
        license_number="CRM67890",
        specialty="Cardiologia",
        prescribing_rights=[]
    )
    
    prescribers["NR001"] = Prescriber(
        id="NR001",
        name="Enf. Juliana Costa",
        license_number="COREN54321",
        specialty="Enfermagem",
        prescribing_rights=[]
    )
    
    # Adicionar prescritores ao sistema
    for prescriber in prescribers.values():
        prescription_system.add_prescriber(prescriber)
    
    return prescription_system, patients, medications, prescribers


def create_prescriptions(prescription_system, patients, medications, prescribers):
    """
    Cria prescrições de exemplo e demonstra verificações de segurança.
    
    Args:
        prescription_system (PrescriptionSystem): Sistema de prescrição
        patients (Dict[str, Patient]): Dicionário de pacientes
        medications (Dict[str, Medication]): Dicionário de medicamentos
        prescribers (Dict[str, Prescriber]): Dicionário de prescritores
        
    Returns:
        Dict[str, Prescription]: Dicionário de prescrições criadas
    """
    prescriptions = {}
    
    print("\n=== Criando Prescrições ===")
    
    # Prescrição 1: Paracetamol para João Silva (deve ser segura)
    try:
        dosage_schedule = DosageSchedule(
            dose=Dose(500, "mg"),
            frequency="every 6 hours",
            duration=5,
            as_needed=True,
            timing_description="after meals"
        )
        
        prescription_id = prescription_system.create_prescription(
            patient_id="P001",
            prescriber_id="DR001",
            medication_id="M001",
            dosage_schedule=dosage_schedule,
            instructions="Take with water for pain relief",
            duration=5,
            refills=0
        )
        
        prescription = prescription_system.get_prescription(prescription_id)
        prescriptions[prescription_id] = prescription
        
        print(f"Prescrição 1 criada com sucesso. ID: {prescription_id}")
        print(f"  Paciente: {patients['P001'].name}")
        print(f"  Medicamento: {medications['M001'].name} {medications['M001'].strength}")
        print(f"  Dose: {dosage_schedule.dose} {dosage_schedule.frequency}")
        print(f"  Status de verificação: {prescription.verification_status}")
        print(f"  Notas: {prescription.verification_notes}")
        
    except (ValueError, VerificationError) as e:
        print(f"Erro ao criar prescrição 1: {e}")
    
    # Prescrição 2: Amoxicilina para João Silva (deve falhar - alergia a penicilina)
    try:
        dosage_schedule = DosageSchedule(
            dose=Dose(500, "mg"),
            frequency="every 8 hours",
            duration=7
        )
        
        prescription_id = prescription_system.create_prescription(
            patient_id="P001",
            prescriber_id="DR001",
            medication_id="M003",  # Amoxicilina (paciente alérgico a penicilina)
            dosage_schedule=dosage_schedule,
            instructions="Take with food for infection",
            duration=7,
            refills=0
        )
        
        prescription = prescription_system.get_prescription(prescription_id)
        prescriptions[prescription_id] = prescription
        
        print(f"Prescrição 2 criada com sucesso. ID: {prescription_id}")
        
    except (ValueError, VerificationError) as e:
        print(f"Erro ao criar prescrição 2: {e}")
    
    # Prescrição 3: Ibuprofeno para Maria Oliveira (deve falhar - paciente tem asma)
    try:
        dosage_schedule = DosageSchedule(
            dose=Dose(400, "mg"),
            frequency="every 8 hours",
            duration=5
        )
        
        prescription_id = prescription_system.create_prescription(
            patient_id="P002",
            prescriber_id="DR001",
            medication_id="M002",  # Ibuprofeno (contraindicado para asma)
            dosage_schedule=dosage_schedule,
            instructions="Take with food for pain and inflammation",
            duration=5,
            refills=0
        )
        
        prescription = prescription_system.get_prescription(prescription_id)
        prescriptions[prescription_id] = prescription
        
        print(f"Prescrição 3 criada com sucesso. ID: {prescription_id}")
        
    except (ValueError, VerificationError) as e:
        print(f"Erro ao criar prescrição 3: {e}")
    
    # Prescrição 4: Ibuprofeno para Carlos Santos (deve falhar - paciente tem úlcera péptica)
    try:
        dosage_schedule = DosageSchedule(
            dose=Dose(400, "mg"),
            frequency="every 8 hours",
            duration=5
        )
        
        prescription_id = prescription_system.create_prescription(
            patient_id="P003",
            prescriber_id="DR001",
            medication_id="M002",  # Ibuprofeno (contraindicado para úlcera péptica)
            dosage_schedule=dosage_schedule,
            instructions="Take with food for pain and inflammation",
            duration=5,
            refills=0
        )
        
        prescription = prescription_system.get_prescription(prescription_id)
        prescriptions[prescription_id] = prescription
        
        print(f"Prescrição 4 criada com sucesso. ID: {prescription_id}")
        
    except (ValueError, VerificationError) as e:
        print(f"Erro ao criar prescrição 4: {e}")
    
    # Prescrição 5: Morfina para Carlos Santos por Dr. Roberto (deve falhar - sem direitos para substâncias controladas)
    try:
        dosage_schedule = DosageSchedule(
            dose=Dose(10, "mg"),
            frequency="every 12 hours",
            duration=3
        )
        
        prescription_id = prescription_system.create_prescription(
            patient_id="P003",
            prescriber_id="DR002",  # Dr. Roberto (sem direitos para substâncias controladas)
            medication_id="M004",  # Morfina (substância controlada)
            dosage_schedule=dosage_schedule,
            instructions="Take for severe pain",
            duration=3,
            refills=0
        )
        
        prescription = prescription_system.get_prescription(prescription_id)
        prescriptions[prescription_id] = prescription
        
        print(f"Prescrição 5 criada com sucesso. ID: {prescription_id}")
        
    except (ValueError, VerificationError) as e:
        print(f"Erro ao criar prescrição 5: {e}")
    
    # Prescrição 6: Morfina para Carlos Santos por Dra. Ana (deve ser segura)
    try:
        dosage_schedule = DosageSchedule(
            dose=Dose(10, "mg"),
            frequency="every 12 hours",
            duration=3
        )
        
        prescription_id = prescription_system.create_prescription(
            patient_id="P003",
            prescriber_id="DR001",  # Dra. Ana (com direitos para substâncias controladas)
            medication_id="M004",  # Morfina (substância controlada)
            dosage_schedule=dosage_schedule,
            instructions="Take for severe pain",
            duration=3,
            refills=0
        )
        
        prescription = prescription_system.get_prescription(prescription_id)
        prescriptions[prescription_id] = prescription
        
        print(f"Prescrição 6 criada com sucesso. ID: {prescription_id}")
        print(f"  Paciente: {patients['P003'].name}")
        print(f"  Medicamento: {medications['M004'].name} {medications['M004'].strength}")
        print(f"  Dose: {dosage_schedule.dose} {dosage_schedule.frequency}")
        print(f"  Status de verificação: {prescription.verification_status}")
        print(f"  Notas: {prescription.verification_notes}")
        
    except (ValueError, VerificationError) as e:
        print(f"Erro ao criar prescrição 6: {e}")
    
    return prescriptions


def manage_prescription_lifecycle(prescription_system, prescriptions):
    """
    Demonstra o gerenciamento do ciclo de vida das prescrições.
    
    Args:
        prescription_system (PrescriptionSystem): Sistema de prescrição
        prescriptions (Dict[str, Prescription]): Dicionário de prescrições
    """
    if not prescriptions:
        print("\n=== Nenhuma prescrição para gerenciar ===")
        return
    
    print("\n=== Gerenciando Ciclo de Vida das Prescrições ===")
    
    # Obter IDs das prescrições ativas
    active_prescriptions = [p_id for p_id, p in prescriptions.items() if p.status == "active"]
    
    if not active_prescriptions:
        print("Nenhuma prescrição ativa para gerenciar.")
        return
    
    # Selecionar a primeira prescrição ativa
    prescription_id = active_prescriptions[0]
    prescription = prescriptions[prescription_id]
    
    print(f"Gerenciando prescrição: {prescription_id}")
    print(f"  Status atual: {prescription.status}")
    
    # Cancelar prescrição
    if len(active_prescriptions) > 1:
        cancel_id = active_prescriptions[1]
        try:
            success = prescription_system.cancel_prescription(
                prescription_id=cancel_id,
                reason="Medicamento substituído por alternativa mais adequada"
            )
            
            if success:
                print(f"Prescrição {cancel_id} cancelada com sucesso.")
                # Atualizar prescrição no dicionário local
                prescriptions[cancel_id] = prescription_system.get_prescription(cancel_id)
            else:
                print(f"Falha ao cancelar prescrição {cancel_id}.")
        
        except ValueError as e:
            print(f"Erro ao cancelar prescrição: {e}")
    
    # Completar prescrição
    try:
        success = prescription_system.complete_prescription(prescription_id)
        
        if success:
            print(f"Prescrição {prescription_id} marcada como concluída.")
            # Atualizar prescrição no dicionário local
            prescriptions[prescription_id] = prescription_system.get_prescription(prescription_id)
        else:
            print(f"Falha ao completar prescrição {prescription_id}.")
    
    except ValueError as e:
        print(f"Erro ao completar prescrição: {e}")
    
    # Renovar prescrição
    try:
        new_prescription_id = prescription_system.renew_prescription(
            prescription_id=prescription_id,
            duration=10,  # Nova duração
            refills=1     # Permitir uma recarga
        )
        
        print(f"Prescrição renovada com sucesso. Novo ID: {new_prescription_id}")
        # Adicionar nova prescrição ao dicionário local
        prescriptions[new_prescription_id] = prescription_system.get_prescription(new_prescription_id)
    
    except (ValueError, VerificationError) as e:
        print(f"Erro ao renovar prescrição: {e}")
    
    # Exibir status final das prescrições
    print("\nStatus final das prescrições:")
    for p_id, p in prescriptions.items():
        print(f"  {p_id}: {p.status}")


def integrate_with_hospital_workflow(prescription_system, patients, medications, prescriptions):
    """
    Demonstra a integração do sistema de prescrição com workflows hospitalares.
    
    Args:
        prescription_system (PrescriptionSystem): Sistema de prescrição
        patients (Dict[str, Patient]): Dicionário de pacientes
        medications (Dict[str, Medication]): Dicionário de medicamentos
        prescriptions (Dict[str, Prescription]): Dicionário de prescrições
    """
    print("\n=== Integrando com Workflows Hospitalares ===")
    
    # Criar gerenciador de workflows
    workflow = HospitalWorkflow()
    
    # Adicionar pacientes ao workflow
    for patient in patients.values():
        workflow_patient = Patient(
            id=patient.id,
            name=patient.name,
            birth_date=patient.birth_date,
            gender=patient.gender,
            allergies=patient.allergies,
            conditions=patient.conditions
        )
        workflow.add_patient(workflow_patient)
    
   
(Content truncated due to size limit. Use line ranges to read in chunks)