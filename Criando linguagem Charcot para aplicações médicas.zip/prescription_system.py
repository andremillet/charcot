#!/usr/bin/env python3
"""
Módulo de Sistema de Prescrição Médica para a Linguagem Charcot

Este módulo implementa um sistema de prescrição médica para a linguagem Charcot,
permitindo a criação, validação e gerenciamento de prescrições médicas com verificações
de segurança automáticas.
"""

from typing import Dict, List, Any, Optional, Union, Callable, Set, Tuple
from dataclasses import dataclass, field
import datetime
import uuid
import json
import re

from implementation.src.fhir_integration import FHIRClient, FHIRMedicationRequest, FHIRReference, FHIRQuantity


@dataclass
class Medication:
    """Representa um medicamento no sistema de prescrição."""
    id: str
    name: str
    active_ingredient: str
    strength: str  # Ex: "500 mg", "10 mg/ml"
    form: str  # Ex: "tablet", "solution", "capsule"
    route: str  # Ex: "oral", "intravenous", "topical"
    atc_code: Optional[str] = None  # Código ATC (Anatomical Therapeutic Chemical)
    contraindications: List[str] = field(default_factory=list)
    interactions: Dict[str, str] = field(default_factory=dict)  # Medicamento -> descrição da interação
    max_daily_dose: Optional[str] = None
    requires_prescription: bool = True
    controlled_substance: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte o medicamento para um dicionário."""
        return {
            "id": self.id,
            "name": self.name,
            "active_ingredient": self.active_ingredient,
            "strength": self.strength,
            "form": self.form,
            "route": self.route,
            "atc_code": self.atc_code,
            "contraindications": self.contraindications,
            "interactions": self.interactions,
            "max_daily_dose": self.max_daily_dose,
            "requires_prescription": self.requires_prescription,
            "controlled_substance": self.controlled_substance
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Medication':
        """Cria um medicamento a partir de um dicionário."""
        return cls(
            id=data["id"],
            name=data["name"],
            active_ingredient=data["active_ingredient"],
            strength=data["strength"],
            form=data["form"],
            route=data["route"],
            atc_code=data.get("atc_code"),
            contraindications=data.get("contraindications", []),
            interactions=data.get("interactions", {}),
            max_daily_dose=data.get("max_daily_dose"),
            requires_prescription=data.get("requires_prescription", True),
            controlled_substance=data.get("controlled_substance", False)
        )


@dataclass
class Dose:
    """Representa uma dose de medicamento."""
    value: float
    unit: str  # Ex: "mg", "ml", "tablet"
    
    def __str__(self) -> str:
        """Retorna a representação em string da dose."""
        return f"{self.value} {self.unit}"
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte a dose para um dicionário."""
        return {
            "value": self.value,
            "unit": self.unit
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Dose':
        """Cria uma dose a partir de um dicionário."""
        return cls(
            value=data["value"],
            unit=data["unit"]
        )
    
    @classmethod
    def from_string(cls, dose_str: str) -> 'Dose':
        """Cria uma dose a partir de uma string."""
        match = re.match(r"(\d+(?:\.\d+)?)\s*(\w+)", dose_str.strip())
        if not match:
            raise ValueError(f"Formato de dose inválido: {dose_str}")
        
        value = float(match.group(1))
        unit = match.group(2)
        
        return cls(value=value, unit=unit)


@dataclass
class DosageSchedule:
    """Representa um esquema de dosagem."""
    dose: Dose
    frequency: str  # Ex: "once daily", "twice daily", "every 8 hours"
    duration: Optional[int] = None  # Duração em dias
    as_needed: bool = False
    timing_description: Optional[str] = None  # Ex: "before meals", "at bedtime"
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte o esquema de dosagem para um dicionário."""
        return {
            "dose": self.dose.to_dict(),
            "frequency": self.frequency,
            "duration": self.duration,
            "as_needed": self.as_needed,
            "timing_description": self.timing_description
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DosageSchedule':
        """Cria um esquema de dosagem a partir de um dicionário."""
        return cls(
            dose=Dose.from_dict(data["dose"]),
            frequency=data["frequency"],
            duration=data.get("duration"),
            as_needed=data.get("as_needed", False),
            timing_description=data.get("timing_description")
        )


@dataclass
class Prescription:
    """Representa uma prescrição médica."""
    id: str
    patient_id: str
    prescriber_id: str
    medication_id: str
    dosage_schedule: DosageSchedule
    instructions: str
    date_written: str
    start_date: str
    end_date: Optional[str] = None
    status: str = "active"  # active, completed, cancelled, suspended
    refills: int = 0
    dispense_amount: Optional[int] = None
    pharmacy_notes: Optional[str] = None
    verification_status: str = "unverified"  # unverified, verified, rejected
    verification_notes: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte a prescrição para um dicionário."""
        return {
            "id": self.id,
            "patient_id": self.patient_id,
            "prescriber_id": self.prescriber_id,
            "medication_id": self.medication_id,
            "dosage_schedule": self.dosage_schedule.to_dict(),
            "instructions": self.instructions,
            "date_written": self.date_written,
            "start_date": self.start_date,
            "end_date": self.end_date,
            "status": self.status,
            "refills": self.refills,
            "dispense_amount": self.dispense_amount,
            "pharmacy_notes": self.pharmacy_notes,
            "verification_status": self.verification_status,
            "verification_notes": self.verification_notes
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Prescription':
        """Cria uma prescrição a partir de um dicionário."""
        return cls(
            id=data["id"],
            patient_id=data["patient_id"],
            prescriber_id=data["prescriber_id"],
            medication_id=data["medication_id"],
            dosage_schedule=DosageSchedule.from_dict(data["dosage_schedule"]),
            instructions=data["instructions"],
            date_written=data["date_written"],
            start_date=data["start_date"],
            end_date=data.get("end_date"),
            status=data.get("status", "active"),
            refills=data.get("refills", 0),
            dispense_amount=data.get("dispense_amount"),
            pharmacy_notes=data.get("pharmacy_notes"),
            verification_status=data.get("verification_status", "unverified"),
            verification_notes=data.get("verification_notes")
        )


@dataclass
class Patient:
    """Representa um paciente no sistema de prescrição."""
    id: str
    name: str
    birth_date: str
    gender: str
    weight: Optional[float] = None  # em kg
    height: Optional[float] = None  # em cm
    allergies: List[str] = field(default_factory=list)
    conditions: List[str] = field(default_factory=list)
    active_medications: List[str] = field(default_factory=list)  # IDs de prescrições ativas
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte o paciente para um dicionário."""
        return {
            "id": self.id,
            "name": self.name,
            "birth_date": self.birth_date,
            "gender": self.gender,
            "weight": self.weight,
            "height": self.height,
            "allergies": self.allergies,
            "conditions": self.conditions,
            "active_medications": self.active_medications
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Patient':
        """Cria um paciente a partir de um dicionário."""
        return cls(
            id=data["id"],
            name=data["name"],
            birth_date=data["birth_date"],
            gender=data["gender"],
            weight=data.get("weight"),
            height=data.get("height"),
            allergies=data.get("allergies", []),
            conditions=data.get("conditions", []),
            active_medications=data.get("active_medications", [])
        )
    
    def calculate_bmi(self) -> Optional[float]:
        """Calcula o IMC (Índice de Massa Corporal) do paciente."""
        if self.weight is None or self.height is None:
            return None
        
        # IMC = peso (kg) / (altura (m))²
        height_m = self.height / 100  # Converter cm para m
        bmi = self.weight / (height_m * height_m)
        return round(bmi, 1)
    
    def calculate_age(self) -> int:
        """Calcula a idade do paciente."""
        birth_date = datetime.datetime.fromisoformat(self.birth_date.replace('Z', '+00:00'))
        today = datetime.datetime.now()
        age = today.year - birth_date.year
        
        # Ajustar se o aniversário deste ano ainda não ocorreu
        if (today.month, today.day) < (birth_date.month, birth_date.day):
            age -= 1
        
        return age


@dataclass
class Prescriber:
    """Representa um prescritor (médico, enfermeiro) no sistema."""
    id: str
    name: str
    license_number: str
    specialty: Optional[str] = None
    prescribing_rights: List[str] = field(default_factory=list)  # Tipos de medicamentos que pode prescrever
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte o prescritor para um dicionário."""
        return {
            "id": self.id,
            "name": self.name,
            "license_number": self.license_number,
            "specialty": self.specialty,
            "prescribing_rights": self.prescribing_rights
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Prescriber':
        """Cria um prescritor a partir de um dicionário."""
        return cls(
            id=data["id"],
            name=data["name"],
            license_number=data["license_number"],
            specialty=data.get("specialty"),
            prescribing_rights=data.get("prescribing_rights", [])
        )


class VerificationError(Exception):
    """Exceção lançada quando uma verificação de prescrição falha."""
    pass


class PrescriptionSystem:
    """Sistema de prescrição médica."""
    
    def __init__(self, fhir_client: Optional[FHIRClient] = None):
        """
        Inicializa o sistema de prescrição.
        
        Args:
            fhir_client (Optional[FHIRClient]): Cliente FHIR para integração com sistemas externos.
        """
        self.medications: Dict[str, Medication] = {}
        self.patients: Dict[str, Patient] = {}
        self.prescribers: Dict[str, Prescriber] = {}
        self.prescriptions: Dict[str, Prescription] = {}
        self.fhir_client = fhir_client
        
        # Registrar verificações de segurança
        self.safety_checks: List[Callable[[Prescription, Patient, Medication, Prescriber], Optional[str]]] = [
            self._check_allergies,
            self._check_interactions,
            self._check_contraindications,
            self._check_dose,
            self._check_prescribing_rights,
            self._check_controlled_substance
        ]
    
    def add_medication(self, medication: Medication) -> None:
        """
        Adiciona um medicamento ao sistema.
        
        Args:
            medication (Medication): O medicamento a ser adicionado.
        """
        self.medications[medication.id] = medication
    
    def add_patient(self, patient: Patient) -> None:
        """
        Adiciona um paciente ao sistema.
        
        Args:
            patient (Patient): O paciente a ser adicionado.
        """
        self.patients[patient.id] = patient
    
    def add_prescriber(self, prescriber: Prescriber) -> None:
        """
        Adiciona um prescritor ao sistema.
        
        Args:
            prescriber (Prescriber): O prescritor a ser adicionado.
        """
        self.prescribers[prescriber.id] = prescriber
    
    def create_prescription(self, patient_id: str, prescriber_id: str, medication_id: str,
                           dosage_schedule: DosageSchedule, instructions: str,
                           start_date: Optional[str] = None, duration: Optional[int] = None,
                           refills: int = 0, dispense_amount: Optional[int] = None,
                           pharmacy_notes: Optional[str] = None) -> str:
        """
        Cria uma nova prescrição.
        
        Args:
            patient_id (str): ID do paciente.
            prescriber_id (str): ID do prescritor.
            medication_id (str): ID do medicamento.
            dosage_schedule (DosageSchedule): Esquema de dosagem.
            instructions (str): Instruções para o paciente.
            start_date (Optional[str]): Data de início (formato ISO). Se None, usa a data atual.
            duration (Optional[int]): Duração em dias. Se fornecido, calcula a data de término.
            refills (int): Número de recargas permitidas.
            dispense_amount (Optional[int]): Quantidade a ser dispensada.
            pharmacy_notes (Optional[str]): Notas para a farmácia.
            
        Returns:
            str: ID da prescrição criada.
            
        Raises:
            ValueError: Se o paciente, prescritor ou medicamento não existirem.
            VerificationError: Se a prescrição falhar nas verificações de segurança.
        """
        # Verificar se o paciente, prescritor e medicamento existem
        if patient_id not in self.patients:
            raise ValueError(f"Paciente com ID {patient_id} não encontrado.")
        
        if prescriber_id not in self.prescribers:
            raise ValueError(f"Prescritor com ID {prescriber_id} não encontrado.")
        
        if medication_id not in self.medications:
            raise ValueError(f"Medicamento com ID {medication_id} não encontrado.")
        
        # Obter objetos
        patient = self.patients[patient_id]
        prescriber = self.prescribers[prescriber_id]
        medication = self.medications[medication_id]
        
        # Definir datas
        date_written = datetime.datetime.now().isoformat()
        
        if start_date is None:
            start_date = date_written
        
        end_date = None
        if duration is not None:
            start_datetime = datetime.datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            end_datetime = start_datetime + datetime.timedelta(days=duration)
            end_date = end_datetime.isoformat()
        
        # Criar prescrição
        prescription_id = str(uuid.uuid4())
        
        prescription = Prescription(
            id=prescription_id,
            patient_id=patient_id,
            prescriber_id=prescriber_id,
            medication_id=medication_id,
            dosage_schedule=dosage_schedule,
            instructions=instructions,
            date_written=date_written,
            start_date=start_date,
            end_date=end_date,
            status="active",
            refills=refills,
            dispense_amount=dispense_amount,
            pharmacy_notes=pharmacy_notes,
            verification_status="unverified"
        )
        
        # Verificar segurança da prescrição
        verification_result = self.verify_prescription(prescription)
        
        if verification_result["status"] == "rejected":
            raise VerificationError(verification_result["notes"])
        
        # Atualizar pres
(Content truncated due to size limit. Use line ranges to read in chunks)