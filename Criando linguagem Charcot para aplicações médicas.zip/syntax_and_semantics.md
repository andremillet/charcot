# Sintaxe e Semântica da Linguagem Charcot

## 1. Visão Geral da Sintaxe

A linguagem Charcot adota uma sintaxe inspirada em Python para facilidade de aprendizado, mas incorpora conceitos de segurança de Rust e adiciona elementos específicos para o domínio médico. A sintaxe é projetada para ser intuitiva, expressiva e segura.

## 2. Estrutura Básica

### 2.1 Identificadores e Palavras-chave

Os identificadores em Charcot seguem regras similares a Python:
- Começam com letra ou underscore
- Podem conter letras, números e underscore
- São case-sensitive

```charcot
# Identificadores válidos
paciente = "João Silva"
_registro_medico = 12345
doseMedicamento = 500
```

Palavras-chave reservadas incluem:

```
if      else    elif    while   for     in      break   continue
return  fn      struct  enum    match   let     mut     const
type    import  from    as      try     catch   raise   with
patient medication dose  admit  transfer discharge
```

Observe que algumas palavras-chave são específicas do domínio médico (`patient`, `medication`, `dose`, `admit`, `transfer`, `discharge`).

### 2.2 Comentários

Comentários de linha única começam com `#`:

```charcot
# Este é um comentário de linha única
idade = 45  # Comentário no final da linha
```

Comentários de múltiplas linhas usam `#[` e `]#`:

```charcot
#[
  Este é um comentário
  de múltiplas linhas
  que pode conter informações detalhadas
]#
```

Comentários de documentação usam `##`:

```charcot
## Calcula a dose de medicamento baseada no peso do paciente
## Parâmetros:
##   peso: Peso do paciente em kg
##   medicamento: Identificador do medicamento
## Retorna:
##   Dose recomendada em mg
fn calcular_dose(peso: float, medicamento: Medication) -> Dose {
    # Implementação
}
```

### 2.3 Indentação e Blocos

Assim como Python, Charcot usa indentação para definir blocos de código:

```charcot
if idade > 65:
    categoria = "Idoso"
    risco = avaliar_risco_idoso(paciente)
else:
    categoria = "Adulto"
    risco = avaliar_risco_padrao(paciente)
```

## 3. Tipos de Dados

### 3.1 Tipos Primitivos

```charcot
# Tipos numéricos
inteiro: int = 42
real: float = 37.5
complexo: complex = 3 + 4i

# Texto
nome: str = "Maria Oliveira"

# Booleano
ativo: bool = true

# Data e hora (tipos específicos para medicina)
data_nascimento: Date = Date(1980, 5, 15)
hora_medicacao: Time = Time(8, 30)
consulta: DateTime = DateTime(2025, 4, 10, 14, 30)
```

### 3.2 Tipos Compostos

```charcot
# Listas (mutáveis)
medicamentos: list[str] = ["Paracetamol", "Ibuprofeno", "Dipirona"]

# Tuplas (imutáveis)
coordenadas: tuple[float, float] = (23.5, 46.7)

# Dicionários
parametros_vitais: dict[str, float] = {
    "temperatura": 36.8,
    "pressao_sistolica": 120,
    "pressao_diastolica": 80,
    "frequencia_cardiaca": 72
}

# Conjuntos
alergias: set[str] = {"Penicilina", "Sulfas", "Aspirina"}
```

### 3.3 Tipos Específicos para Medicina

```charcot
# Paciente
paciente: Patient = Patient {
    id: "P12345",
    nome: "João Silva",
    data_nascimento: Date(1975, 3, 21),
    sexo: Sexo.Masculino
}

# Medicamento
medicamento: Medication = Medication {
    id: "M789",
    nome: "Losartana",
    concentracao: Dose(50, "mg"),
    forma: FormaFarmaceutica.Comprimido
}

# Prescrição
prescricao: Prescription = Prescription {
    paciente: paciente,
    medicamento: medicamento,
    dose: Dose(50, "mg"),
    frequencia: "12/12h",
    duracao: Duration(7, "dias")
}

# Sinais vitais
sinais: VitalSigns = VitalSigns {
    temperatura: Temperature(36.8, "C"),
    pressao_arterial: BloodPressure(120, 80, "mmHg"),
    frequencia_cardiaca: HeartRate(72, "bpm"),
    saturacao: OxygenSaturation(98, "%")
}
```

### 3.4 Tipos Opcionais e Resultados

Charcot usa tipos `Option<T>` e `Result<T, E>` inspirados em Rust para lidar com valores opcionais e operações que podem falhar:

```charcot
# Valor opcional (pode ser None)
alergia_medicamento: Option<str> = None

# Resultado de operação que pode falhar
resultado_exame: Result<ExameResultado, ExameErro> = laboratorio.realizar_exame(paciente, "glicemia")

# Verificando valores opcionais
if alergia_medicamento.is_some():
    print(f"Paciente alérgico a {alergia_medicamento.unwrap()}")

# Tratando resultados
match resultado_exame:
    Ok(resultado) => {
        print(f"Glicemia: {resultado.valor} {resultado.unidade}")
    }
    Err(erro) => {
        print(f"Erro ao realizar exame: {erro.mensagem}")
    }
```

## 4. Declarações e Atribuições

### 4.1 Declaração de Variáveis

Charcot usa inferência de tipos, mas também permite declarações explícitas:

```charcot
# Inferência de tipo
idade = 45  # int inferido

# Declaração explícita
nome: str = "Carlos Ferreira"

# Constantes (imutáveis)
const TEMPERATURA_NORMAL: float = 36.5

# Variáveis mutáveis (explícitas)
mut contagem_leucocitos: int = 7500
contagem_leucocitos = 8000  # OK, variável é mutável

# Variáveis imutáveis (padrão)
pressao_arterial: BloodPressure = BloodPressure(120, 80, "mmHg")
pressao_arterial.sistolica = 125  # Erro! Variável é imutável por padrão
```

### 4.2 Operadores

```charcot
# Operadores aritméticos
soma = 5 + 3
diferenca = 10 - 4
produto = 6 * 7
quociente = 20 / 4
resto = 10 % 3
potencia = 2 ** 3

# Operadores de comparação
maior = 5 > 3
menor = 2 < 7
igual = 4 == 4
diferente = 5 != 3
maior_igual = 6 >= 6
menor_igual = 8 <= 10

# Operadores lógicos
e = true and false
ou = true or false
nao = not false

# Operadores de atribuição composta
mut contador = 0
contador += 1  # contador = contador + 1
contador *= 2  # contador = contador * 2
```

## 5. Estruturas de Controle

### 5.1 Condicionais

```charcot
# If-elif-else
if temperatura > 37.5:
    diagnostico = "Febre"
elif temperatura < 35.5:
    diagnostico = "Hipotermia"
else:
    diagnostico = "Normal"

# Expressão condicional (ternário)
estado = "Crítico" if pressao_sistolica < 90 else "Estável"

# Match (pattern matching)
match resultado_exame:
    "Normal" => {
        print("Exame dentro dos parâmetros normais")
    }
    "Alterado" => {
        print("Exame com alterações")
        notificar_medico(paciente, resultado_exame)
    }
    _ => {
        print("Resultado indeterminado")
    }
```

### 5.2 Loops

```charcot
# Loop for
for medicamento in prescricao.medicamentos:
    print(f"Administrar {medicamento.nome} {medicamento.dose}")

# Loop for com range
for i in range(1, 4):
    print(f"Dose {i} de {medicamento.nome}")

# Loop while
mut tentativas = 0
while tentativas < 3 and not conectado_ao_servidor:
    tentativas += 1
    conectado_ao_servidor = tentar_conexao()

# Loop com break e continue
for paciente in enfermaria.pacientes:
    if paciente.alta_medica:
        continue  # Pula para o próximo paciente
    
    if paciente.sinais_vitais.temperatura > 38:
        notificar_enfermagem(paciente)
        break  # Interrompe o loop
```

### 5.3 Tratamento de Erros

```charcot
# Try-catch para tratamento de exceções
try:
    resultado = calcular_dose(paciente, medicamento)
catch DoseInvalidaError as e:
    print(f"Erro ao calcular dose: {e.message}")
    registrar_erro(e)
catch:
    print("Erro desconhecido")
finally:
    print("Finalizando cálculo")

# Usando Result para tratamento de erros
resultado = calcular_dose_segura(paciente, medicamento)
if resultado.is_ok():
    dose = resultado.unwrap()
    administrar_medicamento(paciente, medicamento, dose)
else:
    erro = resultado.unwrap_err()
    registrar_erro(erro)
```

## 6. Funções e Procedimentos

### 6.1 Definição de Funções

```charcot
# Função básica
fn calcular_imc(peso: float, altura: float) -> float:
    return peso / (altura ** 2)

# Função com tipo de retorno inferido
fn esta_febril(temperatura: float):
    return temperatura > 37.5

# Função com parâmetros opcionais
fn calcular_dose_pediatrica(peso: float, idade: int, superficie_corporal: float = None) -> Dose:
    if superficie_corporal is None:
        superficie_corporal = calcular_superficie_corporal(peso, altura)
    
    # Cálculo baseado em superfície corporal
    return Dose(superficie_corporal * 50, "mg")

# Função com número variável de parâmetros
fn registrar_sintomas(paciente: Patient, *sintomas: str) -> MedicalRecord:
    registro = MedicalRecord.new(paciente)
    for sintoma in sintomas:
        registro.adicionar_sintoma(sintoma)
    return registro
```

### 6.2 Funções de Ordem Superior

```charcot
# Função como parâmetro
fn aplicar_protocolo(paciente: Patient, protocolo: fn(Patient) -> Treatment) -> Treatment:
    return protocolo(paciente)

# Função anônima (lambda)
calcular_risco = |idade: int, comorbidades: list[str]| -> float {
    risco_base = idade / 10
    return risco_base + (len(comorbidades) * 1.5)
}

# Função retornando função
fn criar_calculadora_dose(medicamento: Medication) -> fn(float) -> Dose:
    if medicamento.categoria == "Antibiótico":
        return |peso: float| -> Dose { return Dose(peso * 0.05, "mg") }
    elif medicamento.categoria == "Analgésico":
        return |peso: float| -> Dose { return Dose(peso * 0.1, "mg") }
    else:
        return |peso: float| -> Dose { return Dose(medicamento.dose_padrao, "mg") }
```

### 6.3 Procedimentos Médicos

Charcot introduz uma sintaxe especial para procedimentos médicos:

```charcot
# Definição de procedimento médico
procedure administrar_medicacao(paciente: Patient, medicamento: Medication, dose: Dose):
    # Verificações de segurança automáticas
    verify paciente.alergias does not contain medicamento.substancia
    verify dose is within medicamento.dose_range
    
    # Implementação
    registro = MedicationAdministration.new(
        paciente: paciente,
        medicamento: medicamento,
        dose: dose,
        via: medicamento.via_padrao,
        data_hora: DateTime.now()
    )
    
    # Registro automático de auditoria
    audit "Medicação administrada" {
        paciente: paciente.id,
        medicamento: medicamento.id,
        dose: dose.to_string(),
        responsavel: current_user.id
    }
    
    return registro

# Chamada de procedimento
resultado = administrar_medicacao(paciente, paracetamol, Dose(500, "mg"))
```

## 7. Estruturas de Dados

### 7.1 Structs

```charcot
# Definição de struct
struct Paciente:
    id: str
    nome: str
    data_nascimento: Date
    sexo: Sexo
    alergias: set[str] = set()  # Valor padrão
    
    # Método construtor
    fn new(id: str, nome: str, data_nascimento: Date, sexo: Sexo) -> Self:
        return Paciente {
            id: id,
            nome: nome,
            data_nascimento: data_nascimento,
            sexo: sexo,
            alergias: set()
        }
    
    # Método de instância
    fn idade(self) -> int:
        hoje = Date.today()
        return hoje.year - self.data_nascimento.year - (
            1 if (hoje.month, hoje.day) < (self.data_nascimento.month, self.data_nascimento.day) else 0
        )
    
    # Método que modifica o estado
    fn adicionar_alergia(mut self, alergia: str):
        self.alergias.add(alergia)

# Criação e uso de struct
paciente = Paciente {
    id: "P12345",
    nome: "Ana Santos",
    data_nascimento: Date(1990, 8, 12),
    sexo: Sexo.Feminino
}

idade_atual = paciente.idade()
paciente.adicionar_alergia("Penicilina")
```

### 7.2 Enums

```charcot
# Enum simples
enum Sexo:
    Masculino
    Feminino
    Outro

# Enum com valores associados
enum ResultadoExame:
    Normal
    Alterado(str)  # Com descrição da alteração
    Critico(str, float)  # Com descrição e valor
    Indeterminado

# Uso de enum
resultado = ResultadoExame.Alterado("Leucocitose leve")

# Pattern matching com enum
match resultado:
    Normal => {
        print("Exame normal")
    }
    Alterado(descricao) => {
        print(f"Exame alterado: {descricao}")
    }
    Critico(descricao, valor) => {
        print(f"Exame crítico: {descricao}, valor: {valor}")
        notificar_medico_plantao(paciente, resultado)
    }
    Indeterminado => {
        print("Resultado indeterminado")
        solicitar_novo_exame(paciente, tipo_exame)
    }
```

### 7.3 Traits (Interfaces)

```charcot
# Definição de trait
trait Tratavel:
    fn iniciar_tratamento(self, medicamentos: list[Medication]) -> Treatment
    fn avaliar_resposta(self, tratamento: Treatment) -> ResultadoTratamento

# Implementação de trait
impl Tratavel for Paciente:
    fn iniciar_tratamento(self, medicamentos: list[Medication]) -> Treatment:
        tratamento = Treatment.new(self, medicamentos)
        hospital.registrar_tratamento(tratamento)
        return tratamento
    
    fn avaliar_resposta(self, tratamento: Treatment) -> ResultadoTratamento:
        # Implementação da avaliação
        if self.sintomas.is_empty():
            return ResultadoTratamento.Sucesso
        else:
            return ResultadoTratamento.Parcial(self.sintomas)
```

## 8. Sistema de Módulos

### 8.1 Importação de Módulos

```charcot
# Importação básica
import fhir

# Importação de componentes específicos
from medicamentos import Antibiotico, Analgesico

# Importação com alias
import protocolos.oncologia as onco

# Importação de todos os componentes
from util.formatacao import *
```

### 8.2 Definição de Módulos

```charcot
# Arquivo: prescricao.ch
module prescricao:
    # Exporta estes símbolos
    export Prescricao, gerar_prescricao, validar_prescricao
    
    # Definição de struct
    struct Prescricao:
        paciente: Patient
        medicamentos: list[MedicamentoPrescrito]
        data: Date
        medico: Medico
        
        # Métodos...
    
    # Funções do módulo
    fn gerar_prescricao(paciente: Patient, medicamentos: list[MedicamentoPrescrito], medico: Medico) -> Prescricao:
        # Implementação
    
    fn validar_prescricao(prescricao: Prescricao) -> Result<bool, list[str]>:
        # Implementação
    
    # Função interna (não exportada)
    fn _verificar_interacoes(medicamentos: list[MedicamentoPrescrito]) -> list[Interacao]:
        # Implementação
```

### 8.3 Namespaces

```charcot
# Definição de namespace
namespace Hospital:
    # Tipos e funções relacionados a hospital
    struct Leito:
        numero: int
        tipo: TipoLeito
        ocupado: bool
    
    struct Enfermaria:
        nome: str
        leitos: list[Leito]
    
    fn internar_paciente(paciente: Patient, enfermaria: Enfermaria) -> Result<Leito, str>:
        # Implementação

# Uso de namespace
leito = Hospital.internar_paciente(paciente, enfermaria_clinica_medica)
```

## 9. Recursos Específicos para Medicina

### 9.1 Integração FHIR

```charcot
# Definição de recurso FHIR
fhir resource Paciente extends Patient:
    # Campos adicionais específicos da implementação
    convenio: str
    numero_convenio: str
    
    # Mapeamento para FHIR
    fn to_fhir(self) -> fhir.Patient:
        patient = fhir.Patient.new()
        patient.id = self.id
        patient.name = fhir.HumanName.new(
            family: self.nome.split(" ")[-1],
            given: self.nome.split(" ")[0:-1]
        )
        # Mais mapeamentos...
        return patient
    
    # Criação a partir de FHIR
    fn from_fhir(patient: fhir.Patient) -> Self:
        # Implementação

# Uso de recursos FHIR
paciente_fhir = paciente.to_fhir()
servidor_fhir.create(paciente_fhir)

# Consulta FHIR
pacientes = fhir query Patient where name contains "Silva" and birthDate > "1980"
```

### 9.2 Workflows Clínicos

```charcot
# Definição de workflow
workflow Internacao:
    # Estados do workflow
    states:
        Admissao -> Internado -> (Alta | Transferencia | Obito)
    
    # Transições
    transition Admissao to Internado:
        require:
            paciente.avaliacao_medica is not None
            leito.disponivel == true
        
        action:
            leito.ocupar(paciente)
            paciente.status = "Internado"
            notificar_enfermagem(paciente, leito)
    
    transition Internado to Alta:
        require:
            paciente.prescricao_alta is not None
            medico.autorizou_alta == true
        
        action:
            leito.liberar()
      
(Content truncated due to size limit. Use line ranges to read in chunks)