#!/usr/bin/env python3
"""
Interpretador para a Linguagem Charcot

Este módulo implementa o interpretador para a linguagem Charcot,
responsável por executar programas Charcot.
"""

from typing import Dict, List, Any, Optional, Callable, Union
from dataclasses import dataclass
from enum import Enum, auto
import time
import math

from lexer import Token, TokenType
from parser import Node, NodeType, Expression, Statement, Binary, Unary, Literal, Grouping
from parser import Variable, Assign, Call, Get, Set, Logical, Block, ExpressionStmt
from parser import Function, If, Return, Let, While, For, Struct, Import, Procedure, Match
from type_checker import Type, TypeKind, PrimitiveType, StructType, FunctionType


class RuntimeError(Exception):
    """Exceção lançada quando ocorre um erro em tempo de execução."""
    def __init__(self, token: Token, message: str):
        self.token = token
        self.message = message
        super().__init__(f"[linha {token.line}, coluna {token.column}] {message}")


class ReturnValue(Exception):
    """Exceção usada para implementar a declaração return."""
    def __init__(self, value: Any):
        self.value = value
        super().__init__()


class BreakException(Exception):
    """Exceção usada para implementar a declaração break."""
    pass


class ContinueException(Exception):
    """Exceção usada para implementar a declaração continue."""
    pass


class CharcotCallable:
    """Interface para objetos chamáveis em Charcot."""
    def call(self, interpreter: 'Interpreter', arguments: List[Any]) -> Any:
        """
        Chama o objeto com os argumentos fornecidos.
        
        Args:
            interpreter (Interpreter): O interpretador.
            arguments (List[Any]): Os argumentos para a chamada.
            
        Returns:
            Any: O resultado da chamada.
        """
        raise NotImplementedError()
    
    def arity(self) -> int:
        """
        Retorna o número de argumentos que o objeto espera.
        
        Returns:
            int: O número de argumentos.
        """
        raise NotImplementedError()


class CharcotFunction(CharcotCallable):
    """Representa uma função definida pelo usuário em Charcot."""
    def __init__(self, declaration: Function, closure: Dict[str, Any], is_initializer: bool = False):
        self.declaration = declaration
        self.closure = closure
        self.is_initializer = is_initializer
    
    def call(self, interpreter: 'Interpreter', arguments: List[Any]) -> Any:
        """
        Chama a função com os argumentos fornecidos.
        
        Args:
            interpreter (Interpreter): O interpretador.
            arguments (List[Any]): Os argumentos para a chamada.
            
        Returns:
            Any: O resultado da chamada.
        """
        # Criar ambiente para a execução da função
        environment = Environment(self.closure)
        
        # Definir parâmetros no ambiente
        for i, param in enumerate(self.declaration.params):
            environment.define(param.lexeme, arguments[i])
        
        try:
            # Executar corpo da função
            interpreter.execute_block(self.declaration.body, environment)
        except ReturnValue as return_value:
            # Capturar valor de retorno
            if self.is_initializer:
                # Se for um inicializador, retornar 'this'
                return self.closure.get("this")
            return return_value.value
        
        # Se não houver return, retornar None
        if self.is_initializer:
            return self.closure.get("this")
        return None
    
    def arity(self) -> int:
        """
        Retorna o número de parâmetros da função.
        
        Returns:
            int: O número de parâmetros.
        """
        return len(self.declaration.params)
    
    def __str__(self) -> str:
        return f"<fn {self.declaration.name.lexeme}>"


class CharcotProcedure(CharcotCallable):
    """Representa um procedimento médico definido pelo usuário em Charcot."""
    def __init__(self, declaration: Procedure, closure: Dict[str, Any]):
        self.declaration = declaration
        self.closure = closure
    
    def call(self, interpreter: 'Interpreter', arguments: List[Any]) -> Any:
        """
        Chama o procedimento com os argumentos fornecidos.
        
        Args:
            interpreter (Interpreter): O interpretador.
            arguments (List[Any]): Os argumentos para a chamada.
            
        Returns:
            Any: O resultado da chamada.
        """
        # Criar ambiente para a execução do procedimento
        environment = Environment(self.closure)
        
        # Definir parâmetros no ambiente
        for i, param in enumerate(self.declaration.params):
            environment.define(param.lexeme, arguments[i])
        
        # Verificar verificações do procedimento
        for verification in self.declaration.verifications:
            result = interpreter.evaluate(verification)
            if not interpreter.is_truthy(result):
                raise RuntimeError(self.declaration.name, f"Verificação falhou: {verification}")
        
        try:
            # Executar corpo do procedimento
            interpreter.execute_block(self.declaration.body, environment)
        except ReturnValue as return_value:
            # Capturar valor de retorno
            return return_value.value
        
        # Se não houver return, retornar None
        return None
    
    def arity(self) -> int:
        """
        Retorna o número de parâmetros do procedimento.
        
        Returns:
            int: O número de parâmetros.
        """
        return len(self.declaration.params)
    
    def __str__(self) -> str:
        return f"<procedure {self.declaration.name.lexeme}>"


class CharcotStruct:
    """Representa uma instância de uma estrutura definida pelo usuário em Charcot."""
    def __init__(self, name: str, fields: Dict[str, Any] = None):
        self.name = name
        self.fields = fields or {}
    
    def get(self, name: str) -> Any:
        """
        Obtém o valor de um campo.
        
        Args:
            name (str): O nome do campo.
            
        Returns:
            Any: O valor do campo.
            
        Raises:
            AttributeError: Se o campo não existir.
        """
        if name in self.fields:
            return self.fields[name]
        raise AttributeError(f"'{self.name}' não tem atributo '{name}'")
    
    def set(self, name: str, value: Any):
        """
        Define o valor de um campo.
        
        Args:
            name (str): O nome do campo.
            value (Any): O valor a ser definido.
        """
        self.fields[name] = value
    
    def __str__(self) -> str:
        fields_str = ", ".join(f"{k}: {v}" for k, v in self.fields.items())
        return f"{self.name} {{ {fields_str} }}"


class NativeFunction(CharcotCallable):
    """Representa uma função nativa em Charcot."""
    def __init__(self, arity_count: int, function: Callable):
        self.arity_count = arity_count
        self.function = function
    
    def call(self, interpreter: 'Interpreter', arguments: List[Any]) -> Any:
        """
        Chama a função nativa com os argumentos fornecidos.
        
        Args:
            interpreter (Interpreter): O interpretador.
            arguments (List[Any]): Os argumentos para a chamada.
            
        Returns:
            Any: O resultado da chamada.
        """
        return self.function(*arguments)
    
    def arity(self) -> int:
        """
        Retorna o número de argumentos que a função nativa espera.
        
        Returns:
            int: O número de argumentos.
        """
        return self.arity_count
    
    def __str__(self) -> str:
        return "<native fn>"


class Environment:
    """Ambiente de execução para a linguagem Charcot."""
    def __init__(self, enclosing: Optional[Dict[str, Any]] = None):
        self.values: Dict[str, Any] = {}
        self.enclosing = enclosing
    
    def define(self, name: str, value: Any):
        """
        Define uma variável no ambiente atual.
        
        Args:
            name (str): O nome da variável.
            value (Any): O valor da variável.
        """
        self.values[name] = value
    
    def get(self, name: str) -> Any:
        """
        Obtém o valor de uma variável.
        
        Args:
            name (str): O nome da variável.
            
        Returns:
            Any: O valor da variável.
            
        Raises:
            KeyError: Se a variável não estiver definida.
        """
        if name in self.values:
            return self.values[name]
        
        if self.enclosing is not None:
            if name in self.enclosing:
                return self.enclosing[name]
        
        raise KeyError(f"Variável '{name}' não definida.")
    
    def assign(self, name: str, value: Any):
        """
        Atribui um valor a uma variável existente.
        
        Args:
            name (str): O nome da variável.
            value (Any): O valor a ser atribuído.
            
        Raises:
            KeyError: Se a variável não estiver definida.
        """
        if name in self.values:
            self.values[name] = value
            return
        
        if self.enclosing is not None:
            if name in self.enclosing:
                self.enclosing[name] = value
                return
        
        raise KeyError(f"Variável '{name}' não definida.")


class Interpreter:
    """
    Interpretador para a linguagem Charcot.
    
    Responsável por executar programas Charcot.
    """
    
    def __init__(self):
        self.globals = {}
        self.environment = self.globals
        self.locals: Dict[Expression, int] = {}
        
        # Definir funções nativas
        self._define_natives()
    
    def _define_natives(self):
        """Define funções nativas no ambiente global."""
        # print
        self.globals["print"] = NativeFunction(1, lambda x: print(x))
        
        # clock
        self.globals["clock"] = NativeFunction(0, lambda: time.time())
        
        # len
        self.globals["len"] = NativeFunction(1, lambda x: len(x))
        
        # str
        self.globals["str"] = NativeFunction(1, lambda x: str(x))
        
        # int
        self.globals["int"] = NativeFunction(1, lambda x: int(x))
        
        # float
        self.globals["float"] = NativeFunction(1, lambda x: float(x))
        
        # bool
        self.globals["bool"] = NativeFunction(1, lambda x: bool(x))
        
        # range
        def range_fn(*args):
            if len(args) == 1:
                return list(range(args[0]))
            elif len(args) == 2:
                return list(range(args[0], args[1]))
            elif len(args) == 3:
                return list(range(args[0], args[1], args[2]))
            else:
                raise ValueError("range() requer 1, 2 ou 3 argumentos")
        
        self.globals["range"] = NativeFunction(-1, range_fn)
        
        # input
        self.globals["input"] = NativeFunction(1, lambda prompt: input(prompt))
        
        # Funções matemáticas
        self.globals["abs"] = NativeFunction(1, lambda x: abs(x))
        self.globals["max"] = NativeFunction(-1, lambda *args: max(args))
        self.globals["min"] = NativeFunction(-1, lambda *args: min(args))
        self.globals["sum"] = NativeFunction(1, lambda x: sum(x))
        self.globals["round"] = NativeFunction(2, lambda x, digits=0: round(x, digits))
        
        # Constantes matemáticas
        self.globals["PI"] = math.pi
        self.globals["E"] = math.e
        
        # Tipos específicos para medicina
        # Patient
        class Patient(CharcotStruct):
            def __init__(self, **kwargs):
                super().__init__("Patient", kwargs)
        
        self.globals["Patient"] = lambda **kwargs: Patient(**kwargs)
        
        # Medication
        class Medication(CharcotStruct):
            def __init__(self, **kwargs):
                super().__init__("Medication", kwargs)
        
        self.globals["Medication"] = lambda **kwargs: Medication(**kwargs)
        
        # Dose
        class Dose(CharcotStruct):
            def __init__(self, value, unit):
                super().__init__("Dose", {"value": value, "unit": unit})
            
            def __str__(self):
                return f"{self.fields['value']} {self.fields['unit']}"
        
        self.globals["Dose"] = lambda value, unit: Dose(value, unit)
        
        # Date
        class Date(CharcotStruct):
            def __init__(self, year, month, day):
                super().__init__("Date", {"year": year, "month": month, "day": day})
            
            def __str__(self):
                return f"{self.fields['year']}-{self.fields['month']:02d}-{self.fields['day']:02d}"
            
            @staticmethod
            def today():
                import datetime
                now = datetime.datetime.now()
                return Date(now.year, now.month, now.day)
        
        self.globals["Date"] = lambda year, month, day: Date(year, month, day)
        self.globals["Date"].today = Date.today
        
        # Time
        class Time(CharcotStruct):
            def __init__(self, hour, minute, second=0):
                super().__init__("Time", {"hour": hour, "minute": minute, "second": second})
            
            def __str__(self):
                return f"{self.fields['hour']:02d}:{self.fields['minute']:02d}:{self.fields['second']:02d}"
            
            @staticmethod
            def now():
                import datetime
                now = datetime.datetime.now()
                return Time(now.hour, now.minute, now.second)
        
        self.globals["Time"] = lambda hour, minute, second=0: Time(hour, minute, second)
        self.globals["Time"].now = Time.now
        
        # DateTime
        class DateTime(CharcotStruct):
            def __init__(self, year, month, day, hour=0, minute=0, second=0):
                super().__init__("DateTime", {
                    "year": year, "month": month, "day": day,
                    "hour": hour, "minute": minute, "second": second
                })
            
            def __str__(self):
                return f"{self.fields['year']}-{self.fields['month']:02d}-{self.fields['day']:02d} " \
                       f"{self.fields['hour']:02d}:{self.fields['minute']:02d}:{self.fields['second']:02d}"
            
            @staticmethod
            def now():
                import datetime
                now = datetime.datetime.now()
                return DateTime(now.year, now.month, now.day, now.hour, now.minute, now.second)
        
        self.globals["DateTime"] = lambda year, month, day, hour=0, minute=0, second=0: DateTime(year, month, day, hour, minute, second)
        self.globals["DateTime"].now = DateTime.now
    
    def interpret(self, statements: List[Statement]) -> None:
        """
        Interpreta uma lista de declarações.
        
        Args:
            statements (List[Statement]): A lista de declarações a ser interpretada.
        """
        try:
            for statement in statements:
                self.execute(statement)
        except RuntimeError as error:
            print(f"Erro em tempo de execução: {error}")
    
    def execute(self, stmt: Statement) -> None:
        """
        Executa uma declaração.
        
        Args:
            stmt (Statement): A declaração a ser executada.
        """
        if isinstance(stmt, ExpressionStmt):
            self.evaluate(stmt.expression)
        elif isinstance(stmt, Let):
            self.execute_let(stmt)
        elif isinstance(stmt, Block):
            self.execute_block(stmt.statements, Environment(self.environment))
        elif is
(Content truncated due to size limit. Use line ranges to read in chunks)