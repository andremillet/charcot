# Linguagem de Programação Charcot - Guia do Usuário

## Introdução

A linguagem Charcot é uma linguagem de programação projetada especificamente para aplicações médicas. Ela combina a sintaxe intuitiva do Python com a segurança e desempenho do Rust, além de incorporar nativamente conceitos médicos e padrões como FHIR (Fast Healthcare Interoperability Resources).

Este guia do usuário fornece uma visão abrangente da linguagem Charcot, incluindo sua sintaxe, recursos, exemplos e melhores práticas para desenvolvimento de aplicações médicas.

## Índice

1. [Visão Geral](#visão-geral)
2. [Instalação](#instalação)
3. [Sintaxe Básica](#sintaxe-básica)
4. [Tipos de Dados](#tipos-de-dados)
5. [Estruturas de Controle](#estruturas-de-controle)
6. [Funções](#funções)
7. [Módulos e Pacotes](#módulos-e-pacotes)
8. [Tipos Específicos para Medicina](#tipos-específicos-para-medicina)
9. [Workflows Hospitalares](#workflows-hospitalares)
10. [Sistema de Prescrição](#sistema-de-prescrição)
11. [Integração FHIR](#integração-fhir)
12. [Segurança e Privacidade](#segurança-e-privacidade)
13. [Ambiente REPL](#ambiente-repl)
14. [Exemplos](#exemplos)
15. [Melhores Práticas](#melhores-práticas)
16. [Referência da API](#referência-da-api)
17. [Solução de Problemas](#solução-de-problemas)
18. [Contribuindo](#contribuindo)

## Visão Geral

A linguagem Charcot foi projetada para atender às necessidades específicas de aplicações médicas, oferecendo recursos que facilitam o desenvolvimento de software seguro, eficiente e interoperável para o setor de saúde.

### Características Principais

- **Sintaxe Simples e Intuitiva**: Inspirada em Python, fácil de aprender e usar.
- **Segurança de Tipos**: Sistema de tipos estático que previne erros comuns.
- **Gerenciamento de Memória Seguro**: Inspirado em Rust, evita vazamentos de memória e acesso inválido.
- **Recursos Específicos para Medicina**: Tipos de dados e funções específicas para o domínio médico.
- **Integração FHIR**: Suporte nativo ao padrão FHIR para interoperabilidade.
- **Workflows Hospitalares**: Funções para gerenciar processos hospitalares e ambulatoriais.
- **Sistema de Prescrição**: Verificações de segurança automáticas para prescrições médicas.
- **Segurança e Privacidade**: Recursos avançados para proteção de dados sensíveis.

### Por que Charcot?

A linguagem Charcot foi nomeada em homenagem a Jean-Martin Charcot, um neurologista francês considerado um dos fundadores da neurologia moderna. Assim como Charcot revolucionou a medicina com sua abordagem metódica e científica, a linguagem Charcot busca revolucionar o desenvolvimento de software médico com uma abordagem segura, eficiente e específica para o domínio.

Charcot oferece vantagens significativas para o desenvolvimento de aplicações médicas:

1. **Redução de Erros**: Verificações de segurança automáticas para prescrições médicas, dosagens e interações medicamentosas.
2. **Interoperabilidade**: Integração nativa com o padrão FHIR para comunicação com outros sistemas de saúde.
3. **Produtividade**: Sintaxe intuitiva e recursos específicos para medicina que aceleram o desenvolvimento.
4. **Segurança**: Sistema de tipos forte e gerenciamento de memória seguro que previnem erros comuns.
5. **Conformidade**: Recursos para garantir conformidade com regulamentações de privacidade e segurança de dados médicos.

## Instalação

### Requisitos do Sistema

- Python 3.8 ou superior
- Pip (gerenciador de pacotes Python)
- 100 MB de espaço em disco

### Instalação via Pip

A maneira mais simples de instalar a linguagem Charcot é usando o pip:

```bash
pip install charcot
```

### Instalação a partir do Código-Fonte

Para instalar a partir do código-fonte:

```bash
git clone https://github.com/charcot-lang/charcot.git
cd charcot
pip install -e .
```

### Verificando a Instalação

Para verificar se a instalação foi bem-sucedida, execute o comando:

```bash
charcot --version
```

Você deve ver a versão da linguagem Charcot instalada.

## Sintaxe Básica

A sintaxe da linguagem Charcot é inspirada em Python, com algumas adições específicas para medicina.

### Comentários

Comentários de linha única começam com `#`:

```
# Este é um comentário de linha única
```

Comentários de múltiplas linhas são delimitados por `"""`:

```
"""
Este é um comentário
de múltiplas linhas
"""
```

### Variáveis e Atribuição

A atribuição de variáveis é feita com o operador `=`:

```
nome = "João Silva"
idade = 42
peso = 70.5
ativo = true
```

### Tipos Básicos

- **int**: Números inteiros
- **float**: Números de ponto flutuante
- **string**: Sequências de caracteres
- **bool**: Valores booleanos (true/false)
- **list**: Listas de valores
- **dict**: Dicionários (mapas chave-valor)

### Operadores

Operadores aritméticos:

```
soma = 5 + 3
subtracao = 5 - 3
multiplicacao = 5 * 3
divisao = 5 / 3
divisao_inteira = 5 // 3
resto = 5 % 3
potencia = 5 ** 3
```

Operadores de comparação:

```
igual = 5 == 3
diferente = 5 != 3
maior = 5 > 3
menor = 5 < 3
maior_igual = 5 >= 3
menor_igual = 5 <= 3
```

Operadores lógicos:

```
e = true and false
ou = true or false
nao = not true
```

## Tipos de Dados

### Tipos Básicos

#### Números

```
# Inteiros
idade = 42
ano = 2023

# Ponto flutuante
peso = 70.5
altura = 1.75
```

#### Strings

```
nome = "João Silva"
endereco = 'Rua das Flores, 123'
texto_longo = """
Este é um texto
de múltiplas linhas
"""
```

Formatação de strings:

```
nome = "João"
idade = 42
mensagem = f"Olá, {nome}! Você tem {idade} anos."
```

#### Booleanos

```
ativo = true
internado = false
```

#### Listas

```
alergias = ["penicilina", "sulfa", "aspirina"]
valores = [1, 2, 3, 4, 5]
```

Acesso a elementos:

```
primeira_alergia = alergias[0]  # "penicilina"
```

#### Dicionários

```
paciente = {
    "nome": "João Silva",
    "idade": 42,
    "alergias": ["penicilina"]
}
```

Acesso a elementos:

```
nome_paciente = paciente["nome"]  # "João Silva"
```

### Tipos Específicos para Medicina

Além dos tipos básicos, a linguagem Charcot inclui tipos específicos para medicina, que serão detalhados na seção [Tipos Específicos para Medicina](#tipos-específicos-para-medicina).

## Estruturas de Controle

### Condicionais

#### If-Elif-Else

```
if idade > 65:
    print("Paciente idoso")
elif idade < 18:
    print("Paciente pediátrico")
else:
    print("Paciente adulto")
```

#### Match (Switch)

```
match status_paciente:
    case "internado":
        print("Paciente está internado")
    case "alta":
        print("Paciente recebeu alta")
    case "transferido":
        print("Paciente foi transferido")
    case _:
        print("Status desconhecido")
```

### Loops

#### For

```
for alergia in alergias:
    print(f"Paciente alérgico a {alergia}")
```

Iteração com índice:

```
for i, alergia in enumerate(alergias):
    print(f"Alergia {i+1}: {alergia}")
```

#### While

```
i = 0
while i < len(alergias):
    print(f"Alergia: {alergias[i]}")
    i += 1
```

### Controle de Fluxo

#### Break e Continue

```
for medicamento in medicamentos:
    if medicamento.contraindicado_para(paciente):
        print(f"{medicamento.nome} é contraindicado para o paciente")
        continue
    
    if medicamento.requer_autorizacao and not medico.autorizado:
        print(f"{medicamento.nome} requer autorização especial")
        break
    
    print(f"{medicamento.nome} pode ser prescrito")
```

#### Try-Except

```
try:
    prescrever(paciente, medicamento, dose)
except ContraindicacaoError as e:
    print(f"Erro de contraindicação: {e}")
except DosagemError as e:
    print(f"Erro de dosagem: {e}")
except Exception as e:
    print(f"Erro desconhecido: {e}")
else:
    print("Prescrição realizada com sucesso")
finally:
    print("Processo de prescrição concluído")
```

## Funções

### Definição de Funções

```
def calcular_imc(peso, altura):
    return peso / (altura ** 2)
```

### Parâmetros Nomeados

```
def prescrever(paciente, medicamento, dose, frequencia, duracao=7, instrucoes=null):
    # Implementação
    return prescricao
```

Chamada com parâmetros nomeados:

```
prescricao = prescrever(
    paciente: paciente1,
    medicamento: paracetamol,
    dose: "500 mg",
    frequencia: "8/8h",
    duracao: 5,
    instrucoes: "Tomar com água"
)
```

### Funções com Tipos

```
def calcular_imc(peso: float, altura: float) -> float:
    return peso / (altura ** 2)
```

### Funções Anônimas (Lambda)

```
calcular_dose = lambda peso, dose_por_kg: peso * dose_por_kg
```

## Módulos e Pacotes

### Importação de Módulos

```
import fhir
import prescription
```

### Importação Seletiva

```
from fhir import Patient, Medication
from prescription import create_prescription, verify_safety
```

### Importação com Alias

```
import fhir_integration as fhir
```

### Criação de Módulos

Um módulo é simplesmente um arquivo Python com extensão `.ch`:

```
# arquivo: utils.ch
def calcular_imc(peso, altura):
    return peso / (altura ** 2)

def classificar_imc(imc):
    if imc < 18.5:
        return "Abaixo do peso"
    elif imc < 25:
        return "Peso normal"
    elif imc < 30:
        return "Sobrepeso"
    else:
        return "Obesidade"
```

Importação do módulo:

```
import utils

imc = utils.calcular_imc(70, 1.75)
classificacao = utils.classificar_imc(imc)
```

## Tipos Específicos para Medicina

A linguagem Charcot inclui tipos específicos para medicina, que são fundamentais para o desenvolvimento de aplicações médicas seguras e eficientes.

### Patient (Paciente)

O tipo `patient` representa um paciente no sistema:

```
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175,
    allergies: ["penicillin"],
    conditions: ["hypertension"]
}
```

Atributos:
- **name**: Nome completo do paciente
- **birth_date**: Data de nascimento (formato ISO: YYYY-MM-DD)
- **gender**: Gênero (male, female, other, unknown)
- **weight**: Peso em kg (opcional)
- **height**: Altura em cm (opcional)
- **allergies**: Lista de alergias (opcional)
- **conditions**: Lista de condições médicas (opcional)

Métodos:
- **calculate_bmi()**: Calcula o IMC (Índice de Massa Corporal)
- **calculate_age()**: Calcula a idade atual
- **has_allergy(allergen)**: Verifica se o paciente tem alergia a um determinado alérgeno
- **has_condition(condition)**: Verifica se o paciente tem uma determinada condição médica

### Medication (Medicamento)

O tipo `medication` representa um medicamento no sistema:

```
medication Paracetamol {
    active_ingredient: "Acetaminophen",
    strength: "500 mg",
    form: "tablet",
    route: "oral",
    max_daily_dose: "4000 mg",
    contraindications: ["liver failure"],
    interactions: {
        "Warfarin": "Pode aumentar o efeito anticoagulante"
    }
}
```

Atributos:
- **active_ingredient**: Princípio ativo
- **strength**: Concentração (ex: "500 mg")
- **form**: Forma farmacêutica (ex: "tablet", "solution")
- **route**: Via de administração (ex: "oral", "intravenous")
- **max_daily_dose**: Dose máxima diária (opcional)
- **contraindications**: Lista de contraindicações (opcional)
- **interactions**: Dicionário de interações medicamentosas (opcional)
- **requires_prescription**: Se requer prescrição (opcional, padrão: true)
- **controlled_substance**: Se é substância controlada (opcional, padrão: false)

Métodos:
- **is_contraindicated_for(patient)**: Verifica se o medicamento é contraindicado para um paciente
- **check_interaction(medication)**: Verifica interação com outro medicamento
- **calculate_max_dose(weight)**: Calcula a dose máxima com base no peso do paciente

### Prescription (Prescrição)

O tipo `prescription` representa uma prescrição médica:

```
prescription new_rx {
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    frequency: "every 6 hours",
    duration: 5,
    instructions: "Take with water for pain relief",
    prescriber: Doctor1
}
```

Atributos:
- **patient**: Paciente
- **medication**: Medicamento
- **dose**: Dose (ex: "500 mg")
- **frequency**: Frequência (ex: "every 6 hours")
- **duration**: Duração em dias (opcional)
- **instructions**: Instruções para o paciente (opcional)
- **prescriber**: Prescritor (opcional)

Métodos:
- **is_safe()**: Verifica se a prescrição é segura
- **calculate_total_dose()**: Calcula a dose total com base na frequência e duração
- **is_within_max_dose()**: Verifica se a dose está dentro do limite máximo

### Encounter (Encontro)

O tipo `encounter` representa um encontro clínico (consulta, internação):

```
encounter Encounter1 {
    patient: Patient1,
    class_code: "inpatient",
    status: "in-progress",
    start_time: "2023-05-01T10:00:00",
    location: Room101,
    practitioner: Doctor1,
    reason: "Pneumonia"
}
```

Atributos:
- **patient**: Paciente
- **class_code**: Tipo de encontro (inpatient, outpatient, emergency, etc.)
- **status**: Status (in-progress, finished, cancelled, etc.)
- **start_time**: Data/hora de início
- **end_time**: Data/hora de término (opcional)
- **location**: Localização (opcional)
- **practitioner**: Profissional responsável (opcional)
- **reason**: Motivo do encontro (opcional)

Métodos:
- **duration()**: Calcula a duração do encontro
- **add_diagnosis(diagnosis)**: Adiciona um diagnóstico ao encontro
- **add_procedure(procedure)**: Adiciona um procedimento ao encontro

### Observation (Observação)

O tipo `observation` representa uma observação clínica (sinais vitais, resultados de exames):

```
observation BloodPressure1 {
    patient: Patient1,
    code: "8480-6",
    code_system: "LOINC",
    value: "120/80",
    unit: "mmHg",
    time: "2023-05-01T10:30:00",
    performer: Nurse1
}
```

Atributos:
- **patient**: Paciente
- **code**: Código da observação
- **code_system**: Sistema de codificação (ex: LOINC, SNOMED CT)
- **value**: Valor da observação
- **unit**: Unidade de medida (opcional)
- **time**: Data/hora da observação
- **performer**: Profissional que realizou a observação (opcional)

Métodos:
- **is_abnormal()**: Verifica se o valor está fora dos limites normais
- **trend(observations)**: Calcula a tendência com base em observações anteriores

## Workflows Hospitalares

A linguagem Charcot suporta nativamente workflows hospitalares e ambulatoriais, permitindo a automação de processos clínicos.

### Internação

#### Admissão de Paciente

```
encounter = admit_patient(
    patient: Patient1,
    location: Room101,
    reason: "Pneumonia",
    attending: Doctor1
)
```

#### Transferência de Paciente

```
transfer_patient(
    encounter: encounter,
    new_location: Room202,
    reason: "Necessidade de monitoramento mais próximo"
)
```

#### Alta de Paciente

```
discharge_patient(
    encounter: encounter,
    notes: "Paciente recuperado. Seguimento em 1 semana."
)
```

### Ambulatorial

#### Agendamento de Consulta

```
appointment = schedule_appointment(
    patient: Patient1,
    practitioner: Doctor1,
    time: "2023-05-15T14:00:00",
    reason: "Consulta de rotina"
)
```

#### Check-in de Paciente

```
check_in_patient(
    appointment: appointment,
    time: "2023-05-15T13:45:00"
)
```

#### Início e Fim de Consulta

```
start_appointment(appointment)

# Realizar consulta...

end_appointment(
    appointment: appointment,
    notes: "Paciente estável. Retorno em 3 meses."
)
```

### Medicação

#### Prescrição de Medicamento

```
prescription = prescribe(
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    frequency: "every 6 hours",
    duration: 5,
    instructions: "Take with water for pain relief",
    prescriber: Doctor1
)
```

#### Dispensação de Medicamento

```
dispense_medication(
    prescription: prescription,
    quantity: 20,
    pharmacist: Pharmacist1
)
```

#### Administração de Medicamento

```
administer_medication(
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    route: "oral",
    time: now(),
    administrator: Nurse1
)
```

## Sistema de Prescrição

A linguagem Charcot inclui um sistema de prescrição médica com verificações de segurança automáticas.

### Criação de Prescrição

```
prescription new_rx {
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    frequency: "every 6 hours",
    duration: 5,
    instructions: "Take with water for pain relief",
    prescriber: Doctor1
}
```

### Verificação de Segurança

```
safety_result = safety_check(new_rx)

if safety_result.is_safe:
    print("Prescrição segura")
else:
    print(f"Prescrição não segura: {safety_result.notes}")
```

Verificações realizadas:
- **Alergias**: Verifica se o paciente tem alergia ao medicamento
- **Interações**: Verifica interações com outros medicamentos ativos
- **Contraindicações**: Verifica contraindicações com base nas condições do paciente
- **Dose**: Verifica se a dose está dentro dos limites seguros
- **Direitos de Prescrição**: Verifica se o prescritor tem autorização

### Emissão de Prescrição

```
if safety_result.is_safe:
    issue(new_rx)
    print("Prescrição emitida com sucesso")
else:
    print(f"Prescrição não emitida: {safety_result.notes}")
```

### Cancelamento de Prescrição

```
cancel(new_rx, reason: "Medicamento substituído por alternativa mais adequada")
```

### Renovação de Prescrição

```
renewed_rx = renew(new_rx, duration: 10)
```

## Integração FHIR

A linguagem Charcot integra nativamente o padrão FHIR (Fast Healthcare Interoperability Resources) para garantir interoperabilidade com sistemas de saúde.

### Configuração do Cliente FHIR

```
fhir_client = fhir.connect(
    base_url: "http://hapi.fhir.org/baseR4",
    auth_token: null  # Opcional, para servidores que requerem autenticação
)
```

### Criação de Recursos FHIR

#### Paciente FHIR

```
patient_data = {
    "resourceType": "Patient",
    "active": true,
    "name": [
        {
            "given": ["João"],
            "family": "Silva"
        }
    ],
    "gender": "male",
    "birthDate": "1980-05-15"
}

patient_resource = fhir_create(
    client: fhir_client,
    resource: patient_data
)

print(f"Paciente criado com ID: {patient_resource.id}")
```

#### Medicamento FHIR

```
medication_data = {
    "resourceType": "Medication",
    "code": {
        "coding": [
            {
                "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
                "code": "1049502",
                "display": "Acetaminophen 325 MG Oral Tablet"
            }
        ],
        "text": "Acetaminophen 325 MG Oral Tablet"
    }
}

medication_resource = fhir_create(
    client: fhir_client,
    resource: medication_data
)
```

#### Prescrição FHIR

```
prescription_data = {
    "resourceType": "MedicationRequest",
    "status": "active",
    "intent": "order",
    "medicationReference": {
        "reference": f"Medication/{medication_resource.id}",
        "display": "Acetaminophen 325 MG Oral Tablet"
    },
    "subject": {
        "reference": f"Patient/{patient_resource.id}",
        "display": "João Silva"
    },
    "authoredOn": now(),
    "dosageInstruction": [
        {
            "text": "Take 1 tablet by mouth every 4-6 hours as needed for pain.",
            "doseAndRate": [
                {
                    "doseQuantity": {
                        "value": 1,
                        "unit": "tablet",
                        "system": "http://unitsofmeasure.org",
                        "code": "TAB"
                    }
                }
            ]
        }
    ]
}

prescription_resource = fhir_create(
    client: fhir_client,
    resource: prescription_data
)
```

### Leitura de Recursos FHIR

```
patient = fhir_read(
    client: fhir_client,
    resourceType: "Patient",
    id: patient_resource.id
)

print(f"Nome do paciente: {patient.name[0].given[0]} {patient.name[0].family}")
```

### Pesquisa de Recursos FHIR

```
patients = fhir_search(
    client: fhir_client,
    resourceType: "Patient",
    params: {
        "family": "Silva"
    }
)

print(f"Encontrados {len(patients.entry)} pacientes")
```

### Atualização de Recursos FHIR

```
patient.telecom = [
    {
        "system": "phone",
        "value": "555-123-4567",
        "use": "home"
    }
]

updated_patient = fhir_update(
    client: fhir_client,
    resource: patient
)
```

### Conversão entre FHIR e Charcot

```
# Converter paciente FHIR para paciente Charcot
charcot_patient = Patient.from_fhir(patient)

# Converter paciente Charcot para FHIR
fhir_patient = charcot_patient.to_fhir()
```

## Segurança e Privacidade

A linguagem Charcot inclui recursos avançados de segurança e privacidade para proteção de dados sensíveis de saúde.

### Autenticação e Autorização

```
# Inicializar gerenciador de segurança
security_manager = security.init(
    log_file: "audit.log"
)

# Autenticar usuário
if security_manager.authenticate("dr.silva", "senha123"):
    # Verificar permissão
    if security_manager.check_permission("prescription:create"):
        # Criar prescrição
        rx = prescribe(...)
    else:
        print("Permissão negada")
```

### Criptografia de Dados

```
# Criptografar dados sensíveis
encrypted_data = security_manager.encrypt_data(json.dumps(patient_data))

# Descriptografar dados
decrypted_data = security_manager.decrypt_data(encrypted_data)
decrypted_patient = json.loads(decrypted_data)
```

### Anonimização de Dados

```
# Anonimizar dados de paciente para pesquisa
anonymized = security_manager.anonymize_patient_data(patient_data)
```

### Detecção e Mascaramento de PHI

```
# Detectar informações de saúde protegidas (PHI)
phi_detected = DataProtection.detect_phi(text)

# Mascarar PHI
masked_text = DataProtection.mask_phi(text)
```

### Auditoria

```
# Registrar ação no log de auditoria
security_manager.audit_log(
    action: "create",
    resource: "prescription",
    resource_id: rx.id
)

# Obter logs de auditoria
logs = security_manager.get_audit_logs(
    filters: {
        "resource_type": "prescription"
    }
)
```

## Ambiente REPL

A linguagem Charcot inclui um ambiente REPL (Read-Eval-Print Loop) para desenvolvimento interativo.

### Iniciando o REPL

```bash
charcot
```

Você verá o prompt do REPL:

```
Charcot - Linguagem de Programação para Aplicações Médicas

Digite help para ver a lista de comandos disponíveis.
Digite examples para ver exemplos de código.
Digite exit para sair.

charcot>
```

### Comandos do REPL

- **help**: Exibe ajuda sobre comandos disponíveis
- **examples**: Lista exemplos de código disponíveis
- **example <nome>**: Carrega um exemplo específico
- **load <arquivo>**: Carrega um arquivo Charcot
- **save <arquivo>**: Salva o histórico de comandos em um arquivo
- **clear**: Limpa a tela
- **reset**: Reinicia o ambiente (limpa variáveis)
- **vars**: Lista as variáveis definidas
- **history**: Exibe o histórico de comandos
- **exit**: Sai do REPL

### Exemplos no REPL

```
charcot> examples
Exemplos disponíveis:
  hello_world
  patient_bmi
  medication_safety
  prescription_workflow
  hospital_workflow
  fhir_integration

Para carregar um exemplo, digite: example <nome>

charcot> example patient_bmi
Exemplo 'patient_bmi':
# Exemplo: Cálculo de IMC
# Demonstra a criação de um paciente e cálculo de IMC

# Definir um paciente
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175
}

# Calcular IMC
bmi = Patient1.weight / ((Patient1.height / 100) ** 2)
print(f"Paciente: {Patient1.name}")
print(f"IMC: {bmi:.1f}")

# Classificar IMC
if bmi < 18.5:
    print("Classificação: Abaixo do peso")
elif bmi < 25:
    print("Classificação: Peso normal")
elif bmi < 30:
    print("Classificação: Sobrepeso")
else:
    print("Classificação: Obesidade")

Deseja executar este exemplo? (s/n) s
charcot> patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175
}
charcot> bmi = Patient1.weight / ((Patient1.height / 100) ** 2)
charcot> print(f"Paciente: {Patient1.name}")
Paciente: João Silva
charcot> print(f"IMC: {bmi:.1f}")
IMC: 23.0
charcot> if bmi < 18.5:
    print("Classificação: Abaixo do peso")
elif bmi < 25:
    print("Classificação: Peso normal")
elif bmi < 30:
    print("Classificação: Sobrepeso")
else:
    print("Classificação: Obesidade")
Classificação: Peso normal
```

## Exemplos

### Exemplo 1: Cálculo de IMC

```
# Definir um paciente
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175
}

# Calcular IMC
bmi = Patient1.weight / ((Patient1.height / 100) ** 2)
print(f"Paciente: {Patient1.name}")
print(f"IMC: {bmi:.1f}")

# Classificar IMC
if bmi < 18.5:
    print("Classificação: Abaixo do peso")
elif bmi < 25:
    print("Classificação: Peso normal")
elif bmi < 30:
    print("Classificação: Sobrepeso")
else:
    print("Classificação: Obesidade")
```

### Exemplo 2: Verificação de Segurança de Medicamentos

```
# Definir um medicamento
medication Paracetamol {
    active_ingredient: "Acetaminophen",
    strength: "500 mg",
    form: "tablet",
    route: "oral",
    max_daily_dose: "4000 mg",
    contraindications: ["liver failure"]
}

# Definir um paciente
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175,
    conditions: ["hypertension"]
}

# Verificar dose
dose = 2 * 500  # 2 comprimidos de 500mg
frequency = 4   # 4 vezes ao dia
daily_dose = dose * frequency

print(f"Medicamento: {Paracetamol.active_ingredient} {Paracetamol.strength}")
print(f"Dose prescrita: {dose} mg, {frequency} vezes ao dia")
print(f"Dose diária total: {daily_dose} mg")
print(f"Dose máxima diária: {Paracetamol.max_daily_dose}")

if daily_dose > 4000:
    print("ALERTA: Dose diária excede o máximo recomendado!")
else:
    print("Dose diária dentro do limite seguro.")

# Verificar contraindicações
for condition in Patient1.conditions:
    if condition in Paracetamol.contraindications:
        print(f"ALERTA: Medicamento contraindicado para pacientes com {condition}!")
```

### Exemplo 3: Workflow de Prescrição

```
# Definir um paciente
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175,
    allergies: ["penicillin"],
    conditions: ["hypertension"]
}

# Definir um medicamento
medication Paracetamol {
    active_ingredient: "Acetaminophen",
    strength: "500 mg",
    form: "tablet",
    route: "oral",
    max_daily_dose: "4000 mg"
}

# Definir um prescritor
prescriber Doctor1 {
    name: "Dra. Maria Oliveira",
    license: "CRM12345",
    specialty: "Clínica Médica"
}

# Criar uma prescrição
prescription new_rx {
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    frequency: "every 6 hours",
    duration: 5,  # dias
    instructions: "Take with water for pain relief",
    prescriber: Doctor1
}

# Verificar segurança
safety_result = safety_check(new_rx)

# Exibir resultado da verificação
print(f"Prescrição: {Paracetamol.active_ingredient} {new_rx.dose}, {new_rx.frequency}")
print(f"Paciente: {Patient1.name}")
print(f"Prescritor: {Doctor1.name}")
print(f"Resultado da verificação: {safety_result.status}")

# Emitir prescrição se segura
if safety_result.is_safe:
    issue(new_rx)
    print("Prescrição emitida com sucesso")
    
    # Simular administração do medicamento
    administer_medication(
        patient: Patient1,
        medication: Paracetamol,
        dose: "500 mg",
        route: "oral",
        time: now()
    )
    print("Medicamento administrado")
else:
    print(f"Prescrição não emitida: {safety_result.notes}")
```

### Exemplo 4: Workflow Hospitalar

```
# Definir um paciente
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175,
    conditions: ["pneumonia"]
}

# Definir localizações
location Ward_A {
    name: "Ala A",
    type: "ward",
    capacity: 10
}

location Room_101 {
    name: "Quarto 101",
    type: "room",
    parent: Ward_A,
    capacity: 2
}

location Room_202 {
    name: "Quarto 202",
    type: "room",
    parent: Ward_A,
    capacity: 1
}

# Definir médico
prescriber Doctor1 {
    name: "Dra. Maria Oliveira",
    license: "CRM12345",
    specialty: "Pneumologia"
}

# Internar paciente
print(f"Internando paciente {Patient1.name} com {Patient1.conditions[0]}")
encounter = admit_patient(
    patient: Patient1,
    location: Room_101,
    reason: "Pneumonia",
    attending: Doctor1
)
print(f"Paciente internado no {Room_101.name}")

# Administrar medicação
medication Antibiotico {
    active_ingredient: "Amoxicillin",
    strength: "500 mg",
    form: "capsule",
    route: "oral"
}

print(f"Administrando {Antibiotico.active_ingredient}")
administer_medication(
    patient: Patient1,
    medication: Antibiotico,
    dose: "500 mg",
    route: "oral",
    time: now()
)

# Transferir paciente
print("Transferindo paciente para monitoramento mais próximo")
transfer_patient(
    encounter: encounter,
    new_location: Room_202,
    reason: "Necessidade de monitoramento mais próximo"
)
print(f"Paciente transferido para {Room_202.name}")

# Dar alta ao paciente
print("Paciente recuperado, preparando alta")
discharge_patient(
    encounter: encounter,
    notes: "Paciente recuperado. Seguimento ambulatorial em 1 semana."
)
print("Paciente recebeu alta hospitalar")
```

### Exemplo 5: Integração FHIR

```
# Configurar cliente FHIR
fhir_client = connect_fhir(
    base_url: "http://hapi.fhir.org/baseR4",
    auth_token: null
)

# Criar paciente FHIR
print("Criando paciente no servidor FHIR")
patient_data = {
    "resourceType": "Patient",
    "active": true,
    "name": [
        {
            "given": ["João"],
            "family": "Silva"
        }
    ],
    "gender": "male",
    "birthDate": "1980-05-15"
}

patient_resource = fhir_create(
    client: fhir_client,
    resource: patient_data
)

print(f"Paciente criado com ID: {patient_resource.id}")

# Criar medicamento FHIR
print("Criando medicamento no servidor FHIR")
medication_data = {
    "resourceType": "Medication",
    "code": {
        "coding": [
            {
                "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
                "code": "1049502",
                "display": "Acetaminophen 325 MG Oral Tablet"
            }
        ],
        "text": "Acetaminophen 325 MG Oral Tablet"
    }
}

medication_resource = fhir_create(
    client: fhir_client,
    resource: medication_data
)

print(f"Medicamento criado com ID: {medication_resource.id}")

# Criar prescrição FHIR
print("Criando prescrição no servidor FHIR")
prescription_data = {
    "resourceType": "MedicationRequest",
    "status": "active",
    "intent": "order",
    "medicationReference": {
        "reference": f"Medication/{medication_resource.id}",
        "display": "Acetaminophen 325 MG Oral Tablet"
    },
    "subject": {
        "reference": f"Patient/{patient_resource.id}",
        "display": "João Silva"
    },
    "authoredOn": now(),
    "dosageInstruction": [
        {
            "text": "Take 1 tablet by mouth every 4-6 hours as needed for pain.",
            "doseAndRate": [
                {
                    "doseQuantity": {
                        "value": 1,
                        "unit": "tablet",
                        "system": "http://unitsofmeasure.org",
                        "code": "TAB"
                    }
                }
            ]
        }
    ]
}

prescription_resource = fhir_create(
    client: fhir_client,
    resource: prescription_data
)

print(f"Prescrição criada com ID: {prescription_resource.id}")

# Pesquisar pacientes
print("Pesquisando pacientes")
search_result = fhir_search(
    client: fhir_client,
    resourceType: "Patient",
    params: {
        "family": "Silva"
    }
)

print(f"Encontrados {len(search_result.entry)} pacientes")
```

## Melhores Práticas

### Segurança

1. **Sempre verifique prescrições**: Use a função `safety_check()` para verificar a segurança de todas as prescrições antes de emiti-las.

2. **Valide dados de entrada**: Verifique se os dados de entrada são válidos antes de usá-los, especialmente em aplicações médicas.

3. **Use criptografia para dados sensíveis**: Utilize os recursos de criptografia da linguagem para proteger dados sensíveis.

4. **Implemente controle de acesso**: Use o sistema de autenticação e autorização para controlar o acesso a recursos sensíveis.

5. **Registre ações em log de auditoria**: Mantenha um registro detalhado de todas as ações realizadas no sistema.

### Desempenho

1. **Use tipos específicos para medicina**: Os tipos específicos para medicina são otimizados para desempenho e segurança.

2. **Evite cálculos repetitivos**: Armazene resultados de cálculos complexos em variáveis para reutilização.

3. **Use estruturas de dados apropriadas**: Escolha as estruturas de dados mais adequadas para cada caso.

4. **Otimize consultas FHIR**: Limite o número de campos retornados em consultas FHIR para melhorar o desempenho.

### Interoperabilidade

1. **Adote o padrão FHIR**: Use o padrão FHIR para garantir interoperabilidade com outros sistemas de saúde.

2. **Use terminologias padrão**: Utilize terminologias padrão como SNOMED CT, LOINC e RxNorm para codificar informações médicas.

3. **Implemente APIs RESTful**: Exponha funcionalidades através de APIs RESTful para facilitar a integração com outros sistemas.

### Desenvolvimento

1. **Use o REPL para prototipagem**: O ambiente REPL é ideal para testar ideias e prototipar soluções.

2. **Documente seu código**: Adicione comentários e documentação ao seu código para facilitar a manutenção.

3. **Escreva testes**: Crie testes automatizados para garantir a qualidade do seu código.

4. **Siga as convenções de nomenclatura**: Use nomes descritivos e siga as convenções de nomenclatura da linguagem.

5. **Modularize seu código**: Divida seu código em módulos e funções reutilizáveis.

## Referência da API

### Módulo `fhir`

#### Funções

- **connect_fhir(base_url, auth_token)**: Conecta a um servidor FHIR.
- **fhir_create(client, resource)**: Cria um recurso FHIR.
- **fhir_read(client, resourceType, id)**: Lê um recurso FHIR.
- **fhir_update(client, resource)**: Atualiza um recurso FHIR.
- **fhir_delete(client, resourceType, id)**: Exclui um recurso FHIR.
- **fhir_search(client, resourceType, params)**: Pesquisa recursos FHIR.

### Módulo `prescription`

#### Funções

- **prescribe(patient, medication, dose, frequency, duration, instructions, prescriber)**: Cria uma prescrição.
- **safety_check(prescription)**: Verifica a segurança de uma prescrição.
- **issue(prescription)**: Emite uma prescrição.
- **cancel(prescription, reason)**: Cancela uma prescrição.
- **renew(prescription, duration, refills)**: Renova uma prescrição.

### Módulo `hospital_workflow`

#### Funções

- **admit_patient(patient, location, reason, attending)**: Interna um paciente.
- **transfer_patient(encounter, new_location, reason)**: Transfere um paciente.
- **discharge_patient(encounter, notes)**: Dá alta a um paciente.
- **schedule_appointment(patient, practitioner, time, reason)**: Agenda uma consulta.
- **check_in_patient(appointment, time)**: Registra a chegada do paciente.
- **start_appointment(appointment)**: Inicia uma consulta.
- **end_appointment(appointment, notes)**: Finaliza uma consulta.

### Módulo `security`

#### Funções

- **init(log_file)**: Inicializa o gerenciador de segurança.
- **authenticate(username, password)**: Autentica um usuário.
- **check_permission(permission)**: Verifica se o usuário atual tem uma permissão.
- **require_permission(permission)**: Lança uma exceção se o usuário atual não tiver uma permissão.
- **encrypt_data(data)**: Criptografa dados.
- **decrypt_data(encrypted_data)**: Descriptografa dados.
- **anonymize_patient_data(patient_data)**: Anonimiza dados de paciente.
- **audit_log(action, resource, resource_id, details)**: Registra uma ação no log de auditoria.
- **get_audit_logs(filters)**: Obtém logs de auditoria com base em filtros.

## Solução de Problemas

### Erros Comuns

#### Erro: "Patient not found"

Este erro ocorre quando você tenta acessar um paciente que não existe no sistema.

Solução: Verifique se o ID do paciente está correto e se o paciente foi adicionado ao sistema.

#### Erro: "Medication is contraindicated for patient"

Este erro ocorre quando você tenta prescrever um medicamento que é contraindicado para o paciente.

Solução: Verifique as contraindicações do medicamento e as condições do paciente. Escolha um medicamento alternativo se necessário.

#### Erro: "Prescriber does not have rights to prescribe controlled substances"

Este erro ocorre quando um prescritor tenta prescrever uma substância controlada sem ter os direitos necessários.

Solução: Verifique os direitos de prescrição do prescritor. Apenas prescritores com direitos para substâncias controladas podem prescrever medicamentos controlados.

#### Erro: "Daily dose exceeds maximum recommended dose"

Este erro ocorre quando a dose diária de um medicamento excede a dose máxima recomendada.

Solução: Ajuste a dose ou a frequência para garantir que a dose diária esteja dentro dos limites seguros.

### Depuração

#### Usando o REPL para Depuração

O ambiente REPL é uma ferramenta poderosa para depuração:

```
charcot> vars
Variáveis definidas:
  Patient1 (Patient): {...}
  Paracetamol (Medication): {...}
  new_rx (Prescription): {...}
```

#### Usando Logs

Adicione logs ao seu código para rastrear a execução:

```
print(f"Verificando segurança da prescrição: {prescription.id}")
safety_result = safety_check(prescription)
print(f"Resultado da verificação: {safety_result.status}")
```

#### Usando Try-Except

Use blocos try-except para capturar e tratar erros:

```
try:
    prescription = prescribe(...)
except ContraindicacaoError as e:
    print(f"Erro de contraindicação: {e}")
except DosagemError as e:
    print(f"Erro de dosagem: {e}")
except Exception as e:
    print(f"Erro desconhecido: {e}")
```

## Contribuindo

### Reportando Bugs

Se você encontrar um bug na linguagem Charcot, por favor, reporte-o no [GitHub Issues](https://github.com/charcot-lang/charcot/issues) com as seguintes informações:

- Descrição detalhada do bug
- Passos para reproduzir o bug
- Comportamento esperado
- Comportamento observado
- Versão da linguagem Charcot
- Sistema operacional e versão

### Solicitando Recursos

Se você gostaria de solicitar um novo recurso para a linguagem Charcot, por favor, abra uma issue no [GitHub Issues](https://github.com/charcot-lang/charcot/issues) com as seguintes informações:

- Descrição detalhada do recurso
- Casos de uso para o recurso
- Exemplos de como o recurso seria usado

### Contribuindo com Código

Se você gostaria de contribuir com código para a linguagem Charcot, por favor, siga estes passos:

1. Faça um fork do repositório
2. Crie uma branch para sua feature (`git checkout -b feature/nova-feature`)
3. Faça commit das suas mudanças (`git commit -am 'Adiciona nova feature'`)
4. Faça push para a branch (`git push origin feature/nova-feature`)
5. Abra um Pull Request

### Diretrizes de Código

- Siga as convenções de nomenclatura da linguagem
- Adicione testes para novas funcionalidades
- Atualize a documentação para refletir suas mudanças
- Mantenha o código limpo e legível
- Escreva mensagens de commit claras e descritivas

## Conclusão

A linguagem Charcot é uma ferramenta poderosa para o desenvolvimento de aplicações médicas seguras, eficientes e interoperáveis. Com sua sintaxe intuitiva, recursos específicos para medicina e integração nativa com padrões como FHIR, a linguagem Charcot permite que desenvolvedores criem soluções inovadoras para o setor de saúde.

Este guia do usuário fornece uma visão abrangente da linguagem Charcot, mas é apenas o começo. À medida que você explora a linguagem e desenvolve aplicações médicas, você descobrirá ainda mais recursos e possibilidades.

Agradecemos por escolher a linguagem Charcot para suas aplicações médicas. Estamos ansiosos para ver o que você vai criar!

---

© 2025 Charcot Language Team. Todos os direitos reservados.
