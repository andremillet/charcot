# Linguagem de Programação Charcot - Referência Rápida

## Sintaxe Básica

### Variáveis e Atribuição
```
nome = "João Silva"
idade = 42
peso = 70.5
ativo = true
```

### Tipos Básicos
```
# Números
idade = 42
peso = 70.5

# Strings
nome = "João Silva"
texto = """
Múltiplas
linhas
"""

# Booleanos
ativo = true
internado = false

# Listas
alergias = ["penicilina", "sulfa"]

# Dicionários
paciente = {
    "nome": "João Silva",
    "idade": 42
}
```

### Estruturas de Controle
```
# If-Elif-Else
if idade > 65:
    print("Paciente idoso")
elif idade < 18:
    print("Paciente pediátrico")
else:
    print("Paciente adulto")

# For
for alergia in alergias:
    print(f"Alérgico a {alergia}")

# While
i = 0
while i < 5:
    print(i)
    i += 1
```

### Funções
```
def calcular_imc(peso, altura):
    return peso / (altura ** 2)

# Chamada com parâmetros nomeados
imc = calcular_imc(
    peso: 70.5,
    altura: 1.75
)
```

## Tipos Específicos para Medicina

### Patient (Paciente)
```
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175,
    allergies: ["penicillin"],
    conditions: ["hypertension"]
}

# Métodos
bmi = Patient1.calculate_bmi()
age = Patient1.calculate_age()
```

### Medication (Medicamento)
```
medication Paracetamol {
    active_ingredient: "Acetaminophen",
    strength: "500 mg",
    form: "tablet",
    route: "oral",
    max_daily_dose: "4000 mg",
    contraindications: ["liver failure"]
}
```

### Prescription (Prescrição)
```
prescription new_rx {
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    frequency: "every 6 hours",
    duration: 5,
    instructions: "Take with water for pain relief"
}

# Verificação de segurança
safety_result = safety_check(new_rx)

# Emitir prescrição
if safety_result.is_safe:
    issue(new_rx)
```

## Workflows Hospitalares

### Internação
```
# Admissão
encounter = admit_patient(
    patient: Patient1,
    location: Room101,
    reason: "Pneumonia",
    attending: Doctor1
)

# Transferência
transfer_patient(
    encounter: encounter,
    new_location: Room202,
    reason: "Necessidade de monitoramento"
)

# Alta
discharge_patient(
    encounter: encounter,
    notes: "Paciente recuperado"
)
```

### Medicação
```
# Administração
administer_medication(
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    route: "oral",
    time: now()
)
```

## Integração FHIR

### Cliente FHIR
```
fhir_client = fhir.connect(
    base_url: "http://hapi.fhir.org/baseR4"
)
```

### Operações FHIR
```
# Criar
patient_resource = fhir_create(
    client: fhir_client,
    resource: patient_data
)

# Ler
patient = fhir_read(
    client: fhir_client,
    resourceType: "Patient",
    id: patient_id
)

# Pesquisar
results = fhir_search(
    client: fhir_client,
    resourceType: "Patient",
    params: {
        "family": "Silva"
    }
)
```

## Segurança e Privacidade

### Autenticação
```
if security_manager.authenticate("dr.silva", "senha123"):
    # Usuário autenticado
```

### Criptografia
```
# Criptografar
encrypted = security_manager.encrypt_data(data)

# Descriptografar
decrypted = security_manager.decrypt_data(encrypted)
```

### Anonimização
```
anonymized = security_manager.anonymize_patient_data(patient_data)
```

## Ambiente REPL

Iniciar o REPL:
```bash
charcot
```

Comandos do REPL:
- **help**: Exibe ajuda
- **examples**: Lista exemplos
- **example <nome>**: Carrega exemplo
- **load <arquivo>**: Carrega arquivo
- **save <arquivo>**: Salva histórico
- **vars**: Lista variáveis
- **exit**: Sai do REPL

## Exemplos Comuns

### Cálculo de IMC
```
patient Patient1 {
    name: "João Silva",
    weight: 70.5,
    height: 175
}

bmi = Patient1.weight / ((Patient1.height / 100) ** 2)
print(f"IMC: {bmi:.1f}")
```

### Verificação de Prescrição
```
prescription rx {
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    frequency: "every 6 hours"
}

if safety_check(rx).is_safe:
    issue(rx)
    print("Prescrição emitida")
else:
    print("Prescrição não segura")
```
