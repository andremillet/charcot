#!/usr/bin/env python3
"""
Analisador Léxico para a Linguagem Charcot

Este módulo implementa o analisador léxico (scanner) para a linguagem Charcot,
responsável por transformar o código-fonte em uma sequência de tokens.
"""

import re
from enum import Enum, auto
from dataclasses import dataclass
from typing import List, Optional, Tuple, Dict, Any


class TokenType(Enum):
    """Tipos de tokens suportados pela linguagem Charcot."""
    # Tokens de uma única letra
    LEFT_PAREN = auto()    # (
    RIGHT_PAREN = auto()   # )
    LEFT_BRACE = auto()    # {
    RIGHT_BRACE = auto()   # }
    LEFT_BRACKET = auto()  # [
    RIGHT_BRACKET = auto() # ]
    COMMA = auto()         # ,
    DOT = auto()           # .
    MINUS = auto()         # -
    PLUS = auto()          # +
    SEMICOLON = auto()     # ;
    SLASH = auto()         # /
    STAR = auto()          # *
    COLON = auto()         # :
    
    # Tokens de um ou dois caracteres
    BANG = auto()          # !
    BANG_EQUAL = auto()    # !=
    EQUAL = auto()         # =
    EQUAL_EQUAL = auto()   # ==
    GREATER = auto()       # >
    GREATER_EQUAL = auto() # >=
    LESS = auto()          # <
    LESS_EQUAL = auto()    # <=
    ARROW = auto()         # ->
    PLUS_EQUAL = auto()    # +=
    MINUS_EQUAL = auto()   # -=
    STAR_EQUAL = auto()    # *=
    SLASH_EQUAL = auto()   # /=
    PERCENT = auto()       # %
    PERCENT_EQUAL = auto() # %=
    POWER = auto()         # **
    
    # Literais
    IDENTIFIER = auto()    # identificadores
    STRING = auto()        # strings
    NUMBER = auto()        # números
    
    # Palavras-chave
    AND = auto()           # and
    BREAK = auto()         # break
    CATCH = auto()         # catch
    CLASS = auto()         # class
    CONST = auto()         # const
    CONTINUE = auto()      # continue
    ELSE = auto()          # else
    FALSE = auto()         # false
    FN = auto()            # fn
    FOR = auto()           # for
    IF = auto()            # if
    IMPORT = auto()        # import
    FROM = auto()          # from
    IN = auto()            # in
    LET = auto()           # let
    MATCH = auto()         # match
    MODULE = auto()        # module
    MUT = auto()           # mut
    NONE = auto()          # None
    OR = auto()            # or
    PROCEDURE = auto()     # procedure
    RETURN = auto()        # return
    STRUCT = auto()        # struct
    TRY = auto()           # try
    TRUE = auto()          # true
    TYPE = auto()          # type
    WHILE = auto()         # while
    WITH = auto()          # with
    
    # Palavras-chave específicas para medicina
    PATIENT = auto()       # patient
    MEDICATION = auto()    # medication
    DOSE = auto()          # dose
    ADMIT = auto()         # admit
    TRANSFER = auto()      # transfer
    DISCHARGE = auto()     # discharge
    PRESCRIPTION = auto()  # prescription
    WORKFLOW = auto()      # workflow
    VERIFY = auto()        # verify
    AUDIT = auto()         # audit
    FHIR = auto()          # fhir
    
    # Tokens especiais
    INDENT = auto()        # indentação
    DEDENT = auto()        # dedentação
    NEWLINE = auto()       # nova linha
    EOF = auto()           # fim do arquivo
    ERROR = auto()         # erro


@dataclass
class Token:
    """Representa um token na linguagem Charcot."""
    type: TokenType
    lexeme: str
    literal: Any
    line: int
    column: int
    
    def __str__(self) -> str:
        literal_str = f" {self.literal}" if self.literal is not None else ""
        return f"{self.type.name} '{self.lexeme}'{literal_str} at line {self.line}, column {self.column}"


class Lexer:
    """
    Analisador léxico para a linguagem Charcot.
    
    Converte o código-fonte em uma sequência de tokens, lidando com
    indentação para definir blocos de código (similar a Python).
    """
    
    # Palavras-chave da linguagem
    KEYWORDS: Dict[str, TokenType] = {
        "and": TokenType.AND,
        "break": TokenType.BREAK,
        "catch": TokenType.CATCH,
        "class": TokenType.CLASS,
        "const": TokenType.CONST,
        "continue": TokenType.CONTINUE,
        "else": TokenType.ELSE,
        "false": TokenType.FALSE,
        "fn": TokenType.FN,
        "for": TokenType.FOR,
        "if": TokenType.IF,
        "import": TokenType.IMPORT,
        "from": TokenType.FROM,
        "in": TokenType.IN,
        "let": TokenType.LET,
        "match": TokenType.MATCH,
        "module": TokenType.MODULE,
        "mut": TokenType.MUT,
        "None": TokenType.NONE,
        "or": TokenType.OR,
        "procedure": TokenType.PROCEDURE,
        "return": TokenType.RETURN,
        "struct": TokenType.STRUCT,
        "try": TokenType.TRY,
        "true": TokenType.TRUE,
        "type": TokenType.TYPE,
        "while": TokenType.WHILE,
        "with": TokenType.WITH,
        
        # Palavras-chave específicas para medicina
        "patient": TokenType.PATIENT,
        "medication": TokenType.MEDICATION,
        "dose": TokenType.DOSE,
        "admit": TokenType.ADMIT,
        "transfer": TokenType.TRANSFER,
        "discharge": TokenType.DISCHARGE,
        "prescription": TokenType.PRESCRIPTION,
        "workflow": TokenType.WORKFLOW,
        "verify": TokenType.VERIFY,
        "audit": TokenType.AUDIT,
        "fhir": TokenType.FHIR,
    }
    
    def __init__(self, source: str):
        self.source = source
        self.tokens: List[Token] = []
        
        # Estado do scanner
        self.start = 0
        self.current = 0
        self.line = 1
        self.column = 1
        self.start_column = 1
        
        # Controle de indentação
        self.indent_stack = [0]  # Começamos sem indentação
        self.pending_dedents = 0
        self.at_line_start = True
        self.current_indent = 0
    
    def scan_tokens(self) -> List[Token]:
        """
        Escaneia o código-fonte e retorna a lista de tokens.
        
        Returns:
            List[Token]: Lista de tokens encontrados no código-fonte.
        """
        while not self.is_at_end():
            # Começamos um novo lexema
            self.start = self.current
            self.start_column = self.column
            self.scan_token()
        
        # Adiciona dedents pendentes no final do arquivo
        while self.indent_stack[-1] > 0:
            self.indent_stack.pop()
            self.add_token(TokenType.DEDENT)
        
        # Adiciona o token EOF
        self.add_token(TokenType.EOF)
        return self.tokens
    
    def is_at_end(self) -> bool:
        """Verifica se chegamos ao final do código-fonte."""
        return self.current >= len(self.source)
    
    def advance(self) -> str:
        """
        Avança para o próximo caractere e retorna o atual.
        
        Returns:
            str: O caractere atual.
        """
        char = self.source[self.current]
        self.current += 1
        self.column += 1
        return char
    
    def peek(self) -> str:
        """
        Retorna o caractere atual sem avançar.
        
        Returns:
            str: O caractere atual ou '\0' se estiver no final.
        """
        if self.is_at_end():
            return '\0'
        return self.source[self.current]
    
    def peek_next(self) -> str:
        """
        Retorna o próximo caractere sem avançar.
        
        Returns:
            str: O próximo caractere ou '\0' se estiver no final.
        """
        if self.current + 1 >= len(self.source):
            return '\0'
        return self.source[self.current + 1]
    
    def match(self, expected: str) -> bool:
        """
        Verifica se o próximo caractere é o esperado e avança se for.
        
        Args:
            expected (str): O caractere esperado.
            
        Returns:
            bool: True se o caractere for o esperado, False caso contrário.
        """
        if self.is_at_end() or self.source[self.current] != expected:
            return False
        
        self.current += 1
        self.column += 1
        return True
    
    def add_token(self, token_type: TokenType, literal: Any = None) -> None:
        """
        Adiciona um token à lista de tokens.
        
        Args:
            token_type (TokenType): O tipo do token.
            literal (Any, optional): O valor literal do token. Defaults to None.
        """
        text = self.source[self.start:self.current]
        self.tokens.append(Token(token_type, text, literal, self.line, self.start_column))
    
    def handle_indentation(self) -> None:
        """
        Processa a indentação no início de uma linha.
        Gera tokens INDENT e DEDENT conforme necessário.
        """
        if not self.at_line_start:
            return
        
        self.at_line_start = False
        
        # Conta espaços no início da linha
        spaces = 0
        while self.peek() == ' ':
            spaces += 1
            self.advance()
        
        # Se a linha está vazia ou é um comentário, ignora a indentação
        if self.peek() == '\n' or self.peek() == '#':
            return
        
        # Compara com o nível de indentação atual
        current_indent = self.indent_stack[-1]
        
        if spaces > current_indent:
            # Indentação aumentou
            self.indent_stack.append(spaces)
            self.add_token(TokenType.INDENT)
        elif spaces < current_indent:
            # Indentação diminuiu
            while self.indent_stack and spaces < self.indent_stack[-1]:
                self.indent_stack.pop()
                self.add_token(TokenType.DEDENT)
            
            # Verifica se a indentação está correta
            if self.indent_stack and spaces != self.indent_stack[-1]:
                self.error("Indentação inconsistente")
    
    def scan_token(self) -> None:
        """Escaneia um único token."""
        # Processa indentação no início da linha
        if self.at_line_start:
            self.handle_indentation()
        
        char = self.advance()
        
        # Caracteres simples
        if char == '(':
            self.add_token(TokenType.LEFT_PAREN)
        elif char == ')':
            self.add_token(TokenType.RIGHT_PAREN)
        elif char == '{':
            self.add_token(TokenType.LEFT_BRACE)
        elif char == '}':
            self.add_token(TokenType.RIGHT_BRACE)
        elif char == '[':
            self.add_token(TokenType.LEFT_BRACKET)
        elif char == ']':
            self.add_token(TokenType.RIGHT_BRACKET)
        elif char == ',':
            self.add_token(TokenType.COMMA)
        elif char == '.':
            self.add_token(TokenType.DOT)
        elif char == '-':
            if self.match('>'):
                self.add_token(TokenType.ARROW)
            elif self.match('='):
                self.add_token(TokenType.MINUS_EQUAL)
            else:
                self.add_token(TokenType.MINUS)
        elif char == '+':
            if self.match('='):
                self.add_token(TokenType.PLUS_EQUAL)
            else:
                self.add_token(TokenType.PLUS)
        elif char == ';':
            self.add_token(TokenType.SEMICOLON)
        elif char == '*':
            if self.match('*'):
                self.add_token(TokenType.POWER)
            elif self.match('='):
                self.add_token(TokenType.STAR_EQUAL)
            else:
                self.add_token(TokenType.STAR)
        elif char == ':':
            self.add_token(TokenType.COLON)
        elif char == '%':
            if self.match('='):
                self.add_token(TokenType.PERCENT_EQUAL)
            else:
                self.add_token(TokenType.PERCENT)
        
        # Operadores de um ou dois caracteres
        elif char == '!':
            self.add_token(TokenType.BANG_EQUAL if self.match('=') else TokenType.BANG)
        elif char == '=':
            self.add_token(TokenType.EQUAL_EQUAL if self.match('=') else TokenType.EQUAL)
        elif char == '<':
            self.add_token(TokenType.LESS_EQUAL if self.match('=') else TokenType.LESS)
        elif char == '>':
            self.add_token(TokenType.GREATER_EQUAL if self.match('=') else TokenType.GREATER)
        
        # Comentários e divisão
        elif char == '/':
            if self.match('='):
                self.add_token(TokenType.SLASH_EQUAL)
            else:
                self.add_token(TokenType.SLASH)
        
        # Comentários
        elif char == '#':
            if self.match('['):
                self.block_comment()
            elif self.match('#'):
                self.doc_comment()
            else:
                self.line_comment()
        
        # Espaços em branco
        elif char == ' ' or char == '\r' or char == '\t':
            # Ignora espaços em branco
            pass
        
        # Nova linha
        elif char == '\n':
            self.add_token(TokenType.NEWLINE)
            self.line += 1
            self.column = 1
            self.at_line_start = True
        
        # Literais
        elif char == '"' or char == "'":
            self.string(char)
        elif self.is_digit(char):
            self.number()
        elif self.is_alpha(char):
            self.identifier()
        
        else:
            self.error(f"Caractere inesperado: '{char}'")
    
    def block_comment(self) -> None:
        """Processa um comentário de bloco #[ ... ]#."""
        # Consome caracteres até encontrar ]#
        nesting = 1
        while nesting > 0 and not self.is_at_end():
            if self.peek() == '#' and self.peek_next() == '[':
                self.advance()
                self.advance()
                nesting += 1
            elif self.peek() == ']' and self.peek_next() == '#':
                self.advance()
                self.advance()
                nesting -= 1
            elif self.peek() == '\n':
                self.advance()
                self.line += 1
                self.column = 1
            else:
                self.advance()
        
        if self.is_at_end() and nesting > 0:
            self.error("Comentário de bloco não fechado")
    
    def doc_comment(self) -> None:
        """Processa um comentário de documentação ## ... ."""
        # Consome caracteres até o final da linha
        while self.peek() != '\n' and not self.is_at_end():
            self.advance()
    
    def line_comment(self) -> None:
        """Processa um comentário de linha # ... ."""
        # Consome caracteres até o final da linha
        while self.peek() != '\n' and not self.is_at_end():
            self.advance()
    
    def string(self, quote: str) -> None:
        """
        Processa uma string literal.
        
        Args:
            quote (str): O caractere de aspas que delimita a string.
        """
        # Consome caracteres até encontrar a aspas de fechamento
        while self.peek() != quote and not self.is_at_end():
            if self.peek() == '\n':
                self.line += 1
                self.column = 1
            self.advance()
        
        if self.is_at_end():
            self.error("String não fechada")
            return
        
        # Consome a aspas de fechamento
        self.advance()
        
        # Extrai o valor da string (sem as aspas)
        value = self.source[self.start + 1:self.current - 1]
        self.add_token(TokenType.STRING, value)
    
    def number(self) -> None:
        """Processa um número literal."""
        # Consome dígitos
        while self.is_digit(self.peek()):
            self.advance()
        
        # Verifica se é um número decimal
        if self.peek() == '.' and self.is_digit(self.peek_next()):
            # Consome o ponto
            self.advance()
            
            # Consome os dígitos após o ponto
            while self.is_digit(self.peek()):
                self.advance()
        
        # Converte para o valor numérico
        value = float(self.source[self.start:self.current])
        # Se for um inteiro, converte para int
        if value.is_integer():
            value = int(value)
        
        self.add_token(TokenType.NUMBER, value)
    
    def identifier(self) -> None:
        """Processa um identificador ou palavra-chave."""
        # Consome letras, dígitos e underscores
        while self.is_alphanumeric(self.peek()):
            self.advance()
        
        # Verifica se é uma palavra-chave
        text = self.source[self.start:self.current]
        token_type = self.KEYWORDS.get(text, TokenType.IDENTIFIER)
        
        self.add_token(token_type)
    
    def is_digit(self, char: str) -> bool:
        """Verifica se um caractere é um dígito."""
        return char >= '0' and char <= '9'
    
    def is_alpha(self, char: str) -> bool:
        """Verifica se um caractere é uma letra ou underscore."""
        return (char >= 'a' and char <= 'z') or \
               (char >= 'A' and char <= 'Z') or \
               char == '_'
    
    def is_alphanumeric(self, char: str) -> bool:
        """Verifica se um caractere é alfanumérico ou underscore."""
        return self.is_alpha(char) or self.is_digit(char)
    
    def error(self, message: str) -> None:
        """
        Reporta um erro léxico.
        
        Args:
            message (str): A mensagem de erro.
        """
        self.tokens.append(Token(
            TokenType.ERROR,
            self.source[self.start:self.current],
            message,
            self.line,
            self.start_column
        ))


def tokenize(source: str) -> List[Token]:
    """
    Função auxiliar para tokenizar uma string de código-fonte.
    
    Args:
        source (str): O código-fonte a ser tokenizado.
        
    Returns:
        List[Token]: A lista de tokens encontrados.
    """
    lexer = Lexer(source)
    return lexer.scan_tokens()


if __name__ == "__main__":
    # Exemplo de uso
    code = """
# Este é um exemplo de código Charcot

fn calcular_dose(peso: float, medicamento: Medication) -> Dose:
    if peso < 10:
        return Dose(peso * 0.1, "mg")
    else:
        return Dose(peso * 0.2, "mg")

paciente = Patient {
    id: "P12345",
    nome: "João Silva",
    peso: 70.5
}

dose = calcular_dose(paciente.peso, medicamentos.paracetamol)
print(f"Dose recomendada: {dose}")
"""
    
    tokens = tokenize(code)
    for token in tokens:
        print(token)
