#!/usr/bin/env python3
"""
Interpretador para a Linguagem Charcot

Este módulo implementa o interpretador para a linguagem Charcot,
responsável por executar programas Charcot.
"""

from typing import Dict, List, Any, Optional, Callable, Union
from dataclasses import dataclass
from enum import Enum, auto
import time
import math

from lexer import Token, TokenType
from parser import Node, NodeType, Expression, Statement, Binary, Unary, Literal, Grouping
from parser import Variable, Assign, Call, Get, Set, Logical, Block, ExpressionStmt
from parser import Function, If, Return, Let, While, For, Struct, Import, Procedure, Match
from type_checker import Type, TypeKind, PrimitiveType, StructType, FunctionType


class RuntimeError(Exception):
    """Exceção lançada quando ocorre um erro em tempo de execução."""
    def __init__(self, token: Token, message: str):
        self.token = token
        self.message = message
        super().__init__(f"[linha {token.line}, coluna {token.column}] {message}")


class ReturnValue(Exception):
    """Exceção usada para implementar a declaração return."""
    def __init__(self, value: Any):
        self.value = value
        super().__init__()


class BreakException(Exception):
    """Exceção usada para implementar a declaração break."""
    pass


class ContinueException(Exception):
    """Exceção usada para implementar a declaração continue."""
    pass


class CharcotCallable:
    """Interface para objetos chamáveis em Charcot."""
    def call(self, interpreter: 'Interpreter', arguments: List[Any]) -> Any:
        """
        Chama o objeto com os argumentos fornecidos.
        
        Args:
            interpreter (Interpreter): O interpretador.
            arguments (List[Any]): Os argumentos para a chamada.
            
        Returns:
            Any: O resultado da chamada.
        """
        raise NotImplementedError()
    
    def arity(self) -> int:
        """
        Retorna o número de argumentos que o objeto espera.
        
        Returns:
            int: O número de argumentos.
        """
        raise NotImplementedError()


class CharcotFunction(CharcotCallable):
    """Representa uma função definida pelo usuário em Charcot."""
    def __init__(self, declaration: Function, closure: Dict[str, Any], is_initializer: bool = False):
        self.declaration = declaration
        self.closure = closure
        self.is_initializer = is_initializer
    
    def call(self, interpreter: 'Interpreter', arguments: List[Any]) -> Any:
        """
        Chama a função com os argumentos fornecidos.
        
        Args:
            interpreter (Interpreter): O interpretador.
            arguments (List[Any]): Os argumentos para a chamada.
            
        Returns:
            Any: O resultado da chamada.
        """
        # Criar ambiente para a execução da função
        environment = Environment(self.closure)
        
        # Definir parâmetros no ambiente
        for i, param in enumerate(self.declaration.params):
            environment.define(param.lexeme, arguments[i])
        
        try:
            # Executar corpo da função
            interpreter.execute_block(self.declaration.body, environment)
        except ReturnValue as return_value:
            # Capturar valor de retorno
            if self.is_initializer:
                # Se for um inicializador, retornar 'this'
                return self.closure.get("this")
            return return_value.value
        
        # Se não houver return, retornar None
        if self.is_initializer:
            return self.closure.get("this")
        return None
    
    def arity(self) -> int:
        """
        Retorna o número de parâmetros da função.
        
        Returns:
            int: O número de parâmetros.
        """
        return len(self.declaration.params)
    
    def __str__(self) -> str:
        return f"<fn {self.declaration.name.lexeme}>"


class CharcotProcedure(CharcotCallable):
    """Representa um procedimento médico definido pelo usuário em Charcot."""
    def __init__(self, declaration: Procedure, closure: Dict[str, Any]):
        self.declaration = declaration
        self.closure = closure
    
    def call(self, interpreter: 'Interpreter', arguments: List[Any]) -> Any:
        """
        Chama o procedimento com os argumentos fornecidos.
        
        Args:
            interpreter (Interpreter): O interpretador.
            arguments (List[Any]): Os argumentos para a chamada.
            
        Returns:
            Any: O resultado da chamada.
        """
        # Criar ambiente para a execução do procedimento
        environment = Environment(self.closure)
        
        # Definir parâmetros no ambiente
        for i, param in enumerate(self.declaration.params):
            environment.define(param.lexeme, arguments[i])
        
        # Verificar verificações do procedimento
        for verification in self.declaration.verifications:
            result = interpreter.evaluate(verification)
            if not interpreter.is_truthy(result):
                raise RuntimeError(self.declaration.name, f"Verificação falhou: {verification}")
        
        try:
            # Executar corpo do procedimento
            interpreter.execute_block(self.declaration.body, environment)
        except ReturnValue as return_value:
            # Capturar valor de retorno
            return return_value.value
        
        # Se não houver return, retornar None
        return None
    
    def arity(self) -> int:
        """
        Retorna o número de parâmetros do procedimento.
        
        Returns:
            int: O número de parâmetros.
        """
        return len(self.declaration.params)
    
    def __str__(self) -> str:
        return f"<procedure {self.declaration.name.lexeme}>"


class CharcotStruct:
    """Representa uma instância de uma estrutura definida pelo usuário em Charcot."""
    def __init__(self, name: str, fields: Dict[str, Any] = None):
        self.name = name
        self.fields = fields or {}
    
    def get(self, name: str) -> Any:
        """
        Obtém o valor de um campo.
        
        Args:
            name (str): O nome do campo.
            
        Returns:
            Any: O valor do campo.
            
        Raises:
            AttributeError: Se o campo não existir.
        """
        if name in self.fields:
            return self.fields[name]
        raise AttributeError(f"'{self.name}' não tem atributo '{name}'")
    
    def set(self, name: str, value: Any):
        """
        Define o valor de um campo.
        
        Args:
            name (str): O nome do campo.
            value (Any): O valor a ser definido.
        """
        self.fields[name] = value
    
    def __str__(self) -> str:
        fields_str = ", ".join(f"{k}: {v}" for k, v in self.fields.items())
        return f"{self.name} {{ {fields_str} }}"


class NativeFunction(CharcotCallable):
    """Representa uma função nativa em Charcot."""
    def __init__(self, arity_count: int, function: Callable):
        self.arity_count = arity_count
        self.function = function
    
    def call(self, interpreter: 'Interpreter', arguments: List[Any]) -> Any:
        """
        Chama a função nativa com os argumentos fornecidos.
        
        Args:
            interpreter (Interpreter): O interpretador.
            arguments (List[Any]): Os argumentos para a chamada.
            
        Returns:
            Any: O resultado da chamada.
        """
        return self.function(*arguments)
    
    def arity(self) -> int:
        """
        Retorna o número de argumentos que a função nativa espera.
        
        Returns:
            int: O número de argumentos.
        """
        return self.arity_count
    
    def __str__(self) -> str:
        return "<native fn>"


class Environment:
    """Ambiente de execução para a linguagem Charcot."""
    def __init__(self, enclosing: Optional[Dict[str, Any]] = None):
        self.values: Dict[str, Any] = {}
        self.enclosing = enclosing
    
    def define(self, name: str, value: Any):
        """
        Define uma variável no ambiente atual.
        
        Args:
            name (str): O nome da variável.
            value (Any): O valor da variável.
        """
        self.values[name] = value
    
    def get(self, name: str) -> Any:
        """
        Obtém o valor de uma variável.
        
        Args:
            name (str): O nome da variável.
            
        Returns:
            Any: O valor da variável.
            
        Raises:
            KeyError: Se a variável não estiver definida.
        """
        if name in self.values:
            return self.values[name]
        
        if self.enclosing is not None:
            if name in self.enclosing:
                return self.enclosing[name]
        
        raise KeyError(f"Variável '{name}' não definida.")
    
    def assign(self, name: str, value: Any):
        """
        Atribui um valor a uma variável existente.
        
        Args:
            name (str): O nome da variável.
            value (Any): O valor a ser atribuído.
            
        Raises:
            KeyError: Se a variável não estiver definida.
        """
        if name in self.values:
            self.values[name] = value
            return
        
        if self.enclosing is not None:
            if name in self.enclosing:
                self.enclosing[name] = value
                return
        
        raise KeyError(f"Variável '{name}' não definida.")


class Interpreter:
    """
    Interpretador para a linguagem Charcot.
    
    Responsável por executar programas Charcot.
    """
    
    def __init__(self):
        self.globals = {}
        self.environment = self.globals
        self.locals: Dict[Expression, int] = {}
        
        # Definir funções nativas
        self._define_natives()
    
    def _define_natives(self):
        """Define funções nativas no ambiente global."""
        # print
        self.globals["print"] = NativeFunction(1, lambda x: print(x))
        
        # clock
        self.globals["clock"] = NativeFunction(0, lambda: time.time())
        
        # len
        self.globals["len"] = NativeFunction(1, lambda x: len(x))
        
        # str
        self.globals["str"] = NativeFunction(1, lambda x: str(x))
        
        # int
        self.globals["int"] = NativeFunction(1, lambda x: int(x))
        
        # float
        self.globals["float"] = NativeFunction(1, lambda x: float(x))
        
        # bool
        self.globals["bool"] = NativeFunction(1, lambda x: bool(x))
        
        # range
        def range_fn(*args):
            if len(args) == 1:
                return list(range(args[0]))
            elif len(args) == 2:
                return list(range(args[0], args[1]))
            elif len(args) == 3:
                return list(range(args[0], args[1], args[2]))
            else:
                raise ValueError("range() requer 1, 2 ou 3 argumentos")
        
        self.globals["range"] = NativeFunction(-1, range_fn)
        
        # input
        self.globals["input"] = NativeFunction(1, lambda prompt: input(prompt))
        
        # Funções matemáticas
        self.globals["abs"] = NativeFunction(1, lambda x: abs(x))
        self.globals["max"] = NativeFunction(-1, lambda *args: max(args))
        self.globals["min"] = NativeFunction(-1, lambda *args: min(args))
        self.globals["sum"] = NativeFunction(1, lambda x: sum(x))
        self.globals["round"] = NativeFunction(2, lambda x, digits=0: round(x, digits))
        
        # Constantes matemáticas
        self.globals["PI"] = math.pi
        self.globals["E"] = math.e
        
        # Tipos específicos para medicina
        # Patient
        class Patient(CharcotStruct):
            def __init__(self, **kwargs):
                super().__init__("Patient", kwargs)
        
        self.globals["Patient"] = lambda **kwargs: Patient(**kwargs)
        
        # Medication
        class Medication(CharcotStruct):
            def __init__(self, **kwargs):
                super().__init__("Medication", kwargs)
        
        self.globals["Medication"] = lambda **kwargs: Medication(**kwargs)
        
        # Dose
        class Dose(CharcotStruct):
            def __init__(self, value, unit):
                super().__init__("Dose", {"value": value, "unit": unit})
            
            def __str__(self):
                return f"{self.fields['value']} {self.fields['unit']}"
        
        self.globals["Dose"] = lambda value, unit: Dose(value, unit)
        
        # Date
        class Date(CharcotStruct):
            def __init__(self, year, month, day):
                super().__init__("Date", {"year": year, "month": month, "day": day})
            
            def __str__(self):
                return f"{self.fields['year']}-{self.fields['month']:02d}-{self.fields['day']:02d}"
            
            @staticmethod
            def today():
                import datetime
                now = datetime.datetime.now()
                return Date(now.year, now.month, now.day)
        
        self.globals["Date"] = lambda year, month, day: Date(year, month, day)
        self.globals["Date"].today = Date.today
        
        # Time
        class Time(CharcotStruct):
            def __init__(self, hour, minute, second=0):
                super().__init__("Time", {"hour": hour, "minute": minute, "second": second})
            
            def __str__(self):
                return f"{self.fields['hour']:02d}:{self.fields['minute']:02d}:{self.fields['second']:02d}"
            
            @staticmethod
            def now():
                import datetime
                now = datetime.datetime.now()
                return Time(now.hour, now.minute, now.second)
        
        self.globals["Time"] = lambda hour, minute, second=0: Time(hour, minute, second)
        self.globals["Time"].now = Time.now
        
        # DateTime
        class DateTime(CharcotStruct):
            def __init__(self, year, month, day, hour=0, minute=0, second=0):
                super().__init__("DateTime", {
                    "year": year, "month": month, "day": day,
                    "hour": hour, "minute": minute, "second": second
                })
            
            def __str__(self):
                return f"{self.fields['year']}-{self.fields['month']:02d}-{self.fields['day']:02d} " \
                       f"{self.fields['hour']:02d}:{self.fields['minute']:02d}:{self.fields['second']:02d}"
            
            @staticmethod
            def now():
                import datetime
                now = datetime.datetime.now()
                return DateTime(now.year, now.month, now.day, now.hour, now.minute, now.second)
        
        self.globals["DateTime"] = lambda year, month, day, hour=0, minute=0, second=0: DateTime(year, month, day, hour, minute, second)
        self.globals["DateTime"].now = DateTime.now
    
    def interpret(self, statements: List[Statement]) -> None:
        """
        Interpreta uma lista de declarações.
        
        Args:
            statements (List[Statement]): A lista de declarações a ser interpretada.
        """
        try:
            for statement in statements:
                self.execute(statement)
        except RuntimeError as error:
            print(f"Erro em tempo de execução: {error}")
    
    def execute(self, stmt: Statement) -> None:
        """
        Executa uma declaração.
        
        Args:
            stmt (Statement): A declaração a ser executada.
        """
        if isinstance(stmt, ExpressionStmt):
            self.evaluate(stmt.expression)
        elif isinstance(stmt, Let):
            self.execute_let(stmt)
        elif isinstance(stmt, Block):
            self.execute_block(stmt.statements, Environment(self.environment))
        elif isinstance(stmt, If):
            self.execute_if(stmt)
        elif isinstance(stmt, While):
            self.execute_while(stmt)
        elif isinstance(stmt, For):
            self.execute_for(stmt)
        elif isinstance(stmt, Function):
            self.execute_function(stmt)
        elif isinstance(stmt, Return):
            self.execute_return(stmt)
        elif isinstance(stmt, Struct):
            self.execute_struct(stmt)
        elif isinstance(stmt, Import):
            self.execute_import(stmt)
        elif isinstance(stmt, Procedure):
            self.execute_procedure(stmt)
        elif isinstance(stmt, Match):
            self.execute_match(stmt)
        else:
            raise RuntimeError(Token(TokenType.ERROR, "", None, 0, 0), f"Tipo de declaração não suportado: {type(stmt).__name__}")
    
    def execute_let(self, stmt: Let) -> None:
        """
        Executa uma declaração de variável.
        
        Args:
            stmt (Let): A declaração de variável a ser executada.
        """
        value = None
        if stmt.initializer is not None:
            value = self.evaluate(stmt.initializer)
        
        self.environment.define(stmt.name.lexeme, value)
    
    def execute_if(self, stmt: If) -> None:
        """
        Executa uma declaração if.
        
        Args:
            stmt (If): A declaração if a ser executada.
        """
        if self.is_truthy(self.evaluate(stmt.condition)):
            self.execute(stmt.then_branch)
        elif stmt.else_branch is not None:
            self.execute(stmt.else_branch)
    
    def execute_while(self, stmt: While) -> None:
        """
        Executa uma declaração while.
        
        Args:
            stmt (While): A declaração while a ser executada.
        """
        try:
            while self.is_truthy(self.evaluate(stmt.condition)):
                try:
                    self.execute(stmt.body)
                except ContinueException:
                    continue
        except BreakException:
            pass
    
    def execute_for(self, stmt: For) -> None:
        """
        Executa uma declaração for.
        
        Args:
            stmt (For): A declaração for a ser executada.
        """
        iterable = self.evaluate(stmt.iterable)
        
        if not hasattr(iterable, "__iter__"):
            raise RuntimeError(stmt.variable, f"'{iterable}' não é iterável.")
        
        environment = Environment(self.environment)
        
        try:
            for item in iterable:
                environment.define(stmt.variable.lexeme, item)
                
                try:
                    self.execute_block([stmt.body], environment)
                except ContinueException:
                    continue
        except BreakException:
            pass
    
    def execute_function(self, stmt: Function) -> None:
        """
        Executa uma declaração de função.
        
        Args:
            stmt (Function): A declaração de função a ser executada.
        """
        function = CharcotFunction(stmt, self.environment)
        self.environment.define(stmt.name.lexeme, function)
    
    def execute_return(self, stmt: Return) -> None:
        """
        Executa uma declaração return.
        
        Args:
            stmt (Return): A declaração return a ser executada.
        """
        value = None
        if stmt.value is not None:
            value = self.evaluate(stmt.value)
        
        raise ReturnValue(value)
    
    def execute_struct(self, stmt: Struct) -> None:
        """
        Executa uma declaração de struct.
        
        Args:
            stmt (Struct): A declaração de struct a ser executada.
        """
        # Criar construtor para a struct
        def constructor(**kwargs):
            instance = CharcotStruct(stmt.name.lexeme)
            
            # Inicializar campos com valores padrão
            for i, field in enumerate(stmt.fields):
                instance.fields[field.lexeme] = None
            
            # Atualizar campos com valores fornecidos
            for key, value in kwargs.items():
                if key in instance.fields:
                    instance.fields[key] = value
                else:
                    raise AttributeError(f"'{stmt.name.lexeme}' não tem atributo '{key}'")
            
            return instance
        
        # Definir construtor no ambiente
        self.environment.define(stmt.name.lexeme, constructor)
    
    def execute_import(self, stmt: Import) -> None:
        """
        Executa uma declaração import.
        
        Args:
            stmt (Import): A declaração import a ser executada.
        """
        # TODO: Implementar importação de módulos
        pass
    
    def execute_procedure(self, stmt: Procedure) -> None:
        """
        Executa uma declaração de procedimento médico.
        
        Args:
            stmt (Procedure): A declaração de procedimento a ser executada.
        """
        procedure = CharcotProcedure(stmt, self.environment)
        self.environment.define(stmt.name.lexeme, procedure)
    
    def execute_match(self, stmt: Match) -> None:
        """
        Executa uma declaração match.
        
        Args:
            stmt (Match): A declaração match a ser executada.
        """
        value = self.evaluate(stmt.value)
        
        for pattern, body in stmt.cases:
            pattern_value = self.evaluate(pattern)
            
            if self.is_equal(value, pattern_value):
                self.execute(body)
                return
    
    def execute_block(self, statements: List[Statement], environment: Environment) -> None:
        """
        Executa um bloco de declarações em um novo ambiente.
        
        Args:
            statements (List[Statement]): As declarações a serem executadas.
            environment (Environment): O ambiente para execução.
        """
        previous = self.environment
        
        try:
            self.environment = environment
            
            for statement in statements:
                self.execute(statement)
        finally:
            self.environment = previous
    
    def evaluate(self, expr: Expression) -> Any:
        """
        Avalia uma expressão.
        
        Args:
            expr (Expression): A expressão a ser avaliada.
            
        Returns:
            Any: O resultado da avaliação.
        """
        if isinstance(expr, Binary):
            return self.evaluate_binary(expr)
        elif isinstance(expr, Grouping):
            return self.evaluate(expr.expression)
        elif isinstance(expr, Literal):
            return expr.value
        elif isinstance(expr, Unary):
            return self.evaluate_unary(expr)
        elif isinstance(expr, Variable):
            return self.lookup_variable(expr.name, expr)
        elif isinstance(expr, Assign):
            return self.evaluate_assign(expr)
        elif isinstance(expr, Call):
            return self.evaluate_call(expr)
        elif isinstance(expr, Get):
            return self.evaluate_get(expr)
        elif isinstance(expr, Set):
            return self.evaluate_set(expr)
        elif isinstance(expr, Logical):
            return self.evaluate_logical(expr)
        else:
            raise RuntimeError(Token(TokenType.ERROR, "", None, 0, 0), f"Tipo de expressão não suportado: {type(expr).__name__}")
    
    def evaluate_binary(self, expr: Binary) -> Any:
        """
        Avalia uma expressão binária.
        
        Args:
            expr (Binary): A expressão binária a ser avaliada.
            
        Returns:
            Any: O resultado da avaliação.
        """
        left = self.evaluate(expr.left)
        right = self.evaluate(expr.right)
        
        op = expr.operator.type
        
        # Operadores aritméticos
        if op == TokenType.PLUS:
            if isinstance(left, (int, float)) and isinstance(right, (int, float)):
                return left + right
            elif isinstance(left, str) and isinstance(right, str):
                return left + right
            else:
                raise RuntimeError(expr.operator, f"Operandos devem ser dois números ou duas strings.")
        
        elif op == TokenType.MINUS:
            self.check_number_operands(expr.operator, left, right)
            return left - right
        
        elif op == TokenType.STAR:
            self.check_number_operands(expr.operator, left, right)
            return left * right
        
        elif op == TokenType.SLASH:
            self.check_number_operands(expr.operator, left, right)
            
            if right == 0:
                raise RuntimeError(expr.operator, "Divisão por zero.")
            
            return left / right
        
        elif op == TokenType.PERCENT:
            self.check_number_operands(expr.operator, left, right)
            
            if right == 0:
                raise RuntimeError(expr.operator, "Módulo por zero.")
            
            return left % right
        
        elif op == TokenType.POWER:
            self.check_number_operands(expr.operator, left, right)
            return left ** right
        
        # Operadores de comparação
        elif op == TokenType.GREATER:
            self.check_number_operands(expr.operator, left, right)
            return left > right
        
        elif op == TokenType.GREATER_EQUAL:
            self.check_number_operands(expr.operator, left, right)
            return left >= right
        
        elif op == TokenType.LESS:
            self.check_number_operands(expr.operator, left, right)
            return left < right
        
        elif op == TokenType.LESS_EQUAL:
            self.check_number_operands(expr.operator, left, right)
            return left <= right
        
        # Operadores de igualdade
        elif op == TokenType.EQUAL_EQUAL:
            return self.is_equal(left, right)
        
        elif op == TokenType.BANG_EQUAL:
            return not self.is_equal(left, right)
        
        else:
            raise RuntimeError(expr.operator, f"Operador binário não suportado: {expr.operator.lexeme}")
    
    def evaluate_unary(self, expr: Unary) -> Any:
        """
        Avalia uma expressão unária.
        
        Args:
            expr (Unary): A expressão unária a ser avaliada.
            
        Returns:
            Any: O resultado da avaliação.
        """
        right = self.evaluate(expr.right)
        
        op = expr.operator.type
        
        if op == TokenType.MINUS:
            self.check_number_operand(expr.operator, right)
            return -right
        
        elif op == TokenType.BANG:
            return not self.is_truthy(right)
        
        else:
            raise RuntimeError(expr.operator, f"Operador unário não suportado: {expr.operator.lexeme}")
    
    def evaluate_assign(self, expr: Assign) -> Any:
        """
        Avalia uma expressão de atribuição.
        
        Args:
            expr (Assign): A expressão de atribuição a ser avaliada.
            
        Returns:
            Any: O valor atribuído.
        """
        value = self.evaluate(expr.value)
        
        distance = self.locals.get(expr)
        if distance is not None:
            self.environment.assign_at(distance, expr.name.lexeme, value)
        else:
            self.environment.assign(expr.name.lexeme, value)
        
        return value
    
    def evaluate_call(self, expr: Call) -> Any:
        """
        Avalia uma expressão de chamada.
        
        Args:
            expr (Call): A expressão de chamada a ser avaliada.
            
        Returns:
            Any: O resultado da chamada.
        """
        callee = self.evaluate(expr.callee)
        
        arguments = []
        for argument in expr.arguments:
            arguments.append(self.evaluate(argument))
        
        if not isinstance(callee, CharcotCallable) and not callable(callee):
            raise RuntimeError(expr.paren, "Só é possível chamar funções e classes.")
        
        if isinstance(callee, CharcotCallable):
            if len(arguments) != callee.arity() and callee.arity() >= 0:
                raise RuntimeError(expr.paren, f"Esperado {callee.arity()} argumentos, mas recebeu {len(arguments)}.")
            
            return callee.call(self, arguments)
        else:
            # Função nativa do Python
            try:
                return callee(*arguments)
            except Exception as e:
                raise RuntimeError(expr.paren, f"Erro ao chamar função nativa: {e}")
    
    def evaluate_get(self, expr: Get) -> Any:
        """
        Avalia uma expressão de acesso a propriedade.
        
        Args:
            expr (Get): A expressão de acesso a propriedade a ser avaliada.
            
        Returns:
            Any: O valor da propriedade.
        """
        object = self.evaluate(expr.object)
        
        if isinstance(object, CharcotStruct):
            try:
                return object.get(expr.name.lexeme)
            except AttributeError:
                raise RuntimeError(expr.name, f"Propriedade '{expr.name.lexeme}' não existe.")
        elif hasattr(object, expr.name.lexeme):
            # Acesso a atributo de objeto Python
            return getattr(object, expr.name.lexeme)
        else:
            raise RuntimeError(expr.name, "Só é possível acessar propriedades de objetos.")
    
    def evaluate_set(self, expr: Set) -> Any:
        """
        Avalia uma expressão de definição de propriedade.
        
        Args:
            expr (Set): A expressão de definição de propriedade a ser avaliada.
            
        Returns:
            Any: O valor definido.
        """
        object = self.evaluate(expr.object)
        
        if not isinstance(object, CharcotStruct):
            raise RuntimeError(expr.name, "Só é possível definir propriedades de objetos.")
        
        value = self.evaluate(expr.value)
        object.set(expr.name.lexeme, value)
        
        return value
    
    def evaluate_logical(self, expr: Logical) -> Any:
        """
        Avalia uma expressão lógica.
        
        Args:
            expr (Logical): A expressão lógica a ser avaliada.
            
        Returns:
            Any: O resultado da avaliação.
        """
        left = self.evaluate(expr.left)
        
        if expr.operator.type == TokenType.OR:
            if self.is_truthy(left):
                return left
        else:  # AND
            if not self.is_truthy(left):
                return left
        
        return self.evaluate(expr.right)
    
    def lookup_variable(self, name: Token, expr: Expression) -> Any:
        """
        Procura o valor de uma variável.
        
        Args:
            name (Token): O token do nome da variável.
            expr (Expression): A expressão da variável.
            
        Returns:
            Any: O valor da variável.
        """
        distance = self.locals.get(expr)
        if distance is not None:
            return self.environment.get_at(distance, name.lexeme)
        else:
            try:
                return self.environment.get(name.lexeme)
            except KeyError:
                raise RuntimeError(name, f"Variável '{name.lexeme}' não definida.")
    
    def is_truthy(self, value: Any) -> bool:
        """
        Verifica se um valor é considerado verdadeiro.
        
        Args:
            value (Any): O valor a ser verificado.
            
        Returns:
            bool: True se o valor for considerado verdadeiro, False caso contrário.
        """
        if value is None:
            return False
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return value != 0
        if isinstance(value, str):
            return len(value) > 0
        if isinstance(value, (list, dict, set)):
            return len(value) > 0
        return True
    
    def is_equal(self, a: Any, b: Any) -> bool:
        """
        Verifica se dois valores são iguais.
        
        Args:
            a (Any): O primeiro valor.
            b (Any): O segundo valor.
            
        Returns:
            bool: True se os valores forem iguais, False caso contrário.
        """
        if a is None and b is None:
            return True
        if a is None:
            return False
        
        return a == b
    
    def check_number_operand(self, operator: Token, operand: Any) -> None:
        """
        Verifica se um operando é um número.
        
        Args:
            operator (Token): O operador.
            operand (Any): O operando a ser verificado.
            
        Raises:
            RuntimeError: Se o operando não for um número.
        """
        if not isinstance(operand, (int, float)):
            raise RuntimeError(operator, "Operando deve ser um número.")
    
    def check_number_operands(self, operator: Token, left: Any, right: Any) -> None:
        """
        Verifica se dois operandos são números.
        
        Args:
            operator (Token): O operador.
            left (Any): O operando esquerdo.
            right (Any): O operando direito.
            
        Raises:
            RuntimeError: Se algum dos operandos não for um número.
        """
        if not isinstance(left, (int, float)) or not isinstance(right, (int, float)):
            raise RuntimeError(operator, "Operandos devem ser números.")


def run(source: str) -> None:
    """
    Executa um programa Charcot.
    
    Args:
        source (str): O código-fonte do programa.
    """
    from lexer import tokenize
    from parser import parse
    from type_checker import check_types
    
    # Tokenização
    tokens = tokenize(source)
    
    # Análise sintática
    statements, parse_errors = parse(tokens)
    
    if parse_errors:
        print("Erros de análise sintática:")
        for error in parse_errors:
            print(error)
        return
    
    # Verificação de tipos
    type_errors = check_types(statements)
    
    if type_errors:
        print("Erros de tipo:")
        for error in type_errors:
            print(error)
        return
    
    # Interpretação
    interpreter = Interpreter()
    interpreter.interpret(statements)


if __name__ == "__main__":
    # Exemplo de uso
    code = """
# Este é um exemplo de código Charcot

fn calcular_dose(peso: float, medicamento: Medication) -> Dose:
    if peso < 10:
        return Dose(peso * 0.1, "mg")
    else:
        return Dose(peso * 0.2, "mg")

paciente = Patient(
    id="P12345",
    nome="João Silva",
    peso=70.5
)

medicamento = Medication(
    id="M001",
    nome="Paracetamol",
    concentracao=500
)

dose = calcular_dose(paciente.peso, medicamento)
print(f"Dose recomendada: {dose}")
"""
    
    run(code)
