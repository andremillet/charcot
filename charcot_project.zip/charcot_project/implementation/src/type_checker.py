#!/usr/bin/env python3
"""
Sistema de Tipos para a Linguagem Charcot

Este módulo implementa o sistema de tipos para a linguagem Charcot,
responsável por verificar e inferir tipos em programas Charcot.
"""

from typing import Dict, List, Optional, Set, Union, Any, Tuple
from dataclasses import dataclass
from enum import Enum, auto

from lexer import Token, TokenType
from parser import Node, NodeType, Expression, Statement, Binary, Unary, Literal, Grouping
from parser import Variable, Assign, Call, Get, Set, Logical, Block, ExpressionStmt
from parser import Function, If, Return, Let, While, For, Struct, Import, Procedure, Match


class TypeKind(Enum):
    """Tipos de dados suportados pela linguagem Charcot."""
    PRIMITIVE = auto()    # Tipos primitivos (int, float, bool, str)
    STRUCT = auto()       # Tipos de estrutura definidos pelo usuário
    FUNCTION = auto()     # Tipos de função
    OPTION = auto()       # Tipo Option<T>
    RESULT = auto()       # Tipo Result<T, E>
    LIST = auto()         # Tipo list<T>
    DICT = auto()         # Tipo dict<K, V>
    SET = auto()          # Tipo set<T>
    TUPLE = auto()        # Tipo tuple<T1, T2, ...>
    
    # Tipos específicos para medicina
    PATIENT = auto()      # Tipo Patient
    MEDICATION = auto()   # Tipo Medication
    DOSE = auto()         # Tipo Dose
    DATE = auto()         # Tipo Date
    TIME = auto()         # Tipo Time
    DATETIME = auto()     # Tipo DateTime
    DURATION = auto()     # Tipo Duration
    VITAL_SIGNS = auto()  # Tipo VitalSigns
    
    # Tipo especial para representar qualquer tipo
    ANY = auto()          # Tipo Any (usado para inferência)
    
    # Tipo para representar ausência de valor
    NONE = auto()         # Tipo None
    
    # Tipo para representar erro
    ERROR = auto()        # Tipo Error (usado para reportar erros)


@dataclass
class Type:
    """Classe base para representar tipos na linguagem Charcot."""
    kind: TypeKind
    
    def __eq__(self, other):
        if not isinstance(other, Type):
            return False
        return self.kind == other.kind
    
    def __str__(self):
        return f"Type({self.kind})"


@dataclass
class PrimitiveType(Type):
    """Representa um tipo primitivo."""
    name: str
    
    def __init__(self, name: str):
        super().__init__(TypeKind.PRIMITIVE)
        self.name = name
    
    def __eq__(self, other):
        if not isinstance(other, PrimitiveType):
            return False
        return self.name == other.name
    
    def __str__(self):
        return self.name


@dataclass
class StructType(Type):
    """Representa um tipo de estrutura definido pelo usuário."""
    name: str
    fields: Dict[str, 'Type']
    methods: Dict[str, 'FunctionType']
    
    def __init__(self, name: str, fields: Dict[str, 'Type'], methods: Dict[str, 'FunctionType']):
        super().__init__(TypeKind.STRUCT)
        self.name = name
        self.fields = fields
        self.methods = methods
    
    def __eq__(self, other):
        if not isinstance(other, StructType):
            return False
        return self.name == other.name
    
    def __str__(self):
        return self.name


@dataclass
class FunctionType(Type):
    """Representa um tipo de função."""
    param_types: List[Type]
    return_type: Type
    
    def __init__(self, param_types: List[Type], return_type: Type):
        super().__init__(TypeKind.FUNCTION)
        self.param_types = param_types
        self.return_type = return_type
    
    def __eq__(self, other):
        if not isinstance(other, FunctionType):
            return False
        if len(self.param_types) != len(other.param_types):
            return False
        for i in range(len(self.param_types)):
            if self.param_types[i] != other.param_types[i]:
                return False
        return self.return_type == other.return_type
    
    def __str__(self):
        params = ", ".join(str(t) for t in self.param_types)
        return f"fn({params}) -> {self.return_type}"


@dataclass
class GenericType(Type):
    """Representa um tipo genérico."""
    base_type: Type
    type_args: List[Type]
    
    def __init__(self, kind: TypeKind, base_type: Type, type_args: List[Type]):
        super().__init__(kind)
        self.base_type = base_type
        self.type_args = type_args
    
    def __eq__(self, other):
        if not isinstance(other, GenericType):
            return False
        if self.kind != other.kind:
            return False
        if self.base_type != other.base_type:
            return False
        if len(self.type_args) != len(other.type_args):
            return False
        for i in range(len(self.type_args)):
            if self.type_args[i] != other.type_args[i]:
                return False
        return True
    
    def __str__(self):
        args = ", ".join(str(t) for t in self.type_args)
        return f"{self.base_type}<{args}>"


@dataclass
class OptionType(GenericType):
    """Representa um tipo Option<T>."""
    def __init__(self, value_type: Type):
        super().__init__(TypeKind.OPTION, PrimitiveType("Option"), [value_type])
    
    def __str__(self):
        return f"Option<{self.type_args[0]}>"


@dataclass
class ResultType(GenericType):
    """Representa um tipo Result<T, E>."""
    def __init__(self, value_type: Type, error_type: Type):
        super().__init__(TypeKind.RESULT, PrimitiveType("Result"), [value_type, error_type])
    
    def __str__(self):
        return f"Result<{self.type_args[0]}, {self.type_args[1]}>"


@dataclass
class ListType(GenericType):
    """Representa um tipo list<T>."""
    def __init__(self, element_type: Type):
        super().__init__(TypeKind.LIST, PrimitiveType("list"), [element_type])
    
    def __str__(self):
        return f"list[{self.type_args[0]}]"


@dataclass
class DictType(GenericType):
    """Representa um tipo dict<K, V>."""
    def __init__(self, key_type: Type, value_type: Type):
        super().__init__(TypeKind.DICT, PrimitiveType("dict"), [key_type, value_type])
    
    def __str__(self):
        return f"dict[{self.type_args[0]}, {self.type_args[1]}]"


@dataclass
class SetType(GenericType):
    """Representa um tipo set<T>."""
    def __init__(self, element_type: Type):
        super().__init__(TypeKind.SET, PrimitiveType("set"), [element_type])
    
    def __str__(self):
        return f"set[{self.type_args[0]}]"


@dataclass
class TupleType(Type):
    """Representa um tipo tuple<T1, T2, ...>."""
    element_types: List[Type]
    
    def __init__(self, element_types: List[Type]):
        super().__init__(TypeKind.TUPLE)
        self.element_types = element_types
    
    def __eq__(self, other):
        if not isinstance(other, TupleType):
            return False
        if len(self.element_types) != len(other.element_types):
            return False
        for i in range(len(self.element_types)):
            if self.element_types[i] != other.element_types[i]:
                return False
        return True
    
    def __str__(self):
        elements = ", ".join(str(t) for t in self.element_types)
        return f"tuple[{elements}]"


@dataclass
class MedicalType(Type):
    """Classe base para tipos específicos para medicina."""
    name: str
    
    def __init__(self, kind: TypeKind, name: str):
        super().__init__(kind)
        self.name = name
    
    def __eq__(self, other):
        if not isinstance(other, MedicalType):
            return False
        return self.kind == other.kind and self.name == other.name
    
    def __str__(self):
        return self.name


@dataclass
class PatientType(MedicalType):
    """Representa o tipo Patient."""
    def __init__(self):
        super().__init__(TypeKind.PATIENT, "Patient")


@dataclass
class MedicationType(MedicalType):
    """Representa o tipo Medication."""
    def __init__(self):
        super().__init__(TypeKind.MEDICATION, "Medication")


@dataclass
class DoseType(MedicalType):
    """Representa o tipo Dose."""
    def __init__(self):
        super().__init__(TypeKind.DOSE, "Dose")


@dataclass
class DateType(MedicalType):
    """Representa o tipo Date."""
    def __init__(self):
        super().__init__(TypeKind.DATE, "Date")


@dataclass
class TimeType(MedicalType):
    """Representa o tipo Time."""
    def __init__(self):
        super().__init__(TypeKind.TIME, "Time")


@dataclass
class DateTimeType(MedicalType):
    """Representa o tipo DateTime."""
    def __init__(self):
        super().__init__(TypeKind.DATETIME, "DateTime")


@dataclass
class DurationType(MedicalType):
    """Representa o tipo Duration."""
    def __init__(self):
        super().__init__(TypeKind.DURATION, "Duration")


@dataclass
class VitalSignsType(MedicalType):
    """Representa o tipo VitalSigns."""
    def __init__(self):
        super().__init__(TypeKind.VITAL_SIGNS, "VitalSigns")


@dataclass
class AnyType(Type):
    """Representa o tipo Any."""
    def __init__(self):
        super().__init__(TypeKind.ANY)
    
    def __eq__(self, other):
        # Any é compatível com qualquer tipo
        return True
    
    def __str__(self):
        return "Any"


@dataclass
class NoneType(Type):
    """Representa o tipo None."""
    def __init__(self):
        super().__init__(TypeKind.NONE)
    
    def __str__(self):
        return "None"


@dataclass
class ErrorType(Type):
    """Representa um tipo de erro."""
    message: str
    
    def __init__(self, message: str):
        super().__init__(TypeKind.ERROR)
        self.message = message
    
    def __str__(self):
        return f"Error: {self.message}"


class TypeChecker:
    """
    Verificador de tipos para a linguagem Charcot.
    
    Responsável por verificar e inferir tipos em programas Charcot.
    """
    
    def __init__(self):
        # Tipos primitivos predefinidos
        self.int_type = PrimitiveType("int")
        self.float_type = PrimitiveType("float")
        self.bool_type = PrimitiveType("bool")
        self.str_type = PrimitiveType("str")
        self.none_type = NoneType()
        
        # Tipos específicos para medicina
        self.patient_type = PatientType()
        self.medication_type = MedicationType()
        self.dose_type = DoseType()
        self.date_type = DateType()
        self.time_type = TimeType()
        self.datetime_type = DateTimeType()
        self.duration_type = DurationType()
        self.vital_signs_type = VitalSignsType()
        
        # Ambiente de tipos
        self.globals: Dict[str, Type] = {}
        self.locals: List[Dict[str, Type]] = [{}]
        
        # Tipos definidos pelo usuário
        self.user_types: Dict[str, Type] = {}
        
        # Erros de tipo
        self.errors: List[str] = []
        
        # Inicializar ambiente global com tipos primitivos
        self._init_globals()
    
    def _init_globals(self):
        """Inicializa o ambiente global com tipos primitivos."""
        self.globals["int"] = self.int_type
        self.globals["float"] = self.float_type
        self.globals["bool"] = self.bool_type
        self.globals["str"] = self.str_type
        self.globals["None"] = self.none_type
        
        # Tipos específicos para medicina
        self.globals["Patient"] = self.patient_type
        self.globals["Medication"] = self.medication_type
        self.globals["Dose"] = self.dose_type
        self.globals["Date"] = self.date_type
        self.globals["Time"] = self.time_type
        self.globals["DateTime"] = self.datetime_type
        self.globals["Duration"] = self.duration_type
        self.globals["VitalSigns"] = self.vital_signs_type
    
    def check(self, statements: List[Statement]) -> List[str]:
        """
        Verifica os tipos em uma lista de declarações.
        
        Args:
            statements (List[Statement]): A lista de declarações a ser verificada.
            
        Returns:
            List[str]: A lista de erros de tipo encontrados.
        """
        self.errors = []
        
        # Primeira passagem: coletar declarações de tipos
        for stmt in statements:
            if isinstance(stmt, Struct):
                self._declare_struct(stmt)
        
        # Segunda passagem: verificar tipos
        for stmt in statements:
            self._check_statement(stmt)
        
        return self.errors
    
    def _declare_struct(self, stmt: Struct):
        """
        Declara um tipo de estrutura.
        
        Args:
            stmt (Struct): A declaração de estrutura.
        """
        name = stmt.name.lexeme
        
        if name in self.user_types:
            self._error(stmt.name, f"Tipo '{name}' já declarado.")
            return
        
        # Criar tipo de estrutura vazio inicialmente
        struct_type = StructType(name, {}, {})
        self.user_types[name] = struct_type
        self.globals[name] = struct_type
        
        # Preencher campos
        fields = {}
        for i, field in enumerate(stmt.fields):
            field_name = field.lexeme
            field_type_expr = stmt.field_types[i]
            field_type = self._resolve_type_expression(field_type_expr)
            fields[field_name] = field_type
        
        # Preencher métodos
        methods = {}
        for method in stmt.methods:
            method_name = method.name.lexeme
            param_types = []
            for i, _ in enumerate(method.params):
                if method.param_types[i] is not None:
                    param_type = self._resolve_type_expression(method.param_types[i])
                else:
                    param_type = AnyType()
                param_types.append(param_type)
            
            return_type = self.none_type
            if method.return_type is not None:
                return_type = self._resolve_type_expression(method.return_type)
            
            methods[method_name] = FunctionType(param_types, return_type)
        
        # Atualizar tipo de estrutura
        struct_type.fields = fields
        struct_type.methods = methods
    
    def _check_statement(self, stmt: Statement):
        """
        Verifica os tipos em uma declaração.
        
        Args:
            stmt (Statement): A declaração a ser verificada.
        """
        if isinstance(stmt, ExpressionStmt):
            self._check_expression(stmt.expression)
        elif isinstance(stmt, Let):
            self._check_let(stmt)
        elif isinstance(stmt, Block):
            self._begin_scope()
            for s in stmt.statements:
                self._check_statement(s)
            self._end_scope()
        elif isinstance(stmt, If):
            self._check_if(stmt)
        elif isinstance(stmt, While):
            self._check_while(stmt)
        elif isinstance(stmt, For):
            self._check_for(stmt)
        elif isinstance(stmt, Function):
            self._check_function(stmt)
        elif isinstance(stmt, Return):
            self._check_return(stmt)
        elif isinstance(stmt, Struct):
            # Já processado na primeira passagem
            pass
        elif isinstance(stmt, Import):
            # Ignorar por enquanto
            pass
        elif isinstance(stmt, Procedure):
            self._check_procedure(stmt)
        elif isinstance(stmt, Match):
            self._check_match(stmt)
        else:
            self._error_node(stmt, f"Tipo de declaração não suportado: {type(stmt).__name__}")
    
    def _check_let(self, stmt: Let):
        """
        Verifica os tipos em uma declaração de variável.
        
        Args:
            stmt (Let): A declaração de variável a ser verificada.
        """
        var_type = None
        
        # Verificar tipo explícito
        if stmt.type_annotation is not None:
            var_type = self._resolve_type_expression(stmt.type_annotation)
        
        # Verificar inicializador
        if stmt.initializer is not None:
            init_type = self._check_expression(stmt.initializer)
            
            if var_type is None:
                # Inferir tipo a partir do inicializador
                var_type = init_type
            elif not self._is_assignable(init_type, var_type):
                self._error(stmt.name, f"Não é possível atribuir valor do tipo '{init_type}' a variável do tipo '{var_type}'.")
        
        if var_type is None:
            # Se não há tipo explícito nem inicializador, usar Any
            var_type = AnyType()
        
        # Definir variável no escopo atual
        self._define(stmt.name.lexeme, var_type)
    
    def _check_if(self, stmt: If):
        """
        Verifica os tipos em uma declaração if.
        
        Args:
            stmt (If): A declaração if a ser verificada.
        """
        condition_type = self._check_expression(stmt.condition)
        
        if condition_type != self.bool_type and not isinstance(condition_type, AnyType):
            self._error_node(stmt.condition, f"Condição deve ser do tipo 'bool', mas é '{condition_type}'.")
        
        self._check_statement(stmt.then_branch)
        
        if stmt.else_branch is not None:
            self._check_statement(stmt.else_branch)
    
    def _check_while(self, stmt: While):
        """
        Verifica os tipos em uma declaração while.
        
        Args:
            stmt (While): A declaração while a ser verificada.
        """
        condition_type = self._check_expression(stmt.condition)
        
        if condition_type != self.bool_type and not isinstance(condition_type, AnyType):
            self._error_node(stmt.condition, f"Condição deve ser do tipo 'bool', mas é '{condition_type}'.")
        
        self._check_statement(stmt.body)
    
    def _check_for(self, stmt: For):
        """
        Verifica os tipos em uma declaração for.
        
        Args:
            stmt (For): A declaração for a ser verificada.
        """
        iterable_type = self._check_expression(stmt.iterable)
        
        # Verificar se o tipo é iterável
        element_type = self._get_element_type(iterable_type)
        
        if element_type is None:
            self._error_node(stmt.iterable, f"Tipo '{iterable_type}' não é iterável.")
            element_type = AnyType()
        
        # Criar novo escopo para a variável de iteração
        self._begin_scope()
        self._define(stmt.variable.lexeme, element_type)
        
        self._check_statement(stmt.body)
        
        self._end_scope()
    
    def _check_function(self, stmt: Function):
        """
        Verifica os tipos em uma declaração de função.
        
        Args:
            stmt (Function): A declaração de função a ser verificada.
        """
        param_types = []
        
        # Verificar tipos dos parâmetros
        for i, param in enumerate(stmt.params):
            param_type = AnyType()
            if stmt.param_types[i] is not None:
                param_type = self._resolve_type_expression(stmt.param_types[i])
            param_types.append(param_type)
        
        # Verificar tipo de retorno
        return_type = self.none_type
        if stmt.return_type is not None:
            return_type = self._resolve_type_expression(stmt.return_type)
        
        # Criar tipo de função
        function_type = FunctionType(param_types, return_type)
        
        # Definir função no escopo atual
        self._define(stmt.name.lexeme, function_type)
        
        # Verificar corpo da função
        self._begin_scope()
        
        # Definir parâmetros no escopo da função
        for i, param in enumerate(stmt.params):
            self._define(param.lexeme, param_types[i])
        
        # Verificar declarações no corpo da função
        for s in stmt.body:
            self._check_statement(s)
        
        self._end_scope()
    
    def _check_return(self, stmt: Return):
        """
        Verifica os tipos em uma declaração return.
        
        Args:
            stmt (Return): A declaração return a ser verificada.
        """
        # TODO: Verificar se estamos dentro de uma função
        # TODO: Verificar se o tipo de retorno é compatível com o tipo de retorno da função
        
        if stmt.value is not None:
            self._check_expression(stmt.value)
    
    def _check_procedure(self, stmt: Procedure):
        """
        Verifica os tipos em uma declaração de procedimento médico.
        
        Args:
            stmt (Procedure): A declaração de procedimento a ser verificada.
        """
        # Procedimentos são similares a funções, mas com verificações adicionais
        param_types = []
        
        # Verificar tipos dos parâmetros
        for i, param in enumerate(stmt.params):
            param_type = AnyType()
            if stmt.param_types[i] is not None:
                param_type = self._resolve_type_expression(stmt.param_types[i])
            param_types.append(param_type)
        
        # Criar tipo de função para o procedimento
        function_type = FunctionType(param_types, self.none_type)
        
        # Definir procedimento no escopo atual
        self._define(stmt.name.lexeme, function_type)
        
        # Verificar corpo do procedimento
        self._begin_scope()
        
        # Definir parâmetros no escopo do procedimento
        for i, param in enumerate(stmt.params):
            self._define(param.lexeme, param_types[i])
        
        # Verificar verificações do procedimento
        for verification in stmt.verifications:
            verification_type = self._check_expression(verification)
            
            if verification_type != self.bool_type and not isinstance(verification_type, AnyType):
                self._error_node(verification, f"Verificação deve ser do tipo 'bool', mas é '{verification_type}'.")
        
        # Verificar declarações no corpo do procedimento
        for s in stmt.body:
            self._check_statement(s)
        
        self._end_scope()
    
    def _check_match(self, stmt: Match):
        """
        Verifica os tipos em uma declaração match.
        
        Args:
            stmt (Match): A declaração match a ser verificada.
        """
        value_type = self._check_expression(stmt.value)
        
        for pattern, body in stmt.cases:
            pattern_type = self._check_expression(pattern)
            
            # Verificar se o padrão é compatível com o valor
            if not self._is_assignable(value_type, pattern_type) and not self._is_assignable(pattern_type, value_type):
                self._error_node(pattern, f"Padrão do tipo '{pattern_type}' não é compatível com valor do tipo '{value_type}'.")
            
            self._check_statement(body)
    
    def _check_expression(self, expr: Expression) -> Type:
        """
        Verifica os tipos em uma expressão.
        
        Args:
            expr (Expression): A expressão a ser verificada.
            
        Returns:
            Type: O tipo da expressão.
        """
        if isinstance(expr, Binary):
            return self._check_binary(expr)
        elif isinstance(expr, Grouping):
            return self._check_expression(expr.expression)
        elif isinstance(expr, Literal):
            return self._get_literal_type(expr.value)
        elif isinstance(expr, Unary):
            return self._check_unary(expr)
        elif isinstance(expr, Variable):
            return self._check_variable(expr)
        elif isinstance(expr, Assign):
            return self._check_assign(expr)
        elif isinstance(expr, Call):
            return self._check_call(expr)
        elif isinstance(expr, Get):
            return self._check_get(expr)
        elif isinstance(expr, Set):
            return self._check_set(expr)
        elif isinstance(expr, Logical):
            return self._check_logical(expr)
        else:
            self._error_node(expr, f"Tipo de expressão não suportado: {type(expr).__name__}")
            return ErrorType(f"Tipo de expressão não suportado: {type(expr).__name__}")
    
    def _check_binary(self, expr: Binary) -> Type:
        """
        Verifica os tipos em uma expressão binária.
        
        Args:
            expr (Binary): A expressão binária a ser verificada.
            
        Returns:
            Type: O tipo da expressão binária.
        """
        left_type = self._check_expression(expr.left)
        right_type = self._check_expression(expr.right)
        
        op = expr.operator.type
        
        # Operadores aritméticos
        if op in [TokenType.PLUS, TokenType.MINUS, TokenType.STAR, TokenType.SLASH, TokenType.PERCENT, TokenType.POWER]:
            if left_type == self.int_type and right_type == self.int_type:
                return self.int_type
            elif (left_type in [self.int_type, self.float_type] and 
                  right_type in [self.int_type, self.float_type]):
                return self.float_type
            elif op == TokenType.PLUS and left_type == self.str_type and right_type == self.str_type:
                return self.str_type
            else:
                self._error(expr.operator, f"Operador '{expr.operator.lexeme}' não pode ser aplicado a '{left_type}' e '{right_type}'.")
                return ErrorType(f"Operador '{expr.operator.lexeme}' não pode ser aplicado a '{left_type}' e '{right_type}'.")
        
        # Operadores de comparação
        elif op in [TokenType.GREATER, TokenType.GREATER_EQUAL, TokenType.LESS, TokenType.LESS_EQUAL]:
            if (left_type in [self.int_type, self.float_type] and 
                right_type in [self.int_type, self.float_type]):
                return self.bool_type
            elif left_type == self.str_type and right_type == self.str_type:
                return self.bool_type
            else:
                self._error(expr.operator, f"Operador '{expr.operator.lexeme}' não pode ser aplicado a '{left_type}' e '{right_type}'.")
                return ErrorType(f"Operador '{expr.operator.lexeme}' não pode ser aplicado a '{left_type}' e '{right_type}'.")
        
        # Operadores de igualdade
        elif op in [TokenType.EQUAL_EQUAL, TokenType.BANG_EQUAL]:
            if self._is_assignable(left_type, right_type) or self._is_assignable(right_type, left_type):
                return self.bool_type
            else:
                self._error(expr.operator, f"Operador '{expr.operator.lexeme}' não pode ser aplicado a '{left_type}' e '{right_type}'.")
                return ErrorType(f"Operador '{expr.operator.lexeme}' não pode ser aplicado a '{left_type}' e '{right_type}'.")
        
        else:
            self._error(expr.operator, f"Operador binário não suportado: {expr.operator.lexeme}")
            return ErrorType(f"Operador binário não suportado: {expr.operator.lexeme}")
    
    def _check_unary(self, expr: Unary) -> Type:
        """
        Verifica os tipos em uma expressão unária.
        
        Args:
            expr (Unary): A expressão unária a ser verificada.
            
        Returns:
            Type: O tipo da expressão unária.
        """
        right_type = self._check_expression(expr.right)
        
        op = expr.operator.type
        
        if op == TokenType.MINUS:
            if right_type in [self.int_type, self.float_type]:
                return right_type
            else:
                self._error(expr.operator, f"Operador '-' não pode ser aplicado a '{right_type}'.")
                return ErrorType(f"Operador '-' não pode ser aplicado a '{right_type}'.")
        
        elif op == TokenType.BANG:
            if right_type == self.bool_type:
                return self.bool_type
            else:
                self._error(expr.operator, f"Operador '!' não pode ser aplicado a '{right_type}'.")
                return ErrorType(f"Operador '!' não pode ser aplicado a '{right_type}'.")
        
        else:
            self._error(expr.operator, f"Operador unário não suportado: {expr.operator.lexeme}")
            return ErrorType(f"Operador unário não suportado: {expr.operator.lexeme}")
    
    def _check_variable(self, expr: Variable) -> Type:
        """
        Verifica os tipos em uma expressão de variável.
        
        Args:
            expr (Variable): A expressão de variável a ser verificada.
            
        Returns:
            Type: O tipo da variável.
        """
        name = expr.name.lexeme
        var_type = self._lookup(name)
        
        if var_type is None:
            self._error(expr.name, f"Variável '{name}' não definida.")
            return ErrorType(f"Variável '{name}' não definida.")
        
        return var_type
    
    def _check_assign(self, expr: Assign) -> Type:
        """
        Verifica os tipos em uma expressão de atribuição.
        
        Args:
            expr (Assign): A expressão de atribuição a ser verificada.
            
        Returns:
            Type: O tipo do valor atribuído.
        """
        value_type = self._check_expression(expr.value)
        name = expr.name.lexeme
        var_type = self._lookup(name)
        
        if var_type is None:
            self._error(expr.name, f"Variável '{name}' não definida.")
            return ErrorType(f"Variável '{name}' não definida.")
        
        if not self._is_assignable(value_type, var_type):
            self._error(expr.name, f"Não é possível atribuir valor do tipo '{value_type}' a variável do tipo '{var_type}'.")
        
        return value_type
    
    def _check_call(self, expr: Call) -> Type:
        """
        Verifica os tipos em uma expressão de chamada.
        
        Args:
            expr (Call): A expressão de chamada a ser verificada.
            
        Returns:
            Type: O tipo de retorno da função chamada.
        """
        callee_type = self._check_expression(expr.callee)
        
        if not isinstance(callee_type, FunctionType):
            self._error_node(expr.callee, f"Não é possível chamar valor do tipo '{callee_type}'.")
            return ErrorType(f"Não é possível chamar valor do tipo '{callee_type}'.")
        
        if len(expr.arguments) != len(callee_type.param_types):
            self._error(expr.paren, f"Esperado {len(callee_type.param_types)} argumentos, mas recebeu {len(expr.arguments)}.")
            return callee_type.return_type
        
        for i, arg in enumerate(expr.arguments):
            arg_type = self._check_expression(arg)
            param_type = callee_type.param_types[i]
            
            if not self._is_assignable(arg_type, param_type):
                self._error_node(arg, f"Argumento do tipo '{arg_type}' não é compatível com parâmetro do tipo '{param_type}'.")
        
        return callee_type.return_type
    
    def _check_get(self, expr: Get) -> Type:
        """
        Verifica os tipos em uma expressão de acesso a propriedade.
        
        Args:
            expr (Get): A expressão de acesso a propriedade a ser verificada.
            
        Returns:
            Type: O tipo da propriedade acessada.
        """
        object_type = self._check_expression(expr.object)
        
        if isinstance(object_type, StructType):
            name = expr.name.lexeme
            
            if name in object_type.fields:
                return object_type.fields[name]
            elif name in object_type.methods:
                return object_type.methods[name]
            else:
                self._error(expr.name, f"Propriedade '{name}' não existe no tipo '{object_type.name}'.")
                return ErrorType(f"Propriedade '{name}' não existe no tipo '{object_type.name}'.")
        else:
            self._error_node(expr.object, f"Não é possível acessar propriedades de valor do tipo '{object_type}'.")
            return ErrorType(f"Não é possível acessar propriedades de valor do tipo '{object_type}'.")
    
    def _check_set(self, expr: Set) -> Type:
        """
        Verifica os tipos em uma expressão de definição de propriedade.
        
        Args:
            expr (Set): A expressão de definição de propriedade a ser verificada.
            
        Returns:
            Type: O tipo do valor atribuído.
        """
        object_type = self._check_expression(expr.object)
        value_type = self._check_expression(expr.value)
        
        if isinstance(object_type, StructType):
            name = expr.name.lexeme
            
            if name in object_type.fields:
                field_type = object_type.fields[name]
                
                if not self._is_assignable(value_type, field_type):
                    self._error(expr.name, f"Não é possível atribuir valor do tipo '{value_type}' a campo do tipo '{field_type}'.")
                
                return value_type
            else:
                self._error(expr.name, f"Propriedade '{name}' não existe no tipo '{object_type.name}'.")
                return ErrorType(f"Propriedade '{name}' não existe no tipo '{object_type.name}'.")
        else:
            self._error_node(expr.object, f"Não é possível definir propriedades de valor do tipo '{object_type}'.")
            return ErrorType(f"Não é possível definir propriedades de valor do tipo '{object_type}'.")
    
    def _check_logical(self, expr: Logical) -> Type:
        """
        Verifica os tipos em uma expressão lógica.
        
        Args:
            expr (Logical): A expressão lógica a ser verificada.
            
        Returns:
            Type: O tipo da expressão lógica.
        """
        left_type = self._check_expression(expr.left)
        right_type = self._check_expression(expr.right)
        
        if left_type != self.bool_type and not isinstance(left_type, AnyType):
            self._error_node(expr.left, f"Operando esquerdo deve ser do tipo 'bool', mas é '{left_type}'.")
        
        if right_type != self.bool_type and not isinstance(right_type, AnyType):
            self._error_node(expr.right, f"Operando direito deve ser do tipo 'bool', mas é '{right_type}'.")
        
        return self.bool_type
    
    def _get_literal_type(self, value: Any) -> Type:
        """
        Obtém o tipo de um valor literal.
        
        Args:
            value (Any): O valor literal.
            
        Returns:
            Type: O tipo do valor literal.
        """
        if value is None:
            return self.none_type
        elif isinstance(value, bool):
            return self.bool_type
        elif isinstance(value, int):
            return self.int_type
        elif isinstance(value, float):
            return self.float_type
        elif isinstance(value, str):
            return self.str_type
        else:
            return ErrorType(f"Tipo literal não suportado: {type(value).__name__}")
    
    def _resolve_type_expression(self, expr: Expression) -> Type:
        """
        Resolve uma expressão de tipo para um tipo concreto.
        
        Args:
            expr (Expression): A expressão de tipo a ser resolvida.
            
        Returns:
            Type: O tipo concreto.
        """
        if isinstance(expr, Variable):
            name = expr.name.lexeme
            
            if name in self.globals:
                return self.globals[name]
            else:
                self._error(expr.name, f"Tipo '{name}' não definido.")
                return ErrorType(f"Tipo '{name}' não definido.")
        
        elif isinstance(expr, Call):
            # Tipo genérico
            if isinstance(expr.callee, Variable):
                base_name = expr.callee.name.lexeme
                
                if base_name in self.globals:
                    base_type = self.globals[base_name]
                    
                    type_args = []
                    for arg in expr.arguments:
                        type_args.append(self._resolve_type_expression(arg))
                    
                    if base_name == "list" and len(type_args) == 1:
                        return ListType(type_args[0])
                    elif base_name == "dict" and len(type_args) == 2:
                        return DictType(type_args[0], type_args[1])
                    elif base_name == "set" and len(type_args) == 1:
                        return SetType(type_args[0])
                    elif base_name == "tuple":
                        return TupleType(type_args)
                    elif base_name == "Option" and len(type_args) == 1:
                        return OptionType(type_args[0])
                    elif base_name == "Result" and len(type_args) == 2:
                        return ResultType(type_args[0], type_args[1])
                    else:
                        self._error(expr.callee.name, f"Tipo genérico '{base_name}' não suportado ou número incorreto de argumentos de tipo.")
                        return ErrorType(f"Tipo genérico '{base_name}' não suportado ou número incorreto de argumentos de tipo.")
                else:
                    self._error(expr.callee.name, f"Tipo '{base_name}' não definido.")
                    return ErrorType(f"Tipo '{base_name}' não definido.")
            else:
                self._error_node(expr.callee, "Expressão de tipo inválida.")
                return ErrorType("Expressão de tipo inválida.")
        
        else:
            self._error_node(expr, "Expressão de tipo inválida.")
            return ErrorType("Expressão de tipo inválida.")
    
    def _is_assignable(self, from_type: Type, to_type: Type) -> bool:
        """
        Verifica se um tipo pode ser atribuído a outro.
        
        Args:
            from_type (Type): O tipo de origem.
            to_type (Type): O tipo de destino.
            
        Returns:
            bool: True se o tipo de origem pode ser atribuído ao tipo de destino, False caso contrário.
        """
        # Qualquer tipo pode ser atribuído a Any
        if isinstance(to_type, AnyType):
            return True
        
        # Any pode ser atribuído a qualquer tipo
        if isinstance(from_type, AnyType):
            return True
        
        # Tipos iguais são atribuíveis
        if from_type == to_type:
            return True
        
        # int pode ser atribuído a float
        if from_type == self.int_type and to_type == self.float_type:
            return True
        
        # None pode ser atribuído a Option<T>
        if from_type == self.none_type and isinstance(to_type, OptionType):
            return True
        
        # TODO: Verificar outros casos de atribuição (subtipos, etc.)
        
        return False
    
    def _get_element_type(self, collection_type: Type) -> Optional[Type]:
        """
        Obtém o tipo de elemento de um tipo de coleção.
        
        Args:
            collection_type (Type): O tipo de coleção.
            
        Returns:
            Optional[Type]: O tipo de elemento, ou None se o tipo não for uma coleção.
        """
        if isinstance(collection_type, ListType):
            return collection_type.type_args[0]
        elif isinstance(collection_type, SetType):
            return collection_type.type_args[0]
        elif isinstance(collection_type, DictType):
            # Para dicionários, retornamos o tipo do valor
            return collection_type.type_args[1]
        elif isinstance(collection_type, TupleType):
            # Para tuplas, retornamos o tipo do primeiro elemento
            if collection_type.element_types:
                return collection_type.element_types[0]
            else:
                return None
        elif isinstance(collection_type, AnyType):
            # Para Any, retornamos Any
            return AnyType()
        else:
            return None
    
    def _begin_scope(self):
        """Inicia um novo escopo."""
        self.locals.append({})
    
    def _end_scope(self):
        """Finaliza o escopo atual."""
        self.locals.pop()
    
    def _define(self, name: str, type: Type):
        """
        Define uma variável no escopo atual.
        
        Args:
            name (str): O nome da variável.
            type (Type): O tipo da variável.
        """
        self.locals[-1][name] = type
    
    def _lookup(self, name: str) -> Optional[Type]:
        """
        Procura uma variável nos escopos.
        
        Args:
            name (str): O nome da variável.
            
        Returns:
            Optional[Type]: O tipo da variável, ou None se não for encontrada.
        """
        # Procurar nos escopos locais, do mais interno para o mais externo
        for i in range(len(self.locals) - 1, -1, -1):
            if name in self.locals[i]:
                return self.locals[i][name]
        
        # Procurar no escopo global
        if name in self.globals:
            return self.globals[name]
        
        return None
    
    def _error(self, token: Token, message: str):
        """
        Reporta um erro de tipo.
        
        Args:
            token (Token): O token onde ocorreu o erro.
            message (str): A mensagem de erro.
        """
        error_msg = f"[linha {token.line}, coluna {token.column}] Erro de tipo"
        
        if token.type == TokenType.EOF:
            error_msg += " no final do arquivo"
        else:
            error_msg += f" em '{token.lexeme}'"
        
        error_msg += f": {message}"
        self.errors.append(error_msg)
    
    def _error_node(self, node: Node, message: str):
        """
        Reporta um erro de tipo em um nó da AST.
        
        Args:
            node (Node): O nó onde ocorreu o erro.
            message (str): A mensagem de erro.
        """
        error_msg = f"Erro de tipo: {message}"
        self.errors.append(error_msg)


def check_types(statements: List[Statement]) -> List[str]:
    """
    Função auxiliar para verificar tipos em uma lista de declarações.
    
    Args:
        statements (List[Statement]): A lista de declarações a ser verificada.
        
    Returns:
        List[str]: A lista de erros de tipo encontrados.
    """
    type_checker = TypeChecker()
    return type_checker.check(statements)


if __name__ == "__main__":
    from lexer import tokenize
    from parser import parse
    
    # Exemplo de uso
    code = """
# Este é um exemplo de código Charcot

fn calcular_dose(peso: float, medicamento: Medication) -> Dose:
    if peso < 10:
        return Dose(peso * 0.1, "mg")
    else:
        return Dose(peso * 0.2, "mg")

paciente = Patient {
    id: "P12345",
    nome: "João Silva",
    peso: 70.5
}

dose = calcular_dose(paciente.peso, medicamentos.paracetamol)
print(f"Dose recomendada: {dose}")
"""
    
    tokens = tokenize(code)
    statements, parse_errors = parse(tokens)
    
    if parse_errors:
        print("Erros de análise sintática:")
        for error in parse_errors:
            print(error)
    else:
        type_errors = check_types(statements)
        
        if type_errors:
            print("Erros de tipo:")
            for error in type_errors:
                print(error)
        else:
            print("Verificação de tipos concluída com sucesso.")
