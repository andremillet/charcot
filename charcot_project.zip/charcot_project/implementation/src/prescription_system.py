#!/usr/bin/env python3
"""
Módulo de Sistema de Prescrição Médica para a Linguagem Charcot

Este módulo implementa um sistema de prescrição médica para a linguagem Charcot,
permitindo a criação, validação e gerenciamento de prescrições médicas com verificações
de segurança automáticas.
"""

from typing import Dict, List, Any, Optional, Union, Callable, Set, Tuple
from dataclasses import dataclass, field
import datetime
import uuid
import json
import re

from implementation.src.fhir_integration import FHIRClient, FHIRMedicationRequest, FHIRReference, FHIRQuantity


@dataclass
class Medication:
    """Representa um medicamento no sistema de prescrição."""
    id: str
    name: str
    active_ingredient: str
    strength: str  # Ex: "500 mg", "10 mg/ml"
    form: str  # Ex: "tablet", "solution", "capsule"
    route: str  # Ex: "oral", "intravenous", "topical"
    atc_code: Optional[str] = None  # Código ATC (Anatomical Therapeutic Chemical)
    contraindications: List[str] = field(default_factory=list)
    interactions: Dict[str, str] = field(default_factory=dict)  # Medicamento -> descrição da interação
    max_daily_dose: Optional[str] = None
    requires_prescription: bool = True
    controlled_substance: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte o medicamento para um dicionário."""
        return {
            "id": self.id,
            "name": self.name,
            "active_ingredient": self.active_ingredient,
            "strength": self.strength,
            "form": self.form,
            "route": self.route,
            "atc_code": self.atc_code,
            "contraindications": self.contraindications,
            "interactions": self.interactions,
            "max_daily_dose": self.max_daily_dose,
            "requires_prescription": self.requires_prescription,
            "controlled_substance": self.controlled_substance
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Medication':
        """Cria um medicamento a partir de um dicionário."""
        return cls(
            id=data["id"],
            name=data["name"],
            active_ingredient=data["active_ingredient"],
            strength=data["strength"],
            form=data["form"],
            route=data["route"],
            atc_code=data.get("atc_code"),
            contraindications=data.get("contraindications", []),
            interactions=data.get("interactions", {}),
            max_daily_dose=data.get("max_daily_dose"),
            requires_prescription=data.get("requires_prescription", True),
            controlled_substance=data.get("controlled_substance", False)
        )


@dataclass
class Dose:
    """Representa uma dose de medicamento."""
    value: float
    unit: str  # Ex: "mg", "ml", "tablet"
    
    def __str__(self) -> str:
        """Retorna a representação em string da dose."""
        return f"{self.value} {self.unit}"
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte a dose para um dicionário."""
        return {
            "value": self.value,
            "unit": self.unit
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Dose':
        """Cria uma dose a partir de um dicionário."""
        return cls(
            value=data["value"],
            unit=data["unit"]
        )
    
    @classmethod
    def from_string(cls, dose_str: str) -> 'Dose':
        """Cria uma dose a partir de uma string."""
        match = re.match(r"(\d+(?:\.\d+)?)\s*(\w+)", dose_str.strip())
        if not match:
            raise ValueError(f"Formato de dose inválido: {dose_str}")
        
        value = float(match.group(1))
        unit = match.group(2)
        
        return cls(value=value, unit=unit)


@dataclass
class DosageSchedule:
    """Representa um esquema de dosagem."""
    dose: Dose
    frequency: str  # Ex: "once daily", "twice daily", "every 8 hours"
    duration: Optional[int] = None  # Duração em dias
    as_needed: bool = False
    timing_description: Optional[str] = None  # Ex: "before meals", "at bedtime"
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte o esquema de dosagem para um dicionário."""
        return {
            "dose": self.dose.to_dict(),
            "frequency": self.frequency,
            "duration": self.duration,
            "as_needed": self.as_needed,
            "timing_description": self.timing_description
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DosageSchedule':
        """Cria um esquema de dosagem a partir de um dicionário."""
        return cls(
            dose=Dose.from_dict(data["dose"]),
            frequency=data["frequency"],
            duration=data.get("duration"),
            as_needed=data.get("as_needed", False),
            timing_description=data.get("timing_description")
        )


@dataclass
class Prescription:
    """Representa uma prescrição médica."""
    id: str
    patient_id: str
    prescriber_id: str
    medication_id: str
    dosage_schedule: DosageSchedule
    instructions: str
    date_written: str
    start_date: str
    end_date: Optional[str] = None
    status: str = "active"  # active, completed, cancelled, suspended
    refills: int = 0
    dispense_amount: Optional[int] = None
    pharmacy_notes: Optional[str] = None
    verification_status: str = "unverified"  # unverified, verified, rejected
    verification_notes: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte a prescrição para um dicionário."""
        return {
            "id": self.id,
            "patient_id": self.patient_id,
            "prescriber_id": self.prescriber_id,
            "medication_id": self.medication_id,
            "dosage_schedule": self.dosage_schedule.to_dict(),
            "instructions": self.instructions,
            "date_written": self.date_written,
            "start_date": self.start_date,
            "end_date": self.end_date,
            "status": self.status,
            "refills": self.refills,
            "dispense_amount": self.dispense_amount,
            "pharmacy_notes": self.pharmacy_notes,
            "verification_status": self.verification_status,
            "verification_notes": self.verification_notes
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Prescription':
        """Cria uma prescrição a partir de um dicionário."""
        return cls(
            id=data["id"],
            patient_id=data["patient_id"],
            prescriber_id=data["prescriber_id"],
            medication_id=data["medication_id"],
            dosage_schedule=DosageSchedule.from_dict(data["dosage_schedule"]),
            instructions=data["instructions"],
            date_written=data["date_written"],
            start_date=data["start_date"],
            end_date=data.get("end_date"),
            status=data.get("status", "active"),
            refills=data.get("refills", 0),
            dispense_amount=data.get("dispense_amount"),
            pharmacy_notes=data.get("pharmacy_notes"),
            verification_status=data.get("verification_status", "unverified"),
            verification_notes=data.get("verification_notes")
        )


@dataclass
class Patient:
    """Representa um paciente no sistema de prescrição."""
    id: str
    name: str
    birth_date: str
    gender: str
    weight: Optional[float] = None  # em kg
    height: Optional[float] = None  # em cm
    allergies: List[str] = field(default_factory=list)
    conditions: List[str] = field(default_factory=list)
    active_medications: List[str] = field(default_factory=list)  # IDs de prescrições ativas
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte o paciente para um dicionário."""
        return {
            "id": self.id,
            "name": self.name,
            "birth_date": self.birth_date,
            "gender": self.gender,
            "weight": self.weight,
            "height": self.height,
            "allergies": self.allergies,
            "conditions": self.conditions,
            "active_medications": self.active_medications
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Patient':
        """Cria um paciente a partir de um dicionário."""
        return cls(
            id=data["id"],
            name=data["name"],
            birth_date=data["birth_date"],
            gender=data["gender"],
            weight=data.get("weight"),
            height=data.get("height"),
            allergies=data.get("allergies", []),
            conditions=data.get("conditions", []),
            active_medications=data.get("active_medications", [])
        )
    
    def calculate_bmi(self) -> Optional[float]:
        """Calcula o IMC (Índice de Massa Corporal) do paciente."""
        if self.weight is None or self.height is None:
            return None
        
        # IMC = peso (kg) / (altura (m))²
        height_m = self.height / 100  # Converter cm para m
        bmi = self.weight / (height_m * height_m)
        return round(bmi, 1)
    
    def calculate_age(self) -> int:
        """Calcula a idade do paciente."""
        birth_date = datetime.datetime.fromisoformat(self.birth_date.replace('Z', '+00:00'))
        today = datetime.datetime.now()
        age = today.year - birth_date.year
        
        # Ajustar se o aniversário deste ano ainda não ocorreu
        if (today.month, today.day) < (birth_date.month, birth_date.day):
            age -= 1
        
        return age


@dataclass
class Prescriber:
    """Representa um prescritor (médico, enfermeiro) no sistema."""
    id: str
    name: str
    license_number: str
    specialty: Optional[str] = None
    prescribing_rights: List[str] = field(default_factory=list)  # Tipos de medicamentos que pode prescrever
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte o prescritor para um dicionário."""
        return {
            "id": self.id,
            "name": self.name,
            "license_number": self.license_number,
            "specialty": self.specialty,
            "prescribing_rights": self.prescribing_rights
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Prescriber':
        """Cria um prescritor a partir de um dicionário."""
        return cls(
            id=data["id"],
            name=data["name"],
            license_number=data["license_number"],
            specialty=data.get("specialty"),
            prescribing_rights=data.get("prescribing_rights", [])
        )


class VerificationError(Exception):
    """Exceção lançada quando uma verificação de prescrição falha."""
    pass


class PrescriptionSystem:
    """Sistema de prescrição médica."""
    
    def __init__(self, fhir_client: Optional[FHIRClient] = None):
        """
        Inicializa o sistema de prescrição.
        
        Args:
            fhir_client (Optional[FHIRClient]): Cliente FHIR para integração com sistemas externos.
        """
        self.medications: Dict[str, Medication] = {}
        self.patients: Dict[str, Patient] = {}
        self.prescribers: Dict[str, Prescriber] = {}
        self.prescriptions: Dict[str, Prescription] = {}
        self.fhir_client = fhir_client
        
        # Registrar verificações de segurança
        self.safety_checks: List[Callable[[Prescription, Patient, Medication, Prescriber], Optional[str]]] = [
            self._check_allergies,
            self._check_interactions,
            self._check_contraindications,
            self._check_dose,
            self._check_prescribing_rights,
            self._check_controlled_substance
        ]
    
    def add_medication(self, medication: Medication) -> None:
        """
        Adiciona um medicamento ao sistema.
        
        Args:
            medication (Medication): O medicamento a ser adicionado.
        """
        self.medications[medication.id] = medication
    
    def add_patient(self, patient: Patient) -> None:
        """
        Adiciona um paciente ao sistema.
        
        Args:
            patient (Patient): O paciente a ser adicionado.
        """
        self.patients[patient.id] = patient
    
    def add_prescriber(self, prescriber: Prescriber) -> None:
        """
        Adiciona um prescritor ao sistema.
        
        Args:
            prescriber (Prescriber): O prescritor a ser adicionado.
        """
        self.prescribers[prescriber.id] = prescriber
    
    def create_prescription(self, patient_id: str, prescriber_id: str, medication_id: str,
                           dosage_schedule: DosageSchedule, instructions: str,
                           start_date: Optional[str] = None, duration: Optional[int] = None,
                           refills: int = 0, dispense_amount: Optional[int] = None,
                           pharmacy_notes: Optional[str] = None) -> str:
        """
        Cria uma nova prescrição.
        
        Args:
            patient_id (str): ID do paciente.
            prescriber_id (str): ID do prescritor.
            medication_id (str): ID do medicamento.
            dosage_schedule (DosageSchedule): Esquema de dosagem.
            instructions (str): Instruções para o paciente.
            start_date (Optional[str]): Data de início (formato ISO). Se None, usa a data atual.
            duration (Optional[int]): Duração em dias. Se fornecido, calcula a data de término.
            refills (int): Número de recargas permitidas.
            dispense_amount (Optional[int]): Quantidade a ser dispensada.
            pharmacy_notes (Optional[str]): Notas para a farmácia.
            
        Returns:
            str: ID da prescrição criada.
            
        Raises:
            ValueError: Se o paciente, prescritor ou medicamento não existirem.
            VerificationError: Se a prescrição falhar nas verificações de segurança.
        """
        # Verificar se o paciente, prescritor e medicamento existem
        if patient_id not in self.patients:
            raise ValueError(f"Paciente com ID {patient_id} não encontrado.")
        
        if prescriber_id not in self.prescribers:
            raise ValueError(f"Prescritor com ID {prescriber_id} não encontrado.")
        
        if medication_id not in self.medications:
            raise ValueError(f"Medicamento com ID {medication_id} não encontrado.")
        
        # Obter objetos
        patient = self.patients[patient_id]
        prescriber = self.prescribers[prescriber_id]
        medication = self.medications[medication_id]
        
        # Definir datas
        date_written = datetime.datetime.now().isoformat()
        
        if start_date is None:
            start_date = date_written
        
        end_date = None
        if duration is not None:
            start_datetime = datetime.datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            end_datetime = start_datetime + datetime.timedelta(days=duration)
            end_date = end_datetime.isoformat()
        
        # Criar prescrição
        prescription_id = str(uuid.uuid4())
        
        prescription = Prescription(
            id=prescription_id,
            patient_id=patient_id,
            prescriber_id=prescriber_id,
            medication_id=medication_id,
            dosage_schedule=dosage_schedule,
            instructions=instructions,
            date_written=date_written,
            start_date=start_date,
            end_date=end_date,
            status="active",
            refills=refills,
            dispense_amount=dispense_amount,
            pharmacy_notes=pharmacy_notes,
            verification_status="unverified"
        )
        
        # Verificar segurança da prescrição
        verification_result = self.verify_prescription(prescription)
        
        if verification_result["status"] == "rejected":
            raise VerificationError(verification_result["notes"])
        
        # Atualizar prescrição com resultado da verificação
        prescription.verification_status = verification_result["status"]
        prescription.verification_notes = verification_result["notes"]
        
        # Adicionar prescrição ao sistema
        self.prescriptions[prescription_id] = prescription
        
        # Atualizar lista de medicamentos ativos do paciente
        patient.active_medications.append(prescription_id)
        
        # Integração FHIR, se disponível
        if self.fhir_client:
            try:
                # Criar MedicationRequest FHIR
                medication_request = FHIRMedicationRequest()
                medication_request.status = "active"
                medication_request.intent = "order"
                medication_request.set_medication(f"Medication/{medication_id}", medication.name)
                medication_request.set_subject(f"Patient/{patient_id}", patient.name)
                medication_request.set_requester(f"Practitioner/{prescriber_id}", prescriber.name)
                medication_request.authoredOn = date_written
                
                # Adicionar instruções de dosagem
                dose_quantity = None
                if dosage_schedule.dose.unit in ["mg", "ml", "g", "mcg"]:
                    dose_quantity = FHIRQuantity(
                        value=dosage_schedule.dose.value,
                        unit=dosage_schedule.dose.unit
                    ).to_dict()
                
                timing_text = dosage_schedule.frequency
                if dosage_schedule.timing_description:
                    timing_text += f" {dosage_schedule.timing_description}"
                
                medication_request.add_dosage_instruction(
                    text=f"{instructions}. {timing_text}",
                    dose_quantity=dose_quantity
                )
                
                # Enviar para o servidor FHIR
                result = self.fhir_client.create_resource(medication_request)
                
                # Atualizar ID da prescrição com o ID FHIR, se necessário
                if "id" in result:
                    # Manter o ID original para referência interna
                    pass
            
            except Exception as e:
                print(f"Erro ao criar MedicationRequest FHIR: {e}")
        
        return prescription_id
    
    def verify_prescription(self, prescription: Prescription) -> Dict[str, str]:
        """
        Verifica a segurança de uma prescrição.
        
        Args:
            prescription (Prescription): A prescrição a ser verificada.
            
        Returns:
            Dict[str, str]: Resultado da verificação com status e notas.
        """
        # Obter objetos relacionados
        patient = self.patients.get(prescription.patient_id)
        medication = self.medications.get(prescription.medication_id)
        prescriber = self.prescribers.get(prescription.prescriber_id)
        
        if not patient or not medication or not prescriber:
            return {
                "status": "rejected",
                "notes": "Paciente, medicamento ou prescritor não encontrado."
            }
        
        # Executar verificações de segurança
        issues = []
        
        for check in self.safety_checks:
            result = check(prescription, patient, medication, prescriber)
            if result:
                issues.append(result)
        
        # Determinar status com base nas verificações
        if issues:
            return {
                "status": "rejected",
                "notes": "Problemas encontrados: " + "; ".join(issues)
            }
        
        return {
            "status": "verified",
            "notes": "Prescrição verificada e aprovada."
        }
    
    def _check_allergies(self, prescription: Prescription, patient: Patient, 
                        medication: Medication, prescriber: Prescriber) -> Optional[str]:
        """Verifica se o paciente tem alergia ao medicamento."""
        if medication.active_ingredient in patient.allergies:
            return f"Paciente tem alergia a {medication.active_ingredient}"
        return None
    
    def _check_interactions(self, prescription: Prescription, patient: Patient, 
                           medication: Medication, prescriber: Prescriber) -> Optional[str]:
        """Verifica interações com outros medicamentos ativos."""
        interactions = []
        
        for rx_id in patient.active_medications:
            if rx_id in self.prescriptions and rx_id != prescription.id:
                active_rx = self.prescriptions[rx_id]
                active_med_id = active_rx.medication_id
                
                if active_med_id in self.medications:
                    active_med = self.medications[active_med_id]
                    
                    # Verificar interação em ambas as direções
                    if active_med.name in medication.interactions:
                        interactions.append(f"{medication.name} interage com {active_med.name}: {medication.interactions[active_med.name]}")
                    
                    if medication.name in active_med.interactions:
                        interactions.append(f"{active_med.name} interage com {medication.name}: {active_med.interactions[medication.name]}")
        
        if interactions:
            return "; ".join(interactions)
        
        return None
    
    def _check_contraindications(self, prescription: Prescription, patient: Patient, 
                                medication: Medication, prescriber: Prescriber) -> Optional[str]:
        """Verifica contraindicações com base nas condições do paciente."""
        contraindications = []
        
        for condition in patient.conditions:
            if condition in medication.contraindications:
                contraindications.append(f"{medication.name} é contraindicado para pacientes com {condition}")
        
        if contraindications:
            return "; ".join(contraindications)
        
        return None
    
    def _check_dose(self, prescription: Prescription, patient: Patient, 
                   medication: Medication, prescriber: Prescriber) -> Optional[str]:
        """Verifica se a dose está dentro dos limites seguros."""
        if not medication.max_daily_dose:
            return None
        
        # Extrair valor e unidade da dose máxima diária
        max_dose_match = re.match(r"(\d+(?:\.\d+)?)\s*(\w+)", medication.max_daily_dose)
        if not max_dose_match:
            return None
        
        max_value = float(max_dose_match.group(1))
        max_unit = max_dose_match.group(2)
        
        # Verificar se as unidades são compatíveis
        if max_unit != prescription.dosage_schedule.dose.unit:
            return f"Unidades incompatíveis: prescrição em {prescription.dosage_schedule.dose.unit}, máximo em {max_unit}"
        
        # Calcular dose diária com base na frequência
        daily_frequency = 1
        frequency = prescription.dosage_schedule.frequency.lower()
        
        if "once daily" in frequency or "daily" in frequency:
            daily_frequency = 1
        elif "twice daily" in frequency or "two times a day" in frequency:
            daily_frequency = 2
        elif "three times a day" in frequency or "every 8 hours" in frequency:
            daily_frequency = 3
        elif "four times a day" in frequency or "every 6 hours" in frequency:
            daily_frequency = 4
        elif "every 4 hours" in frequency:
            daily_frequency = 6
        elif "every 12 hours" in frequency:
            daily_frequency = 2
        
        daily_dose = prescription.dosage_schedule.dose.value * daily_frequency
        
        if daily_dose > max_value:
            return f"Dose diária ({daily_dose} {max_unit}) excede o máximo recomendado ({max_value} {max_unit})"
        
        return None
    
    def _check_prescribing_rights(self, prescription: Prescription, patient: Patient, 
                                 medication: Medication, prescriber: Prescriber) -> Optional[str]:
        """Verifica se o prescritor tem direito de prescrever este tipo de medicamento."""
        if medication.controlled_substance and "controlled_substances" not in prescriber.prescribing_rights:
            return f"{prescriber.name} não tem autorização para prescrever substâncias controladas"
        
        return None
    
    def _check_controlled_substance(self, prescription: Prescription, patient: Patient, 
                                   medication: Medication, prescriber: Prescriber) -> Optional[str]:
        """Verifica regras especiais para substâncias controladas."""
        if medication.controlled_substance:
            # Verificar se a duração é muito longa
            if prescription.end_date:
                start_date = datetime.datetime.fromisoformat(prescription.start_date.replace('Z', '+00:00'))
                end_date = datetime.datetime.fromisoformat(prescription.end_date.replace('Z', '+00:00'))
                duration_days = (end_date - start_date).days
                
                if duration_days > 30:
                    return f"Prescrição de substância controlada não pode exceder 30 dias (atual: {duration_days} dias)"
            
            # Verificar número de recargas
            if prescription.refills > 0:
                return "Substâncias controladas não podem ter recargas"
        
        return None
    
    def get_prescription(self, prescription_id: str) -> Optional[Prescription]:
        """
        Obtém uma prescrição pelo ID.
        
        Args:
            prescription_id (str): ID da prescrição.
            
        Returns:
            Optional[Prescription]: A prescrição, se encontrada.
        """
        return self.prescriptions.get(prescription_id)
    
    def get_patient_prescriptions(self, patient_id: str, active_only: bool = False) -> List[Prescription]:
        """
        Obtém as prescrições de um paciente.
        
        Args:
            patient_id (str): ID do paciente.
            active_only (bool): Se True, retorna apenas prescrições ativas.
            
        Returns:
            List[Prescription]: Lista de prescrições do paciente.
        """
        if patient_id not in self.patients:
            return []
        
        if active_only:
            return [self.prescriptions[rx_id] for rx_id in self.patients[patient_id].active_medications 
                   if rx_id in self.prescriptions]
        
        return [rx for rx in self.prescriptions.values() if rx.patient_id == patient_id]
    
    def cancel_prescription(self, prescription_id: str, reason: str) -> bool:
        """
        Cancela uma prescrição.
        
        Args:
            prescription_id (str): ID da prescrição.
            reason (str): Motivo do cancelamento.
            
        Returns:
            bool: True se o cancelamento foi bem-sucedido, False caso contrário.
            
        Raises:
            ValueError: Se a prescrição não existir.
        """
        if prescription_id not in self.prescriptions:
            raise ValueError(f"Prescrição com ID {prescription_id} não encontrada.")
        
        prescription = self.prescriptions[prescription_id]
        
        # Atualizar status
        prescription.status = "cancelled"
        prescription.verification_notes = f"Cancelada: {reason}"
        
        # Remover da lista de medicamentos ativos do paciente
        patient = self.patients.get(prescription.patient_id)
        if patient and prescription_id in patient.active_medications:
            patient.active_medications.remove(prescription_id)
        
        # Integração FHIR, se disponível
        if self.fhir_client:
            try:
                # Atualizar MedicationRequest FHIR
                medication_request = self.fhir_client.read_resource("MedicationRequest", prescription_id)
                medication_request["status"] = "cancelled"
                
                # Adicionar notas de cancelamento
                if "note" not in medication_request:
                    medication_request["note"] = []
                
                medication_request["note"].append({
                    "text": f"Cancelada: {reason}",
                    "time": datetime.datetime.now().isoformat(),
                    "authorString": "System"
                })
                
                # Enviar para o servidor FHIR
                self.fhir_client.update_resource(medication_request)
            
            except Exception as e:
                print(f"Erro ao atualizar MedicationRequest FHIR: {e}")
                return False
        
        return True
    
    def complete_prescription(self, prescription_id: str) -> bool:
        """
        Marca uma prescrição como concluída.
        
        Args:
            prescription_id (str): ID da prescrição.
            
        Returns:
            bool: True se a operação foi bem-sucedida, False caso contrário.
            
        Raises:
            ValueError: Se a prescrição não existir.
        """
        if prescription_id not in self.prescriptions:
            raise ValueError(f"Prescrição com ID {prescription_id} não encontrada.")
        
        prescription = self.prescriptions[prescription_id]
        
        # Atualizar status
        prescription.status = "completed"
        
        # Remover da lista de medicamentos ativos do paciente
        patient = self.patients.get(prescription.patient_id)
        if patient and prescription_id in patient.active_medications:
            patient.active_medications.remove(prescription_id)
        
        # Integração FHIR, se disponível
        if self.fhir_client:
            try:
                # Atualizar MedicationRequest FHIR
                medication_request = self.fhir_client.read_resource("MedicationRequest", prescription_id)
                medication_request["status"] = "completed"
                
                # Enviar para o servidor FHIR
                self.fhir_client.update_resource(medication_request)
            
            except Exception as e:
                print(f"Erro ao atualizar MedicationRequest FHIR: {e}")
                return False
        
        return True
    
    def renew_prescription(self, prescription_id: str, duration: Optional[int] = None, 
                          refills: Optional[int] = None) -> str:
        """
        Renova uma prescrição existente.
        
        Args:
            prescription_id (str): ID da prescrição a ser renovada.
            duration (Optional[int]): Nova duração em dias. Se None, usa a mesma da prescrição original.
            refills (Optional[int]): Novo número de recargas. Se None, usa o mesmo da prescrição original.
            
        Returns:
            str: ID da nova prescrição.
            
        Raises:
            ValueError: Se a prescrição não existir.
            VerificationError: Se a nova prescrição falhar nas verificações de segurança.
        """
        if prescription_id not in self.prescriptions:
            raise ValueError(f"Prescrição com ID {prescription_id} não encontrada.")
        
        # Obter prescrição original
        original = self.prescriptions[prescription_id]
        
        # Definir valores para a nova prescrição
        start_date = datetime.datetime.now().isoformat()
        
        if duration is None and original.end_date:
            # Calcular duração da prescrição original
            start_datetime = datetime.datetime.fromisoformat(original.start_date.replace('Z', '+00:00'))
            end_datetime = datetime.datetime.fromisoformat(original.end_date.replace('Z', '+00:00'))
            duration = (end_datetime - start_datetime).days
        
        if refills is None:
            refills = original.refills
        
        # Criar nova prescrição
        return self.create_prescription(
            patient_id=original.patient_id,
            prescriber_id=original.prescriber_id,
            medication_id=original.medication_id,
            dosage_schedule=original.dosage_schedule,
            instructions=original.instructions,
            start_date=start_date,
            duration=duration,
            refills=refills,
            dispense_amount=original.dispense_amount,
            pharmacy_notes=original.pharmacy_notes
        )
    
    def save_to_file(self, filename: str) -> None:
        """
        Salva o estado atual do sistema em um arquivo JSON.
        
        Args:
            filename (str): Nome do arquivo.
        """
        data = {
            "medications": {m_id: m.to_dict() for m_id, m in self.medications.items()},
            "patients": {p_id: p.to_dict() for p_id, p in self.patients.items()},
            "prescribers": {p_id: p.to_dict() for p_id, p in self.prescribers.items()},
            "prescriptions": {rx_id: rx.to_dict() for rx_id, rx in self.prescriptions.items()}
        }
        
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)
    
    def load_from_file(self, filename: str) -> None:
        """
        Carrega o estado do sistema de um arquivo JSON.
        
        Args:
            filename (str): Nome do arquivo.
        """
        with open(filename, 'r') as f:
            data = json.load(f)
        
        self.medications = {m_id: Medication.from_dict(m) for m_id, m in data.get("medications", {}).items()}
        self.patients = {p_id: Patient.from_dict(p) for p_id, p in data.get("patients", {}).items()}
        self.prescribers = {p_id: Prescriber.from_dict(p) for p_id, p in data.get("prescribers", {}).items()}
        self.prescriptions = {rx_id: Prescription.from_dict(rx) for rx_id, rx in data.get("prescriptions", {}).items()}


# Exemplo de uso
if __name__ == "__main__":
    # Criar sistema de prescrição
    prescription_system = PrescriptionSystem()
    
    # Adicionar medicamentos
    paracetamol = Medication(
        id="M001",
        name="Paracetamol",
        active_ingredient="Acetaminophen",
        strength="500 mg",
        form="tablet",
        route="oral",
        atc_code="N02BE01",
        max_daily_dose="4000 mg"
    )
    
    ibuprofen = Medication(
        id="M002",
        name="Ibuprofeno",
        active_ingredient="Ibuprofen",
        strength="400 mg",
        form="tablet",
        route="oral",
        atc_code="M01AE01",
        contraindications=["asthma", "peptic ulcer"],
        max_daily_dose="2400 mg"
    )
    
    prescription_system.add_medication(paracetamol)
    prescription_system.add_medication(ibuprofen)
    
    # Adicionar pacientes
    patient = Patient(
        id="P001",
        name="João Silva",
        birth_date="1980-05-15",
        gender="male",
        weight=70.5,
        height=175,
        allergies=["penicillin"],
        conditions=["hypertension"]
    )
    
    prescription_system.add_patient(patient)
    
    # Adicionar prescritores
    doctor = Prescriber(
        id="DR001",
        name="Dra. Maria Oliveira",
        license_number="CRM12345",
        specialty="Clínica Médica",
        prescribing_rights=["controlled_substances"]
    )
    
    prescription_system.add_prescriber(doctor)
    
    # Criar prescrição
    try:
        dosage = DosageSchedule(
            dose=Dose(500, "mg"),
            frequency="every 8 hours",
            duration=5,
            as_needed=True,
            timing_description="after meals"
        )
        
        prescription_id = prescription_system.create_prescription(
            patient_id="P001",
            prescriber_id="DR001",
            medication_id="M001",
            dosage_schedule=dosage,
            instructions="Take with water for pain relief",
            duration=5,
            refills=0
        )
        
        print(f"Prescrição criada com sucesso. ID: {prescription_id}")
        
        # Obter prescrição
        prescription = prescription_system.get_prescription(prescription_id)
        print(f"Status da prescrição: {prescription.verification_status}")
        print(f"Notas de verificação: {prescription.verification_notes}")
        
    except (ValueError, VerificationError) as e:
        print(f"Erro: {e}")
