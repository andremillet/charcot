#!/usr/bin/env python3
"""
Analisador Sintático para a Linguagem Charcot

Este módulo implementa o analisador sintático (parser) para a linguagem Charcot,
responsável por transformar a sequência de tokens em uma árvore sintática abstrata (AST).
"""

from typing import List, Optional, Any, Dict, Union, Callable
from dataclasses import dataclass
from enum import Enum, auto

from lexer import Token, TokenType


class NodeType(Enum):
    """Tipos de nós na árvore sintática abstrata."""
    # Expressões
    BINARY = auto()        # Expressão binária (a + b)
    GROUPING = auto()      # Expressão agrupada ((a + b))
    LITERAL = auto()       # Literal (123, "texto", true)
    UNARY = auto()         # Expressão unária (-a, !b)
    VARIABLE = auto()      # Referência a variável (nome)
    ASSIGN = auto()        # Atribuição (a = b)
    CALL = auto()          # Chamada de função (f(x))
    GET = auto()           # Acesso a propriedade (obj.prop)
    SET = auto()           # Definição de propriedade (obj.prop = val)
    LOGICAL = auto()       # Operação lógica (a and b, a or b)
    
    # Declarações
    BLOCK = auto()         # Bloco de código { ... }
    EXPRESSION = auto()    # Declaração de expressão
    FUNCTION = auto()      # Declaração de função
    IF = auto()            # Declaração if
    RETURN = auto()        # Declaração return
    LET = auto()           # Declaração de variável
    WHILE = auto()         # Declaração while
    FOR = auto()           # Declaração for
    STRUCT = auto()        # Declaração de struct
    IMPORT = auto()        # Declaração import
    PROCEDURE = auto()     # Declaração de procedimento médico
    MATCH = auto()         # Declaração match
    
    # Específicos para medicina
    PATIENT = auto()       # Declaração de paciente
    MEDICATION = auto()    # Declaração de medicamento
    PRESCRIPTION = auto()  # Declaração de prescrição
    WORKFLOW = auto()      # Declaração de workflow


@dataclass
class Node:
    """Nó base para a árvore sintática abstrata."""
    type: NodeType
    
    def accept(self, visitor):
        """
        Implementa o padrão Visitor para percorrer a AST.
        
        Args:
            visitor: O visitante que processará o nó.
            
        Returns:
            O resultado do processamento pelo visitante.
        """
        method_name = f"visit_{self.type.name.lower()}_node"
        method = getattr(visitor, method_name, visitor.visit_node)
        return method(self)


@dataclass
class Expression(Node):
    """Classe base para nós de expressão."""
    pass


@dataclass
class Binary(Expression):
    """Expressão binária (a + b)."""
    left: Expression
    operator: Token
    right: Expression
    
    def __init__(self, left: Expression, operator: Token, right: Expression):
        super().__init__(NodeType.BINARY)
        self.left = left
        self.operator = operator
        self.right = right


@dataclass
class Grouping(Expression):
    """Expressão agrupada ((a + b))."""
    expression: Expression
    
    def __init__(self, expression: Expression):
        super().__init__(NodeType.GROUPING)
        self.expression = expression


@dataclass
class Literal(Expression):
    """Literal (123, "texto", true)."""
    value: Any
    
    def __init__(self, value: Any):
        super().__init__(NodeType.LITERAL)
        self.value = value


@dataclass
class Unary(Expression):
    """Expressão unária (-a, !b)."""
    operator: Token
    right: Expression
    
    def __init__(self, operator: Token, right: Expression):
        super().__init__(NodeType.UNARY)
        self.operator = operator
        self.right = right


@dataclass
class Variable(Expression):
    """Referência a variável (nome)."""
    name: Token
    
    def __init__(self, name: Token):
        super().__init__(NodeType.VARIABLE)
        self.name = name


@dataclass
class Assign(Expression):
    """Atribuição (a = b)."""
    name: Token
    value: Expression
    
    def __init__(self, name: Token, value: Expression):
        super().__init__(NodeType.ASSIGN)
        self.name = name
        self.value = value


@dataclass
class Call(Expression):
    """Chamada de função (f(x))."""
    callee: Expression
    paren: Token
    arguments: List[Expression]
    
    def __init__(self, callee: Expression, paren: Token, arguments: List[Expression]):
        super().__init__(NodeType.CALL)
        self.callee = callee
        self.paren = paren
        self.arguments = arguments


@dataclass
class Get(Expression):
    """Acesso a propriedade (obj.prop)."""
    object: Expression
    name: Token
    
    def __init__(self, object: Expression, name: Token):
        super().__init__(NodeType.GET)
        self.object = object
        self.name = name


@dataclass
class Set(Expression):
    """Definição de propriedade (obj.prop = val)."""
    object: Expression
    name: Token
    value: Expression
    
    def __init__(self, object: Expression, name: Token, value: Expression):
        super().__init__(NodeType.SET)
        self.object = object
        self.name = name
        self.value = value


@dataclass
class Logical(Expression):
    """Operação lógica (a and b, a or b)."""
    left: Expression
    operator: Token
    right: Expression
    
    def __init__(self, left: Expression, operator: Token, right: Expression):
        super().__init__(NodeType.LOGICAL)
        self.left = left
        self.operator = operator
        self.right = right


@dataclass
class Statement(Node):
    """Classe base para nós de declaração."""
    pass


@dataclass
class Block(Statement):
    """Bloco de código { ... }."""
    statements: List[Statement]
    
    def __init__(self, statements: List[Statement]):
        super().__init__(NodeType.BLOCK)
        self.statements = statements


@dataclass
class ExpressionStmt(Statement):
    """Declaração de expressão."""
    expression: Expression
    
    def __init__(self, expression: Expression):
        super().__init__(NodeType.EXPRESSION)
        self.expression = expression


@dataclass
class Function(Statement):
    """Declaração de função."""
    name: Token
    params: List[Token]
    param_types: List[Optional[Expression]]
    return_type: Optional[Expression]
    body: List[Statement]
    
    def __init__(self, name: Token, params: List[Token], param_types: List[Optional[Expression]],
                 return_type: Optional[Expression], body: List[Statement]):
        super().__init__(NodeType.FUNCTION)
        self.name = name
        self.params = params
        self.param_types = param_types
        self.return_type = return_type
        self.body = body


@dataclass
class If(Statement):
    """Declaração if."""
    condition: Expression
    then_branch: Statement
    else_branch: Optional[Statement]
    
    def __init__(self, condition: Expression, then_branch: Statement, else_branch: Optional[Statement]):
        super().__init__(NodeType.IF)
        self.condition = condition
        self.then_branch = then_branch
        self.else_branch = else_branch


@dataclass
class Return(Statement):
    """Declaração return."""
    keyword: Token
    value: Optional[Expression]
    
    def __init__(self, keyword: Token, value: Optional[Expression]):
        super().__init__(NodeType.RETURN)
        self.keyword = keyword
        self.value = value


@dataclass
class Let(Statement):
    """Declaração de variável."""
    name: Token
    type_annotation: Optional[Expression]
    initializer: Optional[Expression]
    is_mutable: bool
    
    def __init__(self, name: Token, type_annotation: Optional[Expression],
                 initializer: Optional[Expression], is_mutable: bool):
        super().__init__(NodeType.LET)
        self.name = name
        self.type_annotation = type_annotation
        self.initializer = initializer
        self.is_mutable = is_mutable


@dataclass
class While(Statement):
    """Declaração while."""
    condition: Expression
    body: Statement
    
    def __init__(self, condition: Expression, body: Statement):
        super().__init__(NodeType.WHILE)
        self.condition = condition
        self.body = body


@dataclass
class For(Statement):
    """Declaração for."""
    variable: Token
    iterable: Expression
    body: Statement
    
    def __init__(self, variable: Token, iterable: Expression, body: Statement):
        super().__init__(NodeType.FOR)
        self.variable = variable
        self.iterable = iterable
        self.body = body


@dataclass
class Struct(Statement):
    """Declaração de struct."""
    name: Token
    fields: List[Token]
    field_types: List[Expression]
    methods: List[Function]
    
    def __init__(self, name: Token, fields: List[Token], field_types: List[Expression], methods: List[Function]):
        super().__init__(NodeType.STRUCT)
        self.name = name
        self.fields = fields
        self.field_types = field_types
        self.methods = methods


@dataclass
class Import(Statement):
    """Declaração import."""
    module: Token
    alias: Optional[Token]
    
    def __init__(self, module: Token, alias: Optional[Token]):
        super().__init__(NodeType.IMPORT)
        self.module = module
        self.alias = alias


@dataclass
class Procedure(Statement):
    """Declaração de procedimento médico."""
    name: Token
    params: List[Token]
    param_types: List[Optional[Expression]]
    body: List[Statement]
    verifications: List[Expression]
    
    def __init__(self, name: Token, params: List[Token], param_types: List[Optional[Expression]],
                 body: List[Statement], verifications: List[Expression]):
        super().__init__(NodeType.PROCEDURE)
        self.name = name
        self.params = params
        self.param_types = param_types
        self.body = body
        self.verifications = verifications


@dataclass
class Match(Statement):
    """Declaração match."""
    value: Expression
    cases: List[tuple[Expression, Statement]]
    
    def __init__(self, value: Expression, cases: List[tuple[Expression, Statement]]):
        super().__init__(NodeType.MATCH)
        self.value = value
        self.cases = cases


class ParseError(Exception):
    """Exceção lançada quando ocorre um erro de análise sintática."""
    pass


class Parser:
    """
    Analisador sintático para a linguagem Charcot.
    
    Converte uma sequência de tokens em uma árvore sintática abstrata (AST).
    """
    
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.current = 0
        self.errors: List[str] = []
    
    def parse(self) -> List[Statement]:
        """
        Analisa a sequência de tokens e retorna a AST.
        
        Returns:
            List[Statement]: A lista de declarações que formam o programa.
        """
        statements = []
        
        while not self.is_at_end():
            try:
                stmt = self.declaration()
                if stmt:
                    statements.append(stmt)
            except ParseError as e:
                self.synchronize()
        
        return statements
    
    def declaration(self) -> Optional[Statement]:
        """
        Analisa uma declaração.
        
        Returns:
            Optional[Statement]: A declaração analisada ou None em caso de erro.
        """
        try:
            if self.match(TokenType.FN):
                return self.function_declaration("function")
            if self.match(TokenType.LET):
                return self.var_declaration()
            if self.match(TokenType.STRUCT):
                return self.struct_declaration()
            if self.match(TokenType.IMPORT):
                return self.import_declaration()
            if self.match(TokenType.PROCEDURE):
                return self.procedure_declaration()
            
            return self.statement()
        except ParseError:
            self.synchronize()
            return None
    
    def function_declaration(self, kind: str) -> Function:
        """
        Analisa uma declaração de função.
        
        Args:
            kind (str): O tipo de função ("function", "method").
            
        Returns:
            Function: A declaração de função analisada.
        """
        name = self.consume(TokenType.IDENTIFIER, f"Esperado nome de {kind}.")
        
        self.consume(TokenType.LEFT_PAREN, f"Esperado '(' após o nome de {kind}.")
        
        parameters = []
        param_types = []
        
        if not self.check(TokenType.RIGHT_PAREN):
            while True:
                if len(parameters) >= 255:
                    self.error(self.peek(), "Não pode ter mais de 255 parâmetros.")
                
                param_name = self.consume(TokenType.IDENTIFIER, "Esperado nome de parâmetro.")
                
                # Verificar anotação de tipo
                param_type = None
                if self.match(TokenType.COLON):
                    param_type = self.type_expression()
                
                parameters.append(param_name)
                param_types.append(param_type)
                
                if not self.match(TokenType.COMMA):
                    break
        
        self.consume(TokenType.RIGHT_PAREN, "Esperado ')' após parâmetros.")
        
        # Verificar tipo de retorno
        return_type = None
        if self.match(TokenType.ARROW):
            return_type = self.type_expression()
        
        # Corpo da função
        self.consume(TokenType.COLON, f"Esperado ':' antes do corpo de {kind}.")
        self.consume(TokenType.NEWLINE, f"Esperado nova linha após ':' em {kind}.")
        self.consume(TokenType.INDENT, f"Esperado indentação no corpo de {kind}.")
        
        body = []
        while not self.check(TokenType.DEDENT) and not self.is_at_end():
            body.append(self.declaration())
        
        self.consume(TokenType.DEDENT, f"Esperado dedentação após o corpo de {kind}.")
        
        return Function(name, parameters, param_types, return_type, body)
    
    def var_declaration(self) -> Let:
        """
        Analisa uma declaração de variável.
        
        Returns:
            Let: A declaração de variável analisada.
        """
        is_mutable = False
        if self.match(TokenType.MUT):
            is_mutable = True
        
        name = self.consume(TokenType.IDENTIFIER, "Esperado nome de variável.")
        
        # Verificar anotação de tipo
        type_annotation = None
        if self.match(TokenType.COLON):
            type_annotation = self.type_expression()
        
        # Verificar inicializador
        initializer = None
        if self.match(TokenType.EQUAL):
            initializer = self.expression()
        
        self.consume_end_of_statement("Esperado fim de declaração de variável.")
        
        return Let(name, type_annotation, initializer, is_mutable)
    
    def struct_declaration(self) -> Struct:
        """
        Analisa uma declaração de struct.
        
        Returns:
            Struct: A declaração de struct analisada.
        """
        name = self.consume(TokenType.IDENTIFIER, "Esperado nome de struct.")
        
        self.consume(TokenType.COLON, "Esperado ':' após nome de struct.")
        self.consume(TokenType.NEWLINE, "Esperado nova linha após ':'.")
        self.consume(TokenType.INDENT, "Esperado indentação no corpo de struct.")
        
        fields = []
        field_types = []
        methods = []
        
        while not self.check(TokenType.DEDENT) and not self.is_at_end():
            if self.match(TokenType.FN):
                methods.append(self.function_declaration("method"))
            else:
                field_name = self.consume(TokenType.IDENTIFIER, "Esperado nome de campo ou método.")
                self.consume(TokenType.COLON, "Esperado ':' após nome de campo.")
                field_type = self.type_expression()
                
                fields.append(field_name)
                field_types.append(field_type)
                
                self.consume_end_of_statement("Esperado fim de declaração de campo.")
        
        self.consume(TokenType.DEDENT, "Esperado dedentação após o corpo de struct.")
        
        return Struct(name, fields, field_types, methods)
    
    def import_declaration(self) -> Import:
        """
        Analisa uma declaração de importação.
        
        Returns:
            Import: A declaração de importação analisada.
        """
        module = self.consume(TokenType.IDENTIFIER, "Esperado nome de módulo.")
        
        alias = None
        if self.match(TokenType.AS):
            alias = self.consume(TokenType.IDENTIFIER, "Esperado alias após 'as'.")
        
        self.consume_end_of_statement("Esperado fim de declaração de importação.")
        
        return Import(module, alias)
    
    def procedure_declaration(self) -> Procedure:
        """
        Analisa uma declaração de procedimento médico.
        
        Returns:
            Procedure: A declaração de procedimento analisada.
        """
        name = self.consume(TokenType.IDENTIFIER, "Esperado nome de procedimento.")
        
        self.consume(TokenType.LEFT_PAREN, "Esperado '(' após o nome de procedimento.")
        
        parameters = []
        param_types = []
        
        if not self.check(TokenType.RIGHT_PAREN):
            while True:
                if len(parameters) >= 255:
                    self.error(self.peek(), "Não pode ter mais de 255 parâmetros.")
                
                param_name = self.consume(TokenType.IDENTIFIER, "Esperado nome de parâmetro.")
                
                # Verificar anotação de tipo
                param_type = None
                if self.match(TokenType.COLON):
                    param_type = self.type_expression()
                
                parameters.append(param_name)
                param_types.append(param_type)
                
                if not self.match(TokenType.COMMA):
                    break
        
        self.consume(TokenType.RIGHT_PAREN, "Esperado ')' após parâmetros.")
        
        # Corpo do procedimento
        self.consume(TokenType.COLON, "Esperado ':' antes do corpo de procedimento.")
        self.consume(TokenType.NEWLINE, "Esperado nova linha após ':' em procedimento.")
        self.consume(TokenType.INDENT, "Esperado indentação no corpo de procedimento.")
        
        verifications = []
        body = []
        
        while not self.check(TokenType.DEDENT) and not self.is_at_end():
            if self.match(TokenType.VERIFY):
                verifications.append(self.expression())
                self.consume_end_of_statement("Esperado fim de verificação.")
            else:
                body.append(self.declaration())
        
        self.consume(TokenType.DEDENT, "Esperado dedentação após o corpo de procedimento.")
        
        return Procedure(name, parameters, param_types, body, verifications)
    
    def statement(self) -> Statement:
        """
        Analisa uma declaração.
        
        Returns:
            Statement: A declaração analisada.
        """
        if self.match(TokenType.IF):
            return self.if_statement()
        if self.match(TokenType.WHILE):
            return self.while_statement()
        if self.match(TokenType.FOR):
            return self.for_statement()
        if self.match(TokenType.RETURN):
            return self.return_statement()
        if self.match(TokenType.MATCH):
            return self.match_statement()
        if self.check(TokenType.LEFT_BRACE):
            self.advance()
            return Block(self.block())
        
        return self.expression_statement()
    
    def if_statement(self) -> If:
        """
        Analisa uma declaração if.
        
        Returns:
            If: A declaração if analisada.
        """
        condition = self.expression()
        
        self.consume(TokenType.COLON, "Esperado ':' após condição if.")
        
        then_branch = None
        if self.match(TokenType.NEWLINE):
            self.consume(TokenType.INDENT, "Esperado indentação no bloco if.")
            
            then_statements = []
            while not self.check(TokenType.DEDENT) and not self.is_at_end():
                then_statements.append(self.declaration())
            
            self.consume(TokenType.DEDENT, "Esperado dedentação após bloco if.")
            
            then_branch = Block(then_statements)
        else:
            then_branch = self.statement()
        
        else_branch = None
        if self.match(TokenType.ELSE):
            if self.match(TokenType.COLON):
                self.consume(TokenType.NEWLINE, "Esperado nova linha após ':'.")
                self.consume(TokenType.INDENT, "Esperado indentação no bloco else.")
                
                else_statements = []
                while not self.check(TokenType.DEDENT) and not self.is_at_end():
                    else_statements.append(self.declaration())
                
                self.consume(TokenType.DEDENT, "Esperado dedentação após bloco else.")
                
                else_branch = Block(else_statements)
            else:
                else_branch = self.statement()
        
        return If(condition, then_branch, else_branch)
    
    def while_statement(self) -> While:
        """
        Analisa uma declaração while.
        
        Returns:
            While: A declaração while analisada.
        """
        condition = self.expression()
        
        self.consume(TokenType.COLON, "Esperado ':' após condição while.")
        
        body = None
        if self.match(TokenType.NEWLINE):
            self.consume(TokenType.INDENT, "Esperado indentação no bloco while.")
            
            body_statements = []
            while not self.check(TokenType.DEDENT) and not self.is_at_end():
                body_statements.append(self.declaration())
            
            self.consume(TokenType.DEDENT, "Esperado dedentação após bloco while.")
            
            body = Block(body_statements)
        else:
            body = self.statement()
        
        return While(condition, body)
    
    def for_statement(self) -> Statement:
        """
        Analisa uma declaração for.
        
        Returns:
            Statement: A declaração for analisada.
        """
        variable = self.consume(TokenType.IDENTIFIER, "Esperado nome de variável em for.")
        
        self.consume(TokenType.IN, "Esperado 'in' após nome de variável em for.")
        
        iterable = self.expression()
        
        self.consume(TokenType.COLON, "Esperado ':' após iterável em for.")
        
        body = None
        if self.match(TokenType.NEWLINE):
            self.consume(TokenType.INDENT, "Esperado indentação no bloco for.")
            
            body_statements = []
            while not self.check(TokenType.DEDENT) and not self.is_at_end():
                body_statements.append(self.declaration())
            
            self.consume(TokenType.DEDENT, "Esperado dedentação após bloco for.")
            
            body = Block(body_statements)
        else:
            body = self.statement()
        
        return For(variable, iterable, body)
    
    def return_statement(self) -> Return:
        """
        Analisa uma declaração return.
        
        Returns:
            Return: A declaração return analisada.
        """
        keyword = self.previous()
        
        value = None
        if not self.check(TokenType.NEWLINE) and not self.check(TokenType.SEMICOLON):
            value = self.expression()
        
        self.consume_end_of_statement("Esperado fim de declaração return.")
        
        return Return(keyword, value)
    
    def match_statement(self) -> Match:
        """
        Analisa uma declaração match.
        
        Returns:
            Match: A declaração match analisada.
        """
        value = self.expression()
        
        self.consume(TokenType.COLON, "Esperado ':' após valor em match.")
        self.consume(TokenType.NEWLINE, "Esperado nova linha após ':'.")
        self.consume(TokenType.INDENT, "Esperado indentação no bloco match.")
        
        cases = []
        
        while not self.check(TokenType.DEDENT) and not self.is_at_end():
            pattern = self.expression()
            
            self.consume(TokenType.ARROW, "Esperado '=>' após padrão em match.")
            
            if self.match(TokenType.LEFT_BRACE):
                case_body = Block(self.block())
            else:
                case_body = self.statement()
            
            cases.append((pattern, case_body))
        
        self.consume(TokenType.DEDENT, "Esperado dedentação após bloco match.")
        
        return Match(value, cases)
    
    def expression_statement(self) -> ExpressionStmt:
        """
        Analisa uma declaração de expressão.
        
        Returns:
            ExpressionStmt: A declaração de expressão analisada.
        """
        expr = self.expression()
        
        self.consume_end_of_statement("Esperado fim de expressão.")
        
        return ExpressionStmt(expr)
    
    def block(self) -> List[Statement]:
        """
        Analisa um bloco de código.
        
        Returns:
            List[Statement]: A lista de declarações no bloco.
        """
        statements = []
        
        while not self.check(TokenType.RIGHT_BRACE) and not self.is_at_end():
            statements.append(self.declaration())
        
        self.consume(TokenType.RIGHT_BRACE, "Esperado '}' após bloco.")
        
        return statements
    
    def expression(self) -> Expression:
        """
        Analisa uma expressão.
        
        Returns:
            Expression: A expressão analisada.
        """
        return self.assignment()
    
    def assignment(self) -> Expression:
        """
        Analisa uma expressão de atribuição.
        
        Returns:
            Expression: A expressão de atribuição analisada.
        """
        expr = self.logical_or()
        
        if self.match(TokenType.EQUAL, TokenType.PLUS_EQUAL, TokenType.MINUS_EQUAL,
                      TokenType.STAR_EQUAL, TokenType.SLASH_EQUAL, TokenType.PERCENT_EQUAL):
            operator = self.previous()
            value = self.assignment()
            
            if isinstance(expr, Variable):
                return Assign(expr.name, value)
            elif isinstance(expr, Get):
                return Set(expr.object, expr.name, value)
            
            self.error(operator, "Alvo de atribuição inválido.")
        
        return expr
    
    def logical_or(self) -> Expression:
        """
        Analisa uma expressão lógica OR.
        
        Returns:
            Expression: A expressão lógica OR analisada.
        """
        expr = self.logical_and()
        
        while self.match(TokenType.OR):
            operator = self.previous()
            right = self.logical_and()
            expr = Logical(expr, operator, right)
        
        return expr
    
    def logical_and(self) -> Expression:
        """
        Analisa uma expressão lógica AND.
        
        Returns:
            Expression: A expressão lógica AND analisada.
        """
        expr = self.equality()
        
        while self.match(TokenType.AND):
            operator = self.previous()
            right = self.equality()
            expr = Logical(expr, operator, right)
        
        return expr
    
    def equality(self) -> Expression:
        """
        Analisa uma expressão de igualdade.
        
        Returns:
            Expression: A expressão de igualdade analisada.
        """
        expr = self.comparison()
        
        while self.match(TokenType.BANG_EQUAL, TokenType.EQUAL_EQUAL):
            operator = self.previous()
            right = self.comparison()
            expr = Binary(expr, operator, right)
        
        return expr
    
    def comparison(self) -> Expression:
        """
        Analisa uma expressão de comparação.
        
        Returns:
            Expression: A expressão de comparação analisada.
        """
        expr = self.term()
        
        while self.match(TokenType.GREATER, TokenType.GREATER_EQUAL, TokenType.LESS, TokenType.LESS_EQUAL):
            operator = self.previous()
            right = self.term()
            expr = Binary(expr, operator, right)
        
        return expr
    
    def term(self) -> Expression:
        """
        Analisa uma expressão de termo.
        
        Returns:
            Expression: A expressão de termo analisada.
        """
        expr = self.factor()
        
        while self.match(TokenType.MINUS, TokenType.PLUS):
            operator = self.previous()
            right = self.factor()
            expr = Binary(expr, operator, right)
        
        return expr
    
    def factor(self) -> Expression:
        """
        Analisa uma expressão de fator.
        
        Returns:
            Expression: A expressão de fator analisada.
        """
        expr = self.unary()
        
        while self.match(TokenType.SLASH, TokenType.STAR, TokenType.PERCENT, TokenType.POWER):
            operator = self.previous()
            right = self.unary()
            expr = Binary(expr, operator, right)
        
        return expr
    
    def unary(self) -> Expression:
        """
        Analisa uma expressão unária.
        
        Returns:
            Expression: A expressão unária analisada.
        """
        if self.match(TokenType.BANG, TokenType.MINUS):
            operator = self.previous()
            right = self.unary()
            return Unary(operator, right)
        
        return self.call()
    
    def call(self) -> Expression:
        """
        Analisa uma expressão de chamada.
        
        Returns:
            Expression: A expressão de chamada analisada.
        """
        expr = self.primary()
        
        while True:
            if self.match(TokenType.LEFT_PAREN):
                expr = self.finish_call(expr)
            elif self.match(TokenType.DOT):
                name = self.consume(TokenType.IDENTIFIER, "Esperado nome de propriedade após '.'.")
                expr = Get(expr, name)
            else:
                break
        
        return expr
    
    def finish_call(self, callee: Expression) -> Expression:
        """
        Finaliza a análise de uma expressão de chamada.
        
        Args:
            callee (Expression): A expressão que está sendo chamada.
            
        Returns:
            Expression: A expressão de chamada completa.
        """
        arguments = []
        
        if not self.check(TokenType.RIGHT_PAREN):
            while True:
                if len(arguments) >= 255:
                    self.error(self.peek(), "Não pode ter mais de 255 argumentos.")
                
                arguments.append(self.expression())
                
                if not self.match(TokenType.COMMA):
                    break
        
        paren = self.consume(TokenType.RIGHT_PAREN, "Esperado ')' após argumentos.")
        
        return Call(callee, paren, arguments)
    
    def primary(self) -> Expression:
        """
        Analisa uma expressão primária.
        
        Returns:
            Expression: A expressão primária analisada.
        """
        if self.match(TokenType.FALSE):
            return Literal(False)
        if self.match(TokenType.TRUE):
            return Literal(True)
        if self.match(TokenType.NONE):
            return Literal(None)
        
        if self.match(TokenType.NUMBER, TokenType.STRING):
            return Literal(self.previous().literal)
        
        if self.match(TokenType.IDENTIFIER):
            return Variable(self.previous())
        
        if self.match(TokenType.LEFT_PAREN):
            expr = self.expression()
            self.consume(TokenType.RIGHT_PAREN, "Esperado ')' após expressão.")
            return Grouping(expr)
        
        raise self.error(self.peek(), "Esperado expressão.")
    
    def type_expression(self) -> Expression:
        """
        Analisa uma expressão de tipo.
        
        Returns:
            Expression: A expressão de tipo analisada.
        """
        if self.match(TokenType.IDENTIFIER):
            base_type = Variable(self.previous())
            
            # Verificar se é um tipo genérico
            if self.match(TokenType.LEFT_BRACKET):
                type_args = []
                
                while True:
                    type_args.append(self.type_expression())
                    
                    if not self.match(TokenType.COMMA):
                        break
                
                self.consume(TokenType.RIGHT_BRACKET, "Esperado ']' após argumentos de tipo.")
                
                # Criar uma expressão de chamada para representar o tipo genérico
                return Call(base_type, self.previous(), type_args)
            
            return base_type
        
        raise self.error(self.peek(), "Esperado expressão de tipo.")
    
    def consume_end_of_statement(self, message: str) -> None:
        """
        Consome o fim de uma declaração (nova linha ou ponto e vírgula).
        
        Args:
            message (str): A mensagem de erro em caso de falha.
        """
        if self.match(TokenType.SEMICOLON):
            # Consumir ponto e vírgula
            pass
        elif self.match(TokenType.NEWLINE):
            # Consumir nova linha
            pass
        else:
            raise self.error(self.peek(), message)
    
    def match(self, *types: TokenType) -> bool:
        """
        Verifica se o token atual é de um dos tipos especificados e avança se for.
        
        Args:
            *types: Os tipos de token a serem verificados.
            
        Returns:
            bool: True se o token atual for de um dos tipos especificados, False caso contrário.
        """
        for type in types:
            if self.check(type):
                self.advance()
                return True
        
        return False
    
    def check(self, type: TokenType) -> bool:
        """
        Verifica se o token atual é do tipo especificado.
        
        Args:
            type (TokenType): O tipo de token a ser verificado.
            
        Returns:
            bool: True se o token atual for do tipo especificado, False caso contrário.
        """
        if self.is_at_end():
            return False
        return self.peek().type == type
    
    def advance(self) -> Token:
        """
        Avança para o próximo token e retorna o anterior.
        
        Returns:
            Token: O token anterior.
        """
        if not self.is_at_end():
            self.current += 1
        return self.previous()
    
    def is_at_end(self) -> bool:
        """
        Verifica se chegamos ao final da sequência de tokens.
        
        Returns:
            bool: True se chegamos ao final, False caso contrário.
        """
        return self.peek().type == TokenType.EOF
    
    def peek(self) -> Token:
        """
        Retorna o token atual sem avançar.
        
        Returns:
            Token: O token atual.
        """
        return self.tokens[self.current]
    
    def previous(self) -> Token:
        """
        Retorna o token anterior.
        
        Returns:
            Token: O token anterior.
        """
        return self.tokens[self.current - 1]
    
    def error(self, token: Token, message: str) -> ParseError:
        """
        Reporta um erro de análise sintática.
        
        Args:
            token (Token): O token onde ocorreu o erro.
            message (str): A mensagem de erro.
            
        Returns:
            ParseError: A exceção de erro de análise sintática.
        """
        error_msg = f"[linha {token.line}, coluna {token.column}] Erro"
        
        if token.type == TokenType.EOF:
            error_msg += " no final do arquivo"
        else:
            error_msg += f" em '{token.lexeme}'"
        
        error_msg += f": {message}"
        self.errors.append(error_msg)
        
        return ParseError(error_msg)
    
    def synchronize(self) -> None:
        """
        Sincroniza o parser após um erro, avançando até o início da próxima declaração.
        """
        self.advance()
        
        while not self.is_at_end():
            if self.previous().type == TokenType.SEMICOLON or self.previous().type == TokenType.NEWLINE:
                return
            
            if self.peek().type in [
                TokenType.FN, TokenType.LET, TokenType.FOR, TokenType.IF,
                TokenType.WHILE, TokenType.RETURN, TokenType.STRUCT, TokenType.IMPORT
            ]:
                return
            
            self.advance()


def parse(tokens: List[Token]) -> tuple[List[Statement], List[str]]:
    """
    Função auxiliar para analisar uma lista de tokens.
    
    Args:
        tokens (List[Token]): A lista de tokens a ser analisada.
        
    Returns:
        tuple[List[Statement], List[str]]: A AST e a lista de erros encontrados.
    """
    parser = Parser(tokens)
    statements = parser.parse()
    return statements, parser.errors


if __name__ == "__main__":
    from lexer import tokenize
    
    # Exemplo de uso
    code = """
# Este é um exemplo de código Charcot

fn calcular_dose(peso: float, medicamento: Medication) -> Dose:
    if peso < 10:
        return Dose(peso * 0.1, "mg")
    else:
        return Dose(peso * 0.2, "mg")

paciente = Patient {
    id: "P12345",
    nome: "João Silva",
    peso: 70.5
}

dose = calcular_dose(paciente.peso, medicamentos.paracetamol)
print(f"Dose recomendada: {dose}")
"""
    
    tokens = tokenize(code)
    statements, errors = parse(tokens)
    
    if errors:
        print("Erros encontrados:")
        for error in errors:
            print(error)
    else:
        print(f"Análise sintática concluída com sucesso. {len(statements)} declarações encontradas.")
