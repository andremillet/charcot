#!/usr/bin/env python3
"""
Módulo de Documentação Interativa para o REPL da Linguagem Charcot

Este módulo implementa recursos de ajuda e documentação para o ambiente REPL da linguagem Charcot,
incluindo exemplos, tutoriais e referências para os recursos específicos de medicina.
"""

import os
import sys
import textwrap
import json
from typing import Dict, List, Any, Optional
import colorama
from colorama import Fore, Back, Style

# Inicializar colorama para formatação de texto colorido
colorama.init()


class CharcotDocumentation:
    """Gerencia a documentação interativa para o REPL da linguagem Charcot."""
    
    def __init__(self, docs_dir: Optional[str] = None):
        """
        Inicializa o sistema de documentação.
        
        Args:
            docs_dir (Optional[str]): Diretório contendo arquivos de documentação.
        """
        self.docs_dir = docs_dir or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "docs")
        
        # Carregar documentação
        self.topics = self._load_topics()
        self.examples = self._load_examples()
        self.tutorials = self._load_tutorials()
        self.references = self._load_references()
    
    def _load_topics(self) -> Dict[str, str]:
        """
        Carrega tópicos de documentação.
        
        Returns:
            Dict[str, str]: Dicionário de tópicos.
        """
        topics = {
            "language": """
# Linguagem Charcot

A linguagem Charcot é uma linguagem de programação projetada especificamente para aplicações médicas.
Ela combina a sintaxe intuitiva do Python com a segurança e desempenho do Rust, além de incorporar
nativamente conceitos médicos e padrões como FHIR.

## Características Principais

- **Sintaxe Simples e Intuitiva**: Inspirada em Python, fácil de aprender e usar.
- **Segurança de Tipos**: Sistema de tipos estático que previne erros comuns.
- **Recursos Específicos para Medicina**: Tipos de dados e funções específicas para o domínio médico.
- **Integração FHIR**: Suporte nativo ao padrão FHIR para interoperabilidade.
- **Workflows Hospitalares**: Funções para gerenciar processos hospitalares e ambulatoriais.
- **Sistema de Prescrição**: Verificações de segurança automáticas para prescrições médicas.
- **Segurança e Privacidade**: Recursos avançados para proteção de dados sensíveis.

## Começando

Para começar a usar a linguagem Charcot, experimente os exemplos disponíveis digitando `examples`
e carregue um exemplo com `example <nome>`. Consulte a documentação específica com `help <tópico>`.
""",
            
            "types": """
# Tipos de Dados na Linguagem Charcot

A linguagem Charcot inclui tipos de dados básicos e tipos específicos para medicina.

## Tipos Básicos

- **int**: Números inteiros
- **float**: Números de ponto flutuante
- **string**: Sequências de caracteres
- **bool**: Valores booleanos (true/false)
- **list**: Listas de valores
- **dict**: Dicionários (mapas chave-valor)

## Tipos Específicos para Medicina

- **patient**: Representa um paciente no sistema
- **medication**: Representa um medicamento
- **prescription**: Representa uma prescrição médica
- **encounter**: Representa um encontro clínico (consulta, internação)
- **observation**: Representa uma observação clínica
- **condition**: Representa uma condição médica
- **procedure**: Representa um procedimento médico

## Exemplo de Uso

```
# Definir um paciente
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175
}

# Definir um medicamento
medication Paracetamol {
    active_ingredient: "Acetaminophen",
    strength: "500 mg",
    form: "tablet",
    route: "oral"
}
```
""",
            
            "functions": """
# Funções na Linguagem Charcot

A linguagem Charcot inclui funções básicas e funções específicas para medicina.

## Funções Básicas

- **print()**: Exibe valores na tela
- **input()**: Lê entrada do usuário
- **len()**: Retorna o tamanho de uma coleção
- **str()**, **int()**, **float()**, **bool()**: Conversão de tipos
- **min()**, **max()**, **sum()**: Operações em coleções

## Funções Específicas para Medicina

### Pacientes
- **calculate_bmi(patient)**: Calcula o IMC de um paciente
- **calculate_age(patient)**: Calcula a idade de um paciente

### Workflows Hospitalares
- **admit_patient()**: Interna um paciente
- **discharge_patient()**: Dá alta a um paciente
- **transfer_patient()**: Transfere um paciente
- **schedule_appointment()**: Agenda uma consulta

### Prescrições
- **prescribe()**: Cria uma prescrição
- **safety_check()**: Verifica a segurança de uma prescrição
- **issue()**: Emite uma prescrição
- **cancel()**: Cancela uma prescrição

### Medicamentos
- **administer_medication()**: Administra um medicamento
- **check_interaction()**: Verifica interações medicamentosas

## Exemplo de Uso

```
# Internar paciente
encounter = admit_patient(
    patient: Patient1,
    location: "Room 101",
    reason: "Pneumonia"
)

# Verificar segurança de prescrição
safety_result = safety_check(new_rx)
if safety_result.is_safe:
    issue(new_rx)
```
""",
            
            "fhir": """
# Integração FHIR na Linguagem Charcot

A linguagem Charcot integra nativamente o padrão FHIR (Fast Healthcare Interoperability Resources)
para garantir interoperabilidade com sistemas de saúde.

## Recursos FHIR Suportados

- **Patient**: Informações demográficas e clínicas de pacientes
- **Practitioner**: Profissionais de saúde
- **Medication**: Medicamentos
- **MedicationRequest**: Prescrições de medicamentos
- **Encounter**: Encontros clínicos (consultas, internações)
- **Observation**: Observações clínicas (sinais vitais, resultados de exames)
- **Condition**: Condições médicas (diagnósticos)
- **Procedure**: Procedimentos médicos

## Funções FHIR

- **fhir_create()**: Cria um recurso FHIR
- **fhir_read()**: Lê um recurso FHIR
- **fhir_update()**: Atualiza um recurso FHIR
- **fhir_delete()**: Exclui um recurso FHIR
- **fhir_search()**: Pesquisa recursos FHIR

## Exemplo de Uso

```
# Criar paciente FHIR
patient_fhir = fhir_create(
    resourceType: "Patient",
    name: [{
        given: ["João"],
        family: "Silva"
    }],
    gender: "male",
    birthDate: "1980-05-15"
)

# Pesquisar medicamentos
medications = fhir_search(
    resourceType: "Medication",
    params: {
        "code": "acetaminophen"
    }
)
```
""",
            
            "workflows": """
# Workflows Hospitalares na Linguagem Charcot

A linguagem Charcot suporta nativamente workflows hospitalares e ambulatoriais,
permitindo a automação de processos clínicos.

## Workflows Suportados

- **Internação**: Admissão, transferência e alta de pacientes
- **Ambulatorial**: Agendamento, check-in e conclusão de consultas
- **Medicação**: Prescrição, dispensação e administração de medicamentos
- **Exames**: Solicitação, coleta, análise e resultados de exames

## Funções de Workflow

### Internação
- **admit_patient()**: Interna um paciente
- **transfer_patient()**: Transfere um paciente para outra localização
- **discharge_patient()**: Dá alta a um paciente

### Ambulatorial
- **schedule_appointment()**: Agenda uma consulta
- **check_in_patient()**: Registra a chegada do paciente
- **start_appointment()**: Inicia uma consulta
- **end_appointment()**: Finaliza uma consulta

### Medicação
- **prescribe()**: Cria uma prescrição
- **dispense_medication()**: Dispensa um medicamento
- **administer_medication()**: Administra um medicamento

## Exemplo de Uso

```
# Workflow de internação
encounter = admit_patient(
    patient: Patient1,
    location: "Room 101",
    reason: "Pneumonia"
)

# Administrar medicação
administer_medication(
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    route: "oral"
)

# Transferir paciente
transfer_patient(
    encounter: encounter,
    new_location: "Room 202",
    reason: "Necessidade de monitoramento"
)

# Dar alta
discharge_patient(
    encounter: encounter,
    notes: "Paciente recuperado. Seguimento em 1 semana."
)
```
""",
            
            "prescription": """
# Sistema de Prescrição na Linguagem Charcot

A linguagem Charcot inclui um sistema de prescrição médica com verificações
de segurança automáticas.

## Componentes do Sistema de Prescrição

- **Medicamentos**: Definição de medicamentos com informações completas
- **Pacientes**: Informações clínicas relevantes para prescrições
- **Prescritores**: Médicos e outros profissionais com direitos de prescrição
- **Prescrições**: Instruções detalhadas para uso de medicamentos
- **Verificações de Segurança**: Validações automáticas de segurança

## Verificações de Segurança

- **Alergias**: Verifica se o paciente tem alergia ao medicamento
- **Interações**: Verifica interações com outros medicamentos ativos
- **Contraindicações**: Verifica contraindicações com base nas condições do paciente
- **Dose**: Verifica se a dose está dentro dos limites seguros
- **Direitos de Prescrição**: Verifica se o prescritor tem autorização

## Funções de Prescrição

- **prescribe()**: Cria uma prescrição
- **safety_check()**: Verifica a segurança de uma prescrição
- **issue()**: Emite uma prescrição
- **cancel()**: Cancela uma prescrição
- **renew()**: Renova uma prescrição existente

## Exemplo de Uso

```
# Criar prescrição
prescription new_rx {
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    frequency: "every 6 hours",
    duration: 5,
    instructions: "Take with water for pain relief"
}

# Verificar segurança
safety_result = safety_check(new_rx)

# Emitir prescrição se segura
if safety_result.is_safe:
    issue(new_rx)
    print("Prescrição emitida com sucesso")
else:
    print(f"Prescrição não emitida: {safety_result.notes}")
```
""",
            
            "security": """
# Segurança e Privacidade na Linguagem Charcot

A linguagem Charcot inclui recursos avançados de segurança e privacidade
para proteção de dados sensíveis de saúde.

## Recursos de Segurança

- **Criptografia**: Proteção de dados sensíveis
- **Controle de Acesso**: Baseado em papéis e permissões
- **Auditoria**: Registro detalhado de ações
- **Anonimização**: Remoção de identificadores para uso em pesquisa
- **Proteção de PHI**: Detecção e mascaramento de informações de saúde protegidas

## Funções de Segurança

- **encrypt_data()**: Criptografa dados sensíveis
- **decrypt_data()**: Descriptografa dados
- **authenticate()**: Autentica um usuário
- **check_permission()**: Verifica permissões de acesso
- **audit_log()**: Registra ações no log de auditoria
- **anonymize_data()**: Anonimiza dados para pesquisa
- **mask_phi()**: Mascara informações de saúde protegidas
- **detect_phi()**: Detecta possíveis informações de saúde protegidas

## Exemplo de Uso

```
# Autenticar usuário
if authenticate(username: "dr.silva", password: "senha123"):
    # Verificar permissão
    if check_permission("prescription:create"):
        # Criar prescrição
        rx = prescribe(...)
        
        # Registrar no log de auditoria
        audit_log(
            action: "create",
            resource: "prescription",
            resource_id: rx.id
        )
    else:
        print("Permissão negada")
```
"""
        }
        
        return topics
    
    def _load_examples(self) -> Dict[str, str]:
        """
        Carrega exemplos de código Charcot.
        
        Returns:
            Dict[str, str]: Dicionário de exemplos.
        """
        examples = {
            "hello_world": """
# Exemplo: Hello World
# Um simples programa "Olá, Mundo" na linguagem Charcot

print("Olá, mundo da medicina!")
""",
            
            "patient_bmi": """
# Exemplo: Cálculo de IMC
# Demonstra a criação de um paciente e cálculo de IMC

# Definir um paciente
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175
}

# Calcular IMC
bmi = Patient1.weight / ((Patient1.height / 100) ** 2)
print(f"Paciente: {Patient1.name}")
print(f"IMC: {bmi:.1f}")

# Classificar IMC
if bmi < 18.5:
    print("Classificação: Abaixo do peso")
elif bmi < 25:
    print("Classificação: Peso normal")
elif bmi < 30:
    print("Classificação: Sobrepeso")
else:
    print("Classificação: Obesidade")
""",
            
            "medication_safety": """
# Exemplo: Segurança de Medicamentos
# Demonstra a verificação de segurança de medicamentos

# Definir um medicamento
medication Paracetamol {
    active_ingredient: "Acetaminophen",
    strength: "500 mg",
    form: "tablet",
    route: "oral",
    max_daily_dose: "4000 mg",
    contraindications: ["liver failure"]
}

# Definir um paciente
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175,
    conditions: ["hypertension"]
}

# Verificar dose
dose = 2 * 500  # 2 comprimidos de 500mg
frequency = 4   # 4 vezes ao dia
daily_dose = dose * frequency

print(f"Medicamento: {Paracetamol.active_ingredient} {Paracetamol.strength}")
print(f"Dose prescrita: {dose} mg, {frequency} vezes ao dia")
print(f"Dose diária total: {daily_dose} mg")
print(f"Dose máxima diária: {Paracetamol.max_daily_dose}")

if daily_dose > 4000:
    print("ALERTA: Dose diária excede o máximo recomendado!")
else:
    print("Dose diária dentro do limite seguro.")

# Verificar contraindicações
for condition in Patient1.conditions:
    if condition in Paracetamol.contraindications:
        print(f"ALERTA: Medicamento contraindicado para pacientes com {condition}!")
""",
            
            "prescription_workflow": """
# Exemplo: Workflow de Prescrição
# Demonstra o processo completo de prescrição médica

# Definir um paciente
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175,
    allergies: ["penicillin"],
    conditions: ["hypertension"]
}

# Definir um medicamento
medication Paracetamol {
    active_ingredient: "Acetaminophen",
    strength: "500 mg",
    form: "tablet",
    route: "oral",
    max_daily_dose: "4000 mg"
}

# Definir um prescritor
prescriber Doctor1 {
    name: "Dra. Maria Oliveira",
    license: "CRM12345",
    specialty: "Clínica Médica"
}

# Criar uma prescrição
prescription new_rx {
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    frequency: "every 6 hours",
    duration: 5,  # dias
    instructions: "Take with water for pain relief",
    prescriber: Doctor1
}

# Verificar segurança
safety_result = safety_check(new_rx)

# Exibir resultado da verificação
print(f"Prescrição: {Paracetamol.active_ingredient} {new_rx.dose}, {new_rx.frequency}")
print(f"Paciente: {Patient1.name}")
print(f"Prescritor: {Doctor1.name}")
print(f"Resultado da verificação: {safety_result.status}")

# Emitir prescrição se segura
if safety_result.is_safe:
    issue(new_rx)
    print("Prescrição emitida com sucesso")
    
    # Simular administração do medicamento
    administer_medication(
        patient: Patient1,
        medication: Paracetamol,
        dose: "500 mg",
        route: "oral",
        time: now()
    )
    print("Medicamento administrado")
else:
    print(f"Prescrição não emitida: {safety_result.notes}")
""",
            
            "hospital_workflow": """
# Exemplo: Workflow Hospitalar
# Demonstra o processo de internação, transferência e alta

# Definir um paciente
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175,
    conditions: ["pneumonia"]
}

# Definir localizações
location Ward_A {
    name: "Ala A",
    type: "ward",
    capacity: 10
}

location Room_101 {
    name: "Quarto 101",
    type: "room",
    parent: Ward_A,
    capacity: 2
}

location Room_202 {
    name: "Quarto 202",
    type: "room",
    parent: Ward_A,
    capacity: 1
}

# Definir médico
prescriber Doctor1 {
    name: "Dra. Maria Oliveira",
    license: "CRM12345",
    specialty: "Pneumologia"
}

# Internar paciente
print(f"Internando paciente {Patient1.name} com {Patient1.conditions[0]}")
encounter = admit_patient(
    patient: Patient1,
    location: Room_101,
    reason: "Pneumonia",
    attending: Doctor1
)
print(f"Paciente internado no {Room_101.name}")

# Administrar medicação
medication Antibiotico {
    active_ingredient: "Amoxicillin",
    strength: "500 mg",
    form: "capsule",
    route: "oral"
}

print(f"Administrando {Antibiotico.active_ingredient}")
administer_medication(
    patient: Patient1,
    medication: Antibiotico,
    dose: "500 mg",
    route: "oral",
    time: now()
)

# Transferir paciente
print("Transferindo paciente para monitoramento mais próximo")
transfer_patient(
    encounter: encounter,
    new_location: Room_202,
    reason: "Necessidade de monitoramento mais próximo"
)
print(f"Paciente transferido para {Room_202.name}")

# Dar alta ao paciente
print("Paciente recuperado, preparando alta")
discharge_patient(
    encounter: encounter,
    notes: "Paciente recuperado. Seguimento ambulatorial em 1 semana."
)
print("Paciente recebeu alta hospitalar")
""",
            
            "fhir_integration": """
# Exemplo: Integração FHIR
# Demonstra a integração com o padrão FHIR

# Configurar cliente FHIR
fhir_client = connect_fhir(
    base_url: "http://hapi.fhir.org/baseR4",
    auth_token: null
)

# Criar paciente FHIR
print("Criando paciente no servidor FHIR")
patient_data = {
    "resourceType": "Patient",
    "active": true,
    "name": [
        {
            "given": ["João"],
            "family": "Silva"
        }
    ],
    "gender": "male",
    "birthDate": "1980-05-15"
}

patient_resource = fhir_create(
    client: fhir_client,
    resource: patient_data
)

print(f"Paciente criado com ID: {patient_resource.id}")

# Criar medicamento FHIR
print("Criando medicamento no servidor FHIR")
medication_data = {
    "resourceType": "Medication",
    "code": {
        "coding": [
            {
                "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
                "code": "1049502",
                "display": "Acetaminophen 325 MG Oral Tablet"
            }
        ],
        "text": "Acetaminophen 325 MG Oral Tablet"
    }
}

medication_resource = fhir_create(
    client: fhir_client,
    resource: medication_data
)

print(f"Medicamento criado com ID: {medication_resource.id}")

# Criar prescrição FHIR
print("Criando prescrição no servidor FHIR")
prescription_data = {
    "resourceType": "MedicationRequest",
    "status": "active",
    "intent": "order",
    "medicationReference": {
        "reference": f"Medication/{medication_resource.id}",
        "display": "Acetaminophen 325 MG Oral Tablet"
    },
    "subject": {
        "reference": f"Patient/{patient_resource.id}",
        "display": "João Silva"
    },
    "authoredOn": now(),
    "dosageInstruction": [
        {
            "text": "Take 1 tablet by mouth every 4-6 hours as needed for pain.",
            "doseAndRate": [
                {
                    "doseQuantity": {
                        "value": 1,
                        "unit": "tablet",
                        "system": "http://unitsofmeasure.org",
                        "code": "TAB"
                    }
                }
            ]
        }
    ]
}

prescription_resource = fhir_create(
    client: fhir_client,
    resource: prescription_data
)

print(f"Prescrição criada com ID: {prescription_resource.id}")

# Pesquisar pacientes
print("Pesquisando pacientes")
search_result = fhir_search(
    client: fhir_client,
    resourceType: "Patient",
    params: {
        "family": "Silva"
    }
)

print(f"Encontrados {len(search_result.entry)} pacientes")
"""
        }
        
        return examples
    
    def _load_tutorials(self) -> Dict[str, str]:
        """
        Carrega tutoriais para a linguagem Charcot.
        
        Returns:
            Dict[str, str]: Dicionário de tutoriais.
        """
        tutorials = {
            "getting_started": """
# Tutorial: Primeiros Passos com a Linguagem Charcot

Este tutorial irá guiá-lo através dos conceitos básicos da linguagem Charcot,
uma linguagem de programação projetada especificamente para aplicações médicas.

## 1. Instalação

A linguagem Charcot pode ser instalada usando pip:

```
pip install charcot
```

Após a instalação, você pode iniciar o REPL com o comando:

```
charcot
```

## 2. Sintaxe Básica

A sintaxe da linguagem Charcot é inspirada em Python, com algumas adições específicas para medicina.

### Variáveis e Tipos

```
# Variáveis básicas
nome = "João Silva"
idade = 42
peso = 70.5
ativo = true

# Listas e dicionários
alergias = ["penicillin", "sulfa"]
vitais = {
    "pressao": "120/80",
    "temperatura": 36.5,
    "frequencia_cardiaca": 72
}
```

### Estruturas de Controle

```
# Condicionais
if idade > 65:
    print("Paciente idoso")
elif idade < 18:
    print("Paciente pediátrico")
else:
    print("Paciente adulto")

# Loops
for alergia in alergias:
    print(f"Paciente alérgico a {alergia}")

while peso > 100:
    peso = peso - 0.5
    print(f"Novo peso: {peso}")
```

## 3. Tipos Específicos para Medicina

A linguagem Charcot inclui tipos de dados específicos para medicina:

```
# Definir um paciente
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175
}

# Definir um medicamento
medication Paracetamol {
    active_ingredient: "Acetaminophen",
    strength: "500 mg",
    form: "tablet",
    route: "oral"
}
```

## 4. Funções Específicas para Medicina

```
# Calcular IMC
bmi = calculate_bmi(Patient1)
print(f"IMC: {bmi}")

# Verificar interação medicamentosa
interaction = check_interaction(Paracetamol, Ibuprofeno)
if interaction:
    print(f"Interação detectada: {interaction}")
```

## 5. Próximos Passos

- Explore os exemplos disponíveis com o comando `examples`
- Consulte a documentação completa com `help <tópico>`
- Experimente criar seus próprios programas Charcot

Para mais informações, visite a documentação oficial em https://charcot-lang.org
""",
            
            "prescription_tutorial": """
# Tutorial: Criando um Sistema de Prescrição Médica

Este tutorial irá guiá-lo através do processo de criação de um sistema de prescrição
médica completo usando a linguagem Charcot.

## 1. Configuração Inicial

Primeiro, vamos importar os módulos necessários e configurar o ambiente:

```
# Importar módulos
import fhir
import security
import prescription

# Configurar cliente FHIR
fhir_client = fhir.connect(
    base_url: "http://hapi.fhir.org/baseR4"
)

# Configurar segurança
security_manager = security.init(
    log_file: "audit.log"
)
```

## 2. Definindo Medicamentos

Vamos definir alguns medicamentos para nosso sistema:

```
# Analgésico
medication Paracetamol {
    active_ingredient: "Acetaminophen",
    strength: "500 mg",
    form: "tablet",
    route: "oral",
    max_daily_dose: "4000 mg",
    contraindications: ["liver failure"],
    interactions: {
        "Warfarin": "Pode aumentar o efeito anticoagulante"
    }
}

# Anti-inflamatório
medication Ibuprofeno {
    active_ingredient: "Ibuprofen",
    strength: "400 mg",
    form: "tablet",
    route: "oral",
    max_daily_dose: "2400 mg",
    contraindications: ["peptic ulcer", "asthma"],
    interactions: {
        "Aspirin": "Aumenta o risco de sangramento gastrointestinal",
        "Lisinopril": "Pode reduzir o efeito anti-hipertensivo"
    }
}
```

## 3. Definindo Pacientes

Agora, vamos definir alguns pacientes:

```
# Paciente sem condições especiais
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175
}

# Paciente com condições especiais
patient Patient2 {
    name: "Maria Oliveira",
    birth_date: "1975-10-20",
    gender: "female",
    weight: 65.0,
    height: 160,
    allergies: ["penicillin"],
    conditions: ["peptic ulcer", "hypertension"],
    active_medications: ["Lisinopril"]
}
```

## 4. Definindo Prescritores

Vamos definir os profissionais que podem prescrever:

```
# Médico clínico
prescriber Doctor1 {
    name: "Dr. Carlos Santos",
    license: "CRM12345",
    specialty: "Clínica Médica",
    prescribing_rights: ["controlled_substances"]
}

# Enfermeira
prescriber Nurse1 {
    name: "Enf. Ana Pereira",
    license: "COREN67890",
    specialty: "Enfermagem",
    prescribing_rights: []
}
```

## 5. Criando Prescrições

Agora podemos criar prescrições:

```
# Prescrição segura
try {
    prescription rx1 {
        patient: Patient1,
        medication: Paracetamol,
        dose: "500 mg",
        frequency: "every 6 hours",
        duration: 5,
        instructions: "Take with water for pain relief",
        prescriber: Doctor1
    }
    
    # Verificar segurança
    safety_result = safety_check(rx1)
    
    if safety_result.is_safe:
        issue(rx1)
        print("Prescrição 1 emitida com sucesso")
    else:
        print(f"Prescrição 1 não emitida: {safety_result.notes}")
} catch (e) {
    print(f"Erro: {e}")
}

# Prescrição com potencial problema
try {
    prescription rx2 {
        patient: Patient2,
        medication: Ibuprofeno,  # Contraindicado para úlcera péptica
        dose: "400 mg",
        frequency: "every 8 hours",
        duration: 7,
        instructions: "Take with food for inflammation",
        prescriber: Doctor1
    }
    
    # Verificar segurança
    safety_result = safety_check(rx2)
    
    if safety_result.is_safe:
        issue(rx2)
        print("Prescrição 2 emitida com sucesso")
    else:
        print(f"Prescrição 2 não emitida: {safety_result.notes}")
} catch (e) {
    print(f"Erro: {e}")
}
```

## 6. Administrando Medicamentos

Finalmente, vamos administrar os medicamentos prescritos:

```
# Administrar medicamento
if rx1.status == "active":
    administer_medication(
        patient: Patient1,
        medication: Paracetamol,
        dose: "500 mg",
        route: "oral",
        time: now()
    )
    print("Medicamento administrado ao paciente 1")
```

## 7. Auditoria e Segurança

Vamos verificar o log de auditoria:

```
# Obter logs de auditoria
logs = security_manager.get_audit_logs(
    filters: {
        "resource_type": "prescription"
    }
)

print(f"Número de registros de auditoria: {len(logs)}")
for log in logs:
    print(f"{log.timestamp}: {log.action} {log.resource_type} por {log.user_id}")
```

## 8. Próximos Passos

- Adicione mais medicamentos ao sistema
- Implemente verificações de segurança adicionais
- Integre com um sistema FHIR real
- Adicione uma interface de usuário

Para mais informações sobre o sistema de prescrição, consulte `help prescription`.
""",
            
            "fhir_tutorial": """
# Tutorial: Integração FHIR com a Linguagem Charcot

Este tutorial irá guiá-lo através do processo de integração com sistemas FHIR
usando a linguagem Charcot.

## 1. Introdução ao FHIR

FHIR (Fast Healthcare Interoperability Resources) é um padrão para troca de
informações de saúde eletronicamente. A linguagem Charcot integra nativamente
o FHIR para garantir interoperabilidade com sistemas de saúde.

## 2. Configurando o Cliente FHIR

Primeiro, vamos configurar um cliente FHIR:

```
# Importar módulo FHIR
import fhir

# Configurar cliente FHIR
fhir_client = fhir.connect(
    base_url: "http://hapi.fhir.org/baseR4",
    auth_token: null  # Opcional, para servidores que requerem autenticação
)
```

## 3. Criando Recursos FHIR

Vamos criar alguns recursos FHIR básicos:

```
# Criar paciente
patient_data = {
    "resourceType": "Patient",
    "active": true,
    "name": [
        {
            "given": ["João"],
            "family": "Silva"
        }
    ],
    "gender": "male",
    "birthDate": "1980-05-15"
}

patient_resource = fhir_create(
    client: fhir_client,
    resource: patient_data
)

print(f"Paciente criado com ID: {patient_resource.id}")

# Criar medicamento
medication_data = {
    "resourceType": "Medication",
    "code": {
        "coding": [
            {
                "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
                "code": "1049502",
                "display": "Acetaminophen 325 MG Oral Tablet"
            }
        ],
        "text": "Acetaminophen 325 MG Oral Tablet"
    }
}

medication_resource = fhir_create(
    client: fhir_client,
    resource: medication_data
)

print(f"Medicamento criado com ID: {medication_resource.id}")
```

## 4. Lendo Recursos FHIR

Agora, vamos ler os recursos que criamos:

```
# Ler paciente
patient = fhir_read(
    client: fhir_client,
    resourceType: "Patient",
    id: patient_resource.id
)

print(f"Nome do paciente: {patient.name[0].given[0]} {patient.name[0].family}")

# Ler medicamento
medication = fhir_read(
    client: fhir_client,
    resourceType: "Medication",
    id: medication_resource.id
)

print(f"Medicamento: {medication.code.text}")
```

## 5. Pesquisando Recursos FHIR

Vamos pesquisar recursos no servidor FHIR:

```
# Pesquisar pacientes
patients = fhir_search(
    client: fhir_client,
    resourceType: "Patient",
    params: {
        "family": "Silva"
    }
)

print(f"Encontrados {len(patients.entry)} pacientes")

# Pesquisar medicamentos
medications = fhir_search(
    client: fhir_client,
    resourceType: "Medication",
    params: {
        "code": "acetaminophen"
    }
)

print(f"Encontrados {len(medications.entry)} medicamentos")
```

## 6. Atualizando Recursos FHIR

Vamos atualizar um recurso existente:

```
# Atualizar paciente
patient.telecom = [
    {
        "system": "phone",
        "value": "555-123-4567",
        "use": "home"
    }
]

updated_patient = fhir_update(
    client: fhir_client,
    resource: patient
)

print("Paciente atualizado com sucesso")
```

## 7. Criando uma Prescrição FHIR

Vamos criar uma prescrição usando MedicationRequest:

```
# Criar prescrição
prescription_data = {
    "resourceType": "MedicationRequest",
    "status": "active",
    "intent": "order",
    "medicationReference": {
        "reference": f"Medication/{medication_resource.id}",
        "display": "Acetaminophen 325 MG Oral Tablet"
    },
    "subject": {
        "reference": f"Patient/{patient_resource.id}",
        "display": "João Silva"
    },
    "authoredOn": now(),
    "dosageInstruction": [
        {
            "text": "Take 1 tablet by mouth every 4-6 hours as needed for pain.",
            "doseAndRate": [
                {
                    "doseQuantity": {
                        "value": 1,
                        "unit": "tablet",
                        "system": "http://unitsofmeasure.org",
                        "code": "TAB"
                    }
                }
            ]
        }
    ]
}

prescription_resource = fhir_create(
    client: fhir_client,
    resource: prescription_data
)

print(f"Prescrição criada com ID: {prescription_resource.id}")
```

## 8. Convertendo entre FHIR e Charcot

A linguagem Charcot permite converter facilmente entre objetos nativos e recursos FHIR:

```
# Converter paciente FHIR para paciente Charcot
charcot_patient = Patient.from_fhir(patient)
print(f"Paciente Charcot: {charcot_patient.name}")

# Converter paciente Charcot para FHIR
fhir_patient = charcot_patient.to_fhir()
print(f"Paciente FHIR: {fhir_patient.name[0].given[0]} {fhir_patient.name[0].family}")
```

## 9. Próximos Passos

- Explore outros tipos de recursos FHIR
- Implemente operações FHIR mais avançadas
- Integre com um servidor FHIR real em sua instituição
- Desenvolva aplicações que usam FHIR para interoperabilidade

Para mais informações sobre FHIR, consulte `help fhir`.
"""
        }
        
        return tutorials
    
    def _load_references(self) -> Dict[str, Dict[str, str]]:
        """
        Carrega referências para a linguagem Charcot.
        
        Returns:
            Dict[str, Dict[str, str]]: Dicionário de referências.
        """
        references = {
            "types": {
                "patient": """
# Tipo: patient

Representa um paciente no sistema.

## Sintaxe

```
patient <nome> {
    name: <string>,
    birth_date: <string>,
    gender: <string>,
    [weight: <float>],
    [height: <float>],
    [allergies: [<string>, ...]],
    [conditions: [<string>, ...]],
    [active_medications: [<string>, ...]]
}
```

## Atributos

- **name**: Nome completo do paciente
- **birth_date**: Data de nascimento (formato ISO: YYYY-MM-DD)
- **gender**: Gênero (male, female, other, unknown)
- **weight**: Peso em kg (opcional)
- **height**: Altura em cm (opcional)
- **allergies**: Lista de alergias (opcional)
- **conditions**: Lista de condições médicas (opcional)
- **active_medications**: Lista de IDs de prescrições ativas (opcional)

## Métodos

- **calculate_bmi()**: Calcula o IMC (Índice de Massa Corporal)
- **calculate_age()**: Calcula a idade atual
- **to_fhir()**: Converte para recurso FHIR Patient
- **from_fhir(fhir_patient)**: Cria um paciente a partir de um recurso FHIR

## Exemplo

```
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175,
    allergies: ["penicillin"],
    conditions: ["hypertension"]
}

bmi = Patient1.calculate_bmi()
age = Patient1.calculate_age()
```
""",
                
                "medication": """
# Tipo: medication

Representa um medicamento no sistema.

## Sintaxe

```
medication <nome> {
    active_ingredient: <string>,
    strength: <string>,
    form: <string>,
    route: <string>,
    [atc_code: <string>],
    [max_daily_dose: <string>],
    [contraindications: [<string>, ...]],
    [interactions: {<string>: <string>, ...}],
    [requires_prescription: <bool>],
    [controlled_substance: <bool>]
}
```

## Atributos

- **active_ingredient**: Princípio ativo
- **strength**: Concentração (ex: "500 mg")
- **form**: Forma farmacêutica (ex: "tablet", "solution")
- **route**: Via de administração (ex: "oral", "intravenous")
- **atc_code**: Código ATC (opcional)
- **max_daily_dose**: Dose máxima diária (opcional)
- **contraindications**: Lista de contraindicações (opcional)
- **interactions**: Dicionário de interações medicamentosas (opcional)
- **requires_prescription**: Se requer prescrição (opcional, padrão: true)
- **controlled_substance**: Se é substância controlada (opcional, padrão: false)

## Métodos

- **to_fhir()**: Converte para recurso FHIR Medication
- **from_fhir(fhir_medication)**: Cria um medicamento a partir de um recurso FHIR

## Exemplo

```
medication Paracetamol {
    active_ingredient: "Acetaminophen",
    strength: "500 mg",
    form: "tablet",
    route: "oral",
    max_daily_dose: "4000 mg",
    contraindications: ["liver failure"],
    interactions: {
        "Warfarin": "Pode aumentar o efeito anticoagulante"
    }
}
```
""",
                
                "prescription": """
# Tipo: prescription

Representa uma prescrição médica.

## Sintaxe

```
prescription <nome> {
    patient: <patient>,
    medication: <medication>,
    dose: <string>,
    frequency: <string>,
    [duration: <int>],
    [instructions: <string>],
    [start_date: <string>],
    [end_date: <string>],
    [refills: <int>],
    [dispense_amount: <int>],
    [prescriber: <prescriber>]
}
```

## Atributos

- **patient**: Paciente
- **medication**: Medicamento
- **dose**: Dose (ex: "500 mg")
- **frequency**: Frequência (ex: "every 8 hours")
- **duration**: Duração em dias (opcional)
- **instructions**: Instruções para o paciente (opcional)
- **start_date**: Data de início (opcional, padrão: data atual)
- **end_date**: Data de término (opcional)
- **refills**: Número de recargas permitidas (opcional, padrão: 0)
- **dispense_amount**: Quantidade a ser dispensada (opcional)
- **prescriber**: Prescritor (opcional)

## Atributos Adicionais (Gerados)

- **id**: ID único da prescrição
- **date_written**: Data em que a prescrição foi escrita
- **status**: Status da prescrição (active, completed, cancelled, suspended)
- **verification_status**: Status de verificação (unverified, verified, rejected)
- **verification_notes**: Notas de verificação

## Métodos

- **to_fhir()**: Converte para recurso FHIR MedicationRequest
- **from_fhir(fhir_medication_request)**: Cria uma prescrição a partir de um recurso FHIR

## Exemplo

```
prescription new_rx {
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    frequency: "every 6 hours",
    duration: 5,
    instructions: "Take with water for pain relief",
    prescriber: Doctor1
}
```
""",
                
                "encounter": """
# Tipo: encounter

Representa um encontro clínico (consulta, internação).

## Sintaxe

```
encounter <nome> {
    patient: <patient>,
    class_code: <string>,
    [status: <string>],
    [start_time: <string>],
    [end_time: <string>],
    [location: <location>],
    [practitioner: <prescriber>],
    [reason: <string>],
    [diagnoses: [<string>, ...]]
}
```

## Atributos

- **patient**: Paciente
- **class_code**: Tipo de encontro (inpatient, outpatient, emergency, etc.)
- **status**: Status (opcional, padrão: "in-progress")
- **start_time**: Data/hora de início (opcional, padrão: data/hora atual)
- **end_time**: Data/hora de término (opcional)
- **location**: Localização (opcional)
- **practitioner**: Profissional responsável (opcional)
- **reason**: Motivo do encontro (opcional)
- **diagnoses**: Lista de diagnósticos (opcional)

## Atributos Adicionais (Gerados)

- **id**: ID único do encontro

## Métodos

- **to_fhir()**: Converte para recurso FHIR Encounter
- **from_fhir(fhir_encounter)**: Cria um encontro a partir de um recurso FHIR

## Exemplo

```
encounter Encounter1 {
    patient: Patient1,
    class_code: "inpatient",
    reason: "Pneumonia",
    location: Room101,
    practitioner: Doctor1
}
```
"""
            },
            
            "functions": {
                "admit_patient": """
# Função: admit_patient()

Interna um paciente no hospital.

## Sintaxe

```
admit_patient(
    patient: <patient>,
    location: <location | string>,
    reason: <string>,
    [attending: <prescriber | string>]
)
```

## Parâmetros

- **patient**: Paciente a ser internado
- **location**: Localização (quarto, leito) ou ID/nome da localização
- **reason**: Motivo da internação
- **attending**: Médico responsável (opcional)

## Retorno

- Objeto encounter representando a internação

## Exceções

- ValueError: Se o paciente ou localização não existirem
- ValueError: Se a localização estiver ocupada

## Exemplo

```
encounter = admit_patient(
    patient: Patient1,
    location: Room101,
    reason: "Pneumonia",
    attending: Doctor1
)
```
""",
                
                "discharge_patient": """
# Função: discharge_patient()

Dá alta a um paciente.

## Sintaxe

```
discharge_patient(
    encounter: <encounter | string>,
    [notes: <string>]
)
```

## Parâmetros

- **encounter**: Encontro (internação) ou ID do encontro
- **notes**: Notas de alta (opcional)

## Retorno

- true se a alta foi bem-sucedida, false caso contrário

## Exceções

- ValueError: Se o encontro não existir
- ValueError: Se o encontro não estiver ativo

## Exemplo

```
success = discharge_patient(
    encounter: Encounter1,
    notes: "Paciente recuperado. Seguimento em 1 semana."
)
```
""",
                
                "transfer_patient": """
# Função: transfer_patient()

Transfere um paciente para outra localização.

## Sintaxe

```
transfer_patient(
    encounter: <encounter | string>,
    new_location: <location | string>,
    [reason: <string>]
)
```

## Parâmetros

- **encounter**: Encontro (internação) ou ID do encontro
- **new_location**: Nova localização ou ID/nome da nova localização
- **reason**: Motivo da transferência (opcional)

## Retorno

- true se a transferência foi bem-sucedida, false caso contrário

## Exceções

- ValueError: Se o encontro ou nova localização não existirem
- ValueError: Se a nova localização estiver ocupada
- ValueError: Se o encontro não estiver ativo

## Exemplo

```
success = transfer_patient(
    encounter: Encounter1,
    new_location: Room202,
    reason: "Necessidade de monitoramento mais próximo"
)
```
""",
                
                "prescribe": """
# Função: prescribe()

Cria uma prescrição médica.

## Sintaxe

```
prescribe(
    patient: <patient | string>,
    medication: <medication | string>,
    dose: <string>,
    frequency: <string>,
    [duration: <int>],
    [instructions: <string>],
    [start_date: <string>],
    [refills: <int>],
    [dispense_amount: <int>],
    [prescriber: <prescriber | string>]
)
```

## Parâmetros

- **patient**: Paciente ou ID do paciente
- **medication**: Medicamento ou ID do medicamento
- **dose**: Dose (ex: "500 mg")
- **frequency**: Frequência (ex: "every 8 hours")
- **duration**: Duração em dias (opcional)
- **instructions**: Instruções para o paciente (opcional)
- **start_date**: Data de início (opcional, padrão: data atual)
- **refills**: Número de recargas permitidas (opcional, padrão: 0)
- **dispense_amount**: Quantidade a ser dispensada (opcional)
- **prescriber**: Prescritor ou ID do prescritor (opcional)

## Retorno

- ID da prescrição criada

## Exceções

- ValueError: Se o paciente, medicamento ou prescritor não existirem
- VerificationError: Se a prescrição falhar nas verificações de segurança

## Exemplo

```
prescription_id = prescribe(
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    frequency: "every 6 hours",
    duration: 5,
    instructions: "Take with water for pain relief",
    prescriber: Doctor1
)
```
""",
                
                "safety_check": """
# Função: safety_check()

Verifica a segurança de uma prescrição.

## Sintaxe

```
safety_check(
    prescription: <prescription | string>
)
```

## Parâmetros

- **prescription**: Prescrição ou ID da prescrição

## Retorno

- Objeto com os seguintes atributos:
  - **status**: Status da verificação ("verified" ou "rejected")
  - **notes**: Notas de verificação
  - **is_safe**: true se a prescrição é segura, false caso contrário

## Verificações Realizadas

- Alergias: Verifica se o paciente tem alergia ao medicamento
- Interações: Verifica interações com outros medicamentos ativos
- Contraindicações: Verifica contraindicações com base nas condições do paciente
- Dose: Verifica se a dose está dentro dos limites seguros
- Direitos de Prescrição: Verifica se o prescritor tem autorização

## Exemplo

```
safety_result = safety_check(new_rx)
if safety_result.is_safe:
    print("Prescrição segura")
else:
    print(f"Prescrição não segura: {safety_result.notes}")
```
""",
                
                "administer_medication": """
# Função: administer_medication()

Administra um medicamento a um paciente.

## Sintaxe

```
administer_medication(
    patient: <patient | string>,
    medication: <medication | string>,
    dose: <string>,
    route: <string>,
    [time: <string>],
    [administrator: <string>],
    [notes: <string>]
)
```

## Parâmetros

- **patient**: Paciente ou ID do paciente
- **medication**: Medicamento ou ID do medicamento
- **dose**: Dose administrada
- **route**: Via de administração
- **time**: Data/hora da administração (opcional, padrão: data/hora atual)
- **administrator**: Pessoa que administrou o medicamento (opcional)
- **notes**: Notas adicionais (opcional)

## Retorno

- ID do registro de administração

## Exceções

- ValueError: Se o paciente ou medicamento não existirem

## Exemplo

```
administration_id = administer_medication(
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    route: "oral",
    time: now(),
    administrator: "Nurse1",
    notes: "Paciente relatou dor de cabeça"
)
```
"""
            }
        }
        
        return references
    
    def get_topic(self, topic: str) -> Optional[str]:
        """
        Obtém a documentação para um tópico.
        
        Args:
            topic (str): O tópico.
            
        Returns:
            Optional[str]: A documentação, se encontrada.
        """
        return self.topics.get(topic)
    
    def get_example(self, name: str) -> Optional[str]:
        """
        Obtém um exemplo pelo nome.
        
        Args:
            name (str): O nome do exemplo.
            
        Returns:
            Optional[str]: O exemplo, se encontrado.
        """
        return self.examples.get(name)
    
    def get_tutorial(self, name: str) -> Optional[str]:
        """
        Obtém um tutorial pelo nome.
        
        Args:
            name (str): O nome do tutorial.
            
        Returns:
            Optional[str]: O tutorial, se encontrado.
        """
        return self.tutorials.get(name)
    
    def get_reference(self, category: str, name: str) -> Optional[str]:
        """
        Obtém uma referência pelo categoria e nome.
        
        Args:
            category (str): A categoria da referência.
            name (str): O nome da referência.
            
        Returns:
            Optional[str]: A referência, se encontrada.
        """
        if category in self.references and name in self.references[category]:
            return self.references[category][name]
        return None
    
    def list_topics(self) -> List[str]:
        """
        Lista todos os tópicos disponíveis.
        
        Returns:
            List[str]: Lista de tópicos.
        """
        return list(self.topics.keys())
    
    def list_examples(self) -> List[str]:
        """
        Lista todos os exemplos disponíveis.
        
        Returns:
            List[str]: Lista de exemplos.
        """
        return list(self.examples.keys())
    
    def list_tutorials(self) -> List[str]:
        """
        Lista todos os tutoriais disponíveis.
        
        Returns:
            List[str]: Lista de tutoriais.
        """
        return list(self.tutorials.keys())
    
    def list_reference_categories(self) -> List[str]:
        """
        Lista todas as categorias de referência disponíveis.
        
        Returns:
            List[str]: Lista de categorias.
        """
        return list(self.references.keys())
    
    def list_references(self, category: str) -> List[str]:
        """
        Lista todas as referências em uma categoria.
        
        Args:
            category (str): A categoria.
            
        Returns:
            List[str]: Lista de referências.
        """
        if category in self.references:
            return list(self.references[category].keys())
        return []
    
    def format_text(self, text: str, width: int = 80, color: bool = True) -> str:
        """
        Formata texto para exibição.
        
        Args:
            text (str): O texto a ser formatado.
            width (int): Largura máxima.
            color (bool): Se deve usar cores.
            
        Returns:
            str: O texto formatado.
        """
        if not color:
            return text
        
        # Formatar cabeçalhos
        text = re.sub(r'^# (.+)$', f'{Fore.CYAN}\\1{Style.RESET_ALL}', text, flags=re.MULTILINE)
        text = re.sub(r'^## (.+)$', f'{Fore.GREEN}\\1{Style.RESET_ALL}', text, flags=re.MULTILINE)
        text = re.sub(r'^### (.+)$', f'{Fore.YELLOW}\\1{Style.RESET_ALL}', text, flags=re.MULTILINE)
        
        # Formatar código
        text = re.sub(r'```(.+?)```', lambda m: f'{Fore.BLUE}{m.group(1)}{Style.RESET_ALL}', text, flags=re.DOTALL)
        
        # Formatar negrito
        text = re.sub(r'\*\*(.+?)\*\*', f'{Fore.YELLOW}\\1{Style.RESET_ALL}', text)
        
        # Formatar itálico
        text = re.sub(r'\*(.+?)\*', f'{Fore.GREEN}\\1{Style.RESET_ALL}', text)
        
        return text


class CharcotDebugger:
    """Implementa recursos de depuração para o REPL da linguagem Charcot."""
    
    def __init__(self):
        """Inicializa o depurador."""
        self.breakpoints = set()
        self.step_mode = False
        self.current_line = 0
        self.variables = {}
        self.call_stack = []
    
    def add_breakpoint(self, line: int) -> None:
        """
        Adiciona um ponto de interrupção.
        
        Args:
            line (int): Número da linha.
        """
        self.breakpoints.add(line)
        print(f"{Fore.YELLOW}Breakpoint adicionado na linha {line}{Style.RESET_ALL}")
    
    def remove_breakpoint(self, line: int) -> None:
        """
        Remove um ponto de interrupção.
        
        Args:
            line (int): Número da linha.
        """
        if line in self.breakpoints:
            self.breakpoints.remove(line)
            print(f"{Fore.YELLOW}Breakpoint removido da linha {line}{Style.RESET_ALL}")
        else:
            print(f"{Fore.RED}Nenhum breakpoint na linha {line}{Style.RESET_ALL}")
    
    def list_breakpoints(self) -> None:
        """Lista todos os pontos de interrupção."""
        if not self.breakpoints:
            print(f"{Fore.YELLOW}Nenhum breakpoint definido.{Style.RESET_ALL}")
            return
        
        print(f"{Fore.CYAN}Breakpoints:{Style.RESET_ALL}")
        for line in sorted(self.breakpoints):
            print(f"  Linha {line}")
    
    def clear_breakpoints(self) -> None:
        """Remove todos os pontos de interrupção."""
        self.breakpoints.clear()
        print(f"{Fore.YELLOW}Todos os breakpoints foram removidos.{Style.RESET_ALL}")
    
    def step_into(self) -> None:
        """Ativa o modo de execução passo a passo (entrando em funções)."""
        self.step_mode = True
        print(f"{Fore.YELLOW}Modo de execução passo a passo ativado (step into).{Style.RESET_ALL}")
    
    def step_over(self) -> None:
        """Ativa o modo de execução passo a passo (pulando funções)."""
        self.step_mode = True
        print(f"{Fore.YELLOW}Modo de execução passo a passo ativado (step over).{Style.RESET_ALL}")
    
    def continue_execution(self) -> None:
        """Continua a execução até o próximo breakpoint."""
        self.step_mode = False
        print(f"{Fore.YELLOW}Continuando execução.{Style.RESET_ALL}")
    
    def show_variables(self) -> None:
        """Mostra as variáveis no escopo atual."""
        if not self.variables:
            print(f"{Fore.YELLOW}Nenhuma variável definida.{Style.RESET_ALL}")
            return
        
        print(f"{Fore.CYAN}Variáveis:{Style.RESET_ALL}")
        for name, value in self.variables.items():
            print(f"  {Fore.YELLOW}{name}{Style.RESET_ALL} = {value}")
    
    def show_call_stack(self) -> None:
        """Mostra a pilha de chamadas."""
        if not self.call_stack:
            print(f"{Fore.YELLOW}Pilha de chamadas vazia.{Style.RESET_ALL}")
            return
        
        print(f"{Fore.CYAN}Pilha de chamadas:{Style.RESET_ALL}")
        for i, frame in enumerate(reversed(self.call_stack)):
            print(f"  {i}: {frame['function']} (linha {frame['line']})")
    
    def evaluate_expression(self, expression: str) -> None:
        """
        Avalia uma expressão no contexto atual.
        
        Args:
            expression (str): A expressão a ser avaliada.
        """
        try:
            # Implementação simplificada
            print(f"{Fore.GREEN}=> {expression}{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Erro: {str(e)}{Style.RESET_ALL}")


# Exemplo de uso
if __name__ == "__main__":
    # Criar documentação
    docs = CharcotDocumentation()
    
    # Exibir tópico
    topic = docs.get_topic("language")
    if topic:
        print(docs.format_text(topic))
    
    # Listar exemplos
    print("\nExemplos disponíveis:")
    for example in docs.list_examples():
        print(f"  {example}")
    
    # Exibir exemplo
    example = docs.get_example("patient_bmi")
    if example:
        print("\nExemplo:")
        print(docs.format_text(example))
    
    # Criar depurador
    debugger = CharcotDebugger()
    
    # Adicionar breakpoints
    debugger.add_breakpoint(10)
    debugger.add_breakpoint(20)
    
    # Listar breakpoints
    debugger.list_breakpoints()
