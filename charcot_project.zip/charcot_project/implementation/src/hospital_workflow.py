#!/usr/bin/env python3
"""
Módulo de Workflows Hospitalares para a Linguagem Charcot

Este módulo implementa funcionalidades para gerenciar workflows hospitalares e ambulatoriais
na linguagem Charcot, incluindo internação, transferência, alta e outros processos clínicos.
"""

from typing import Dict, List, Any, Optional, Union, Callable
from dataclasses import dataclass, field
import datetime
import uuid
import json

from implementation.src.fhir_integration import FHIRClient, FHIREncounter, FHIRReference, FHIRPeriod


@dataclass
class Patient:
    """Representa um paciente no sistema hospitalar."""
    id: str
    name: str
    birth_date: str
    gender: str
    medical_record_number: Optional[str] = None
    active_encounters: List[str] = field(default_factory=list)
    allergies: List[str] = field(default_factory=list)
    conditions: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte o paciente para um dicionário."""
        return {
            "id": self.id,
            "name": self.name,
            "birth_date": self.birth_date,
            "gender": self.gender,
            "medical_record_number": self.medical_record_number,
            "active_encounters": self.active_encounters,
            "allergies": self.allergies,
            "conditions": self.conditions
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Patient':
        """Cria um paciente a partir de um dicionário."""
        return cls(
            id=data["id"],
            name=data["name"],
            birth_date=data["birth_date"],
            gender=data["gender"],
            medical_record_number=data.get("medical_record_number"),
            active_encounters=data.get("active_encounters", []),
            allergies=data.get("allergies", []),
            conditions=data.get("conditions", [])
        )
    
    @classmethod
    def from_fhir(cls, fhir_patient: Dict[str, Any]) -> 'Patient':
        """Cria um paciente a partir de um recurso FHIR Patient."""
        patient_id = fhir_patient.get("id", str(uuid.uuid4()))
        
        # Extrair nome
        name = "Unknown"
        if "name" in fhir_patient and fhir_patient["name"]:
            name_obj = fhir_patient["name"][0]
            given = " ".join(name_obj.get("given", []))
            family = name_obj.get("family", "")
            name = f"{given} {family}".strip()
        
        # Extrair data de nascimento
        birth_date = fhir_patient.get("birthDate", "Unknown")
        
        # Extrair gênero
        gender = fhir_patient.get("gender", "unknown")
        
        # Extrair número de registro médico
        medical_record_number = None
        if "identifier" in fhir_patient:
            for identifier in fhir_patient["identifier"]:
                if identifier.get("system") == "http://hospital.example.org/fhir/identifier/MRN":
                    medical_record_number = identifier.get("value")
                    break
        
        return cls(
            id=patient_id,
            name=name,
            birth_date=birth_date,
            gender=gender,
            medical_record_number=medical_record_number
        )


@dataclass
class Location:
    """Representa uma localização no hospital."""
    id: str
    name: str
    type: str  # ward, room, bed, etc.
    status: str = "active"  # active, inactive, suspended
    parent_location: Optional[str] = None
    capacity: Optional[int] = None
    current_occupancy: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte a localização para um dicionário."""
        return {
            "id": self.id,
            "name": self.name,
            "type": self.type,
            "status": self.status,
            "parent_location": self.parent_location,
            "capacity": self.capacity,
            "current_occupancy": self.current_occupancy
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Location':
        """Cria uma localização a partir de um dicionário."""
        return cls(
            id=data["id"],
            name=data["name"],
            type=data["type"],
            status=data.get("status", "active"),
            parent_location=data.get("parent_location"),
            capacity=data.get("capacity"),
            current_occupancy=data.get("current_occupancy", 0)
        )


@dataclass
class Encounter:
    """Representa um encontro (internação, consulta) no hospital."""
    id: str
    patient_id: str
    status: str  # planned, arrived, in-progress, finished, cancelled
    class_code: str  # inpatient, outpatient, emergency, etc.
    start_time: str
    end_time: Optional[str] = None
    location_id: Optional[str] = None
    practitioner_id: Optional[str] = None
    reason: Optional[str] = None
    diagnoses: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte o encontro para um dicionário."""
        return {
            "id": self.id,
            "patient_id": self.patient_id,
            "status": self.status,
            "class_code": self.class_code,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "location_id": self.location_id,
            "practitioner_id": self.practitioner_id,
            "reason": self.reason,
            "diagnoses": self.diagnoses
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Encounter':
        """Cria um encontro a partir de um dicionário."""
        return cls(
            id=data["id"],
            patient_id=data["patient_id"],
            status=data["status"],
            class_code=data["class_code"],
            start_time=data["start_time"],
            end_time=data.get("end_time"),
            location_id=data.get("location_id"),
            practitioner_id=data.get("practitioner_id"),
            reason=data.get("reason"),
            diagnoses=data.get("diagnoses", [])
        )
    
    @classmethod
    def from_fhir(cls, fhir_encounter: Dict[str, Any]) -> 'Encounter':
        """Cria um encontro a partir de um recurso FHIR Encounter."""
        encounter_id = fhir_encounter.get("id", str(uuid.uuid4()))
        
        # Extrair ID do paciente
        patient_id = None
        if "subject" in fhir_encounter and "reference" in fhir_encounter["subject"]:
            patient_ref = fhir_encounter["subject"]["reference"]
            if patient_ref.startswith("Patient/"):
                patient_id = patient_ref[8:]  # Remove "Patient/"
        
        # Extrair status
        status = fhir_encounter.get("status", "unknown")
        
        # Extrair classe
        class_code = "unknown"
        if "class" in fhir_encounter and "code" in fhir_encounter["class"]:
            class_code = fhir_encounter["class"]["code"]
        
        # Extrair período
        start_time = None
        end_time = None
        if "period" in fhir_encounter:
            start_time = fhir_encounter["period"].get("start")
            end_time = fhir_encounter["period"].get("end")
        
        if not start_time:
            start_time = datetime.datetime.now().isoformat()
        
        # Extrair localização
        location_id = None
        if "location" in fhir_encounter and fhir_encounter["location"]:
            location_ref = fhir_encounter["location"][0].get("location", {}).get("reference")
            if location_ref and location_ref.startswith("Location/"):
                location_id = location_ref[9:]  # Remove "Location/"
        
        # Extrair profissional
        practitioner_id = None
        if "participant" in fhir_encounter and fhir_encounter["participant"]:
            for participant in fhir_encounter["participant"]:
                if "individual" in participant and "reference" in participant["individual"]:
                    practitioner_ref = participant["individual"]["reference"]
                    if practitioner_ref.startswith("Practitioner/"):
                        practitioner_id = practitioner_ref[13:]  # Remove "Practitioner/"
                        break
        
        # Extrair motivo
        reason = None
        if "reasonCode" in fhir_encounter and fhir_encounter["reasonCode"]:
            reason_code = fhir_encounter["reasonCode"][0]
            if "text" in reason_code:
                reason = reason_code["text"]
            elif "coding" in reason_code and reason_code["coding"]:
                reason = reason_code["coding"][0].get("display")
        
        # Extrair diagnósticos
        diagnoses = []
        if "diagnosis" in fhir_encounter:
            for diagnosis in fhir_encounter["diagnosis"]:
                if "condition" in diagnosis and "reference" in diagnosis["condition"]:
                    condition_ref = diagnosis["condition"]["reference"]
                    if condition_ref.startswith("Condition/"):
                        diagnoses.append(condition_ref[10:])  # Remove "Condition/"
        
        return cls(
            id=encounter_id,
            patient_id=patient_id or "unknown",
            status=status,
            class_code=class_code,
            start_time=start_time,
            end_time=end_time,
            location_id=location_id,
            practitioner_id=practitioner_id,
            reason=reason,
            diagnoses=diagnoses
        )


class HospitalWorkflow:
    """Gerencia workflows hospitalares."""
    
    def __init__(self, fhir_client: Optional[FHIRClient] = None):
        """
        Inicializa o gerenciador de workflows hospitalares.
        
        Args:
            fhir_client (Optional[FHIRClient]): Cliente FHIR para integração com sistemas externos.
        """
        self.patients: Dict[str, Patient] = {}
        self.locations: Dict[str, Location] = {}
        self.encounters: Dict[str, Encounter] = {}
        self.fhir_client = fhir_client
    
    def admit_patient(self, patient_id: str, location_id: str, reason: str, 
                      practitioner_id: Optional[str] = None) -> str:
        """
        Interna um paciente no hospital.
        
        Args:
            patient_id (str): ID do paciente.
            location_id (str): ID da localização (quarto, leito).
            reason (str): Motivo da internação.
            practitioner_id (Optional[str]): ID do médico responsável.
            
        Returns:
            str: ID do encontro criado.
            
        Raises:
            ValueError: Se o paciente ou localização não existirem, ou se a localização estiver ocupada.
        """
        # Verificar se o paciente existe
        if patient_id not in self.patients:
            raise ValueError(f"Paciente com ID {patient_id} não encontrado.")
        
        # Verificar se a localização existe
        if location_id not in self.locations:
            raise ValueError(f"Localização com ID {location_id} não encontrada.")
        
        # Verificar se a localização está disponível
        location = self.locations[location_id]
        if location.capacity is not None and location.current_occupancy >= location.capacity:
            raise ValueError(f"Localização {location.name} está com capacidade máxima.")
        
        # Criar encontro
        encounter_id = str(uuid.uuid4())
        start_time = datetime.datetime.now().isoformat()
        
        encounter = Encounter(
            id=encounter_id,
            patient_id=patient_id,
            status="in-progress",
            class_code="inpatient",
            start_time=start_time,
            location_id=location_id,
            practitioner_id=practitioner_id,
            reason=reason
        )
        
        # Atualizar registros
        self.encounters[encounter_id] = encounter
        self.patients[patient_id].active_encounters.append(encounter_id)
        self.locations[location_id].current_occupancy += 1
        
        # Integração FHIR, se disponível
        if self.fhir_client:
            fhir_encounter = FHIREncounter()
            fhir_encounter.status = "in-progress"
            fhir_encounter.set_class("IMP", "http://terminology.hl7.org/CodeSystem/v3-ActCode", "inpatient encounter")
            fhir_encounter.set_subject(f"Patient/{patient_id}")
            fhir_encounter.set_period(start=start_time)
            fhir_encounter.add_location(f"Location/{location_id}")
            
            if practitioner_id:
                fhir_encounter.add_participant(f"Practitioner/{practitioner_id}")
            
            try:
                result = self.fhir_client.create_resource(fhir_encounter)
                # Atualizar ID do encontro com o ID FHIR
                if "id" in result:
                    encounter.id = result["id"]
                    self.encounters[result["id"]] = encounter
                    del self.encounters[encounter_id]
                    self.patients[patient_id].active_encounters.remove(encounter_id)
                    self.patients[patient_id].active_encounters.append(result["id"])
                    encounter_id = result["id"]
            except Exception as e:
                print(f"Erro ao criar encontro FHIR: {e}")
        
        return encounter_id
    
    def transfer_patient(self, encounter_id: str, new_location_id: str, 
                         reason: Optional[str] = None) -> bool:
        """
        Transfere um paciente para outra localização.
        
        Args:
            encounter_id (str): ID do encontro.
            new_location_id (str): ID da nova localização.
            reason (Optional[str]): Motivo da transferência.
            
        Returns:
            bool: True se a transferência foi bem-sucedida, False caso contrário.
            
        Raises:
            ValueError: Se o encontro ou nova localização não existirem, ou se a nova localização estiver ocupada.
        """
        # Verificar se o encontro existe
        if encounter_id not in self.encounters:
            raise ValueError(f"Encontro com ID {encounter_id} não encontrado.")
        
        # Verificar se a nova localização existe
        if new_location_id not in self.locations:
            raise ValueError(f"Localização com ID {new_location_id} não encontrada.")
        
        # Verificar se a nova localização está disponível
        new_location = self.locations[new_location_id]
        if new_location.capacity is not None and new_location.current_occupancy >= new_location.capacity:
            raise ValueError(f"Localização {new_location.name} está com capacidade máxima.")
        
        # Obter encontro e localização atual
        encounter = self.encounters[encounter_id]
        old_location_id = encounter.location_id
        
        # Verificar se o encontro está ativo
        if encounter.status != "in-progress":
            raise ValueError(f"Encontro com ID {encounter_id} não está ativo.")
        
        # Atualizar registros
        if old_location_id:
            self.locations[old_location_id].current_occupancy -= 1
        
        encounter.location_id = new_location_id
        self.locations[new_location_id].current_occupancy += 1
        
        # Integração FHIR, se disponível
        if self.fhir_client:
            try:
                # Obter encontro FHIR atual
                fhir_encounter = self.fhir_client.read_resource("Encounter", encounter_id)
                
                # Atualizar localização
                if "location" in fhir_encounter:
                    for location in fhir_encounter["location"]:
                        if "status" in location:
                            location["status"] = "completed"
                else:
                    fhir_encounter["location"] = []
                
                # Adicionar nova localização
                fhir_encounter["location"].append({
                    "status": "active",
                    "location": {
                        "reference": f"Location/{new_location_id}"
                    }
                })
                
                # Atualizar encontro FHIR
                self.fhir_client.update_resource(fhir_encounter)
            except Exception as e:
                print(f"Erro ao atualizar encontro FHIR: {e}")
                return False
        
        return True
    
    def discharge_patient(self, encounter_id: str, discharge_notes: Optional[str] = None) -> bool:
        """
        Dá alta a um paciente.
        
        Args:
            encounter_id (str): ID do encontro.
            discharge_notes (Optional[str]): Notas de alta.
            
        Returns:
            bool: True se a alta foi bem-sucedida, False caso contrário.
            
        Raises:
            ValueError: Se o encontro não existir ou não estiver ativo.
        """
        # Verificar se o encontro existe
        if encounter_id not in self.encounters:
            raise ValueError(f"Encontro com ID {encounter_id} não encontrado.")
        
        # Obter encontro
        encounter = self.encounters[encounter_id]
        
        # Verificar se o encontro está ativo
        if encounter.status != "in-progress":
            raise ValueError(f"Encontro com ID {encounter_id} não está ativo.")
        
        # Atualizar registros
        encounter.status = "finished"
        encounter.end_time = datetime.datetime.now().isoformat()
        
        # Liberar localização
        if encounter.location_id:
            self.locations[encounter.location_id].current_occupancy -= 1
        
        # Remover encontro da lista de encontros ativos do paciente
        patient = self.patients[encounter.patient_id]
        if encounter_id in patient.active_encounters:
            patient.active_encounters.remove(encounter_id)
        
        # Integração FHIR, se disponível
        if self.fhir_client:
            try:
                # Obter encontro FHIR atual
                fhir_encounter = self.fhir_client.read_resource("Encounter", encounter_id)
                
                # Atualizar status e período
                fhir_encounter["status"] = "finished"
                if "period" in fhir_encounter:
                    fhir_encounter["period"]["end"] = encounter.end_time
                else:
                    fhir_encounter["period"] = {
                        "start": encounter.start_time,
                        "end": encounter.end_time
                    }
                
                # Adicionar notas de alta, se fornecidas
                if discharge_notes:
                    if "note" not in fhir_encounter:
                        fhir_encounter["note"] = []
                    
                    fhir_encounter["note"].append({
                        "text": discharge_notes,
                        "time": encounter.end_time,
                        "authorString": "System"
                    })
                
                # Atualizar encontro FHIR
                self.fhir_client.update_resource(fhir_encounter)
            except Exception as e:
                print(f"Erro ao atualizar encontro FHIR: {e}")
                return False
        
        return True
    
    def schedule_appointment(self, patient_id: str, practitioner_id: str, 
                            appointment_time: str, reason: str, duration_minutes: int = 30) -> str:
        """
        Agenda uma consulta ambulatorial.
        
        Args:
            patient_id (str): ID do paciente.
            practitioner_id (str): ID do médico.
            appointment_time (str): Data e hora da consulta (formato ISO).
            reason (str): Motivo da consulta.
            duration_minutes (int): Duração da consulta em minutos.
            
        Returns:
            str: ID do encontro criado.
            
        Raises:
            ValueError: Se o paciente não existir.
        """
        # Verificar se o paciente existe
        if patient_id not in self.patients:
            raise ValueError(f"Paciente com ID {patient_id} não encontrado.")
        
        # Criar encontro
        encounter_id = str(uuid.uuid4())
        
        # Calcular fim da consulta
        start_datetime = datetime.datetime.fromisoformat(appointment_time)
        end_datetime = start_datetime + datetime.timedelta(minutes=duration_minutes)
        end_time = end_datetime.isoformat()
        
        encounter = Encounter(
            id=encounter_id,
            patient_id=patient_id,
            status="planned",
            class_code="ambulatory",
            start_time=appointment_time,
            end_time=end_time,
            practitioner_id=practitioner_id,
            reason=reason
        )
        
        # Atualizar registros
        self.encounters[encounter_id] = encounter
        
        # Integração FHIR, se disponível
        if self.fhir_client:
            fhir_encounter = FHIREncounter()
            fhir_encounter.status = "planned"
            fhir_encounter.set_class("AMB", "http://terminology.hl7.org/CodeSystem/v3-ActCode", "ambulatory")
            fhir_encounter.set_subject(f"Patient/{patient_id}")
            fhir_encounter.set_period(start=appointment_time, end=end_time)
            
            if practitioner_id:
                fhir_encounter.add_participant(f"Practitioner/{practitioner_id}")
            
            try:
                result = self.fhir_client.create_resource(fhir_encounter)
                # Atualizar ID do encontro com o ID FHIR
                if "id" in result:
                    encounter.id = result["id"]
                    self.encounters[result["id"]] = encounter
                    del self.encounters[encounter_id]
                    encounter_id = result["id"]
            except Exception as e:
                print(f"Erro ao criar encontro FHIR: {e}")
        
        return encounter_id
    
    def start_appointment(self, encounter_id: str, location_id: Optional[str] = None) -> bool:
        """
        Inicia uma consulta agendada.
        
        Args:
            encounter_id (str): ID do encontro.
            location_id (Optional[str]): ID da localização da consulta.
            
        Returns:
            bool: True se o início da consulta foi bem-sucedido, False caso contrário.
            
        Raises:
            ValueError: Se o encontro não existir ou não estiver planejado.
        """
        # Verificar se o encontro existe
        if encounter_id not in self.encounters:
            raise ValueError(f"Encontro com ID {encounter_id} não encontrado.")
        
        # Obter encontro
        encounter = self.encounters[encounter_id]
        
        # Verificar se o encontro está planejado
        if encounter.status != "planned":
            raise ValueError(f"Encontro com ID {encounter_id} não está planejado.")
        
        # Atualizar registros
        encounter.status = "in-progress"
        encounter.start_time = datetime.datetime.now().isoformat()
        
        if location_id:
            # Verificar se a localização existe
            if location_id not in self.locations:
                raise ValueError(f"Localização com ID {location_id} não encontrada.")
            
            encounter.location_id = location_id
        
        # Adicionar encontro à lista de encontros ativos do paciente
        patient = self.patients[encounter.patient_id]
        patient.active_encounters.append(encounter_id)
        
        # Integração FHIR, se disponível
        if self.fhir_client:
            try:
                # Obter encontro FHIR atual
                fhir_encounter = self.fhir_client.read_resource("Encounter", encounter_id)
                
                # Atualizar status e período
                fhir_encounter["status"] = "in-progress"
                if "period" in fhir_encounter:
                    fhir_encounter["period"]["start"] = encounter.start_time
                else:
                    fhir_encounter["period"] = {"start": encounter.start_time}
                
                # Adicionar localização, se fornecida
                if location_id:
                    if "location" not in fhir_encounter:
                        fhir_encounter["location"] = []
                    
                    fhir_encounter["location"].append({
                        "status": "active",
                        "location": {
                            "reference": f"Location/{location_id}"
                        }
                    })
                
                # Atualizar encontro FHIR
                self.fhir_client.update_resource(fhir_encounter)
            except Exception as e:
                print(f"Erro ao atualizar encontro FHIR: {e}")
                return False
        
        return True
    
    def end_appointment(self, encounter_id: str, notes: Optional[str] = None) -> bool:
        """
        Finaliza uma consulta.
        
        Args:
            encounter_id (str): ID do encontro.
            notes (Optional[str]): Notas da consulta.
            
        Returns:
            bool: True se o fim da consulta foi bem-sucedido, False caso contrário.
            
        Raises:
            ValueError: Se o encontro não existir ou não estiver em andamento.
        """
        # Verificar se o encontro existe
        if encounter_id not in self.encounters:
            raise ValueError(f"Encontro com ID {encounter_id} não encontrado.")
        
        # Obter encontro
        encounter = self.encounters[encounter_id]
        
        # Verificar se o encontro está em andamento
        if encounter.status != "in-progress":
            raise ValueError(f"Encontro com ID {encounter_id} não está em andamento.")
        
        # Atualizar registros
        encounter.status = "finished"
        encounter.end_time = datetime.datetime.now().isoformat()
        
        # Remover encontro da lista de encontros ativos do paciente
        patient = self.patients[encounter.patient_id]
        if encounter_id in patient.active_encounters:
            patient.active_encounters.remove(encounter_id)
        
        # Integração FHIR, se disponível
        if self.fhir_client:
            try:
                # Obter encontro FHIR atual
                fhir_encounter = self.fhir_client.read_resource("Encounter", encounter_id)
                
                # Atualizar status e período
                fhir_encounter["status"] = "finished"
                if "period" in fhir_encounter:
                    fhir_encounter["period"]["end"] = encounter.end_time
                else:
                    fhir_encounter["period"] = {
                        "start": encounter.start_time,
                        "end": encounter.end_time
                    }
                
                # Adicionar notas, se fornecidas
                if notes:
                    if "note" not in fhir_encounter:
                        fhir_encounter["note"] = []
                    
                    fhir_encounter["note"].append({
                        "text": notes,
                        "time": encounter.end_time,
                        "authorString": "System"
                    })
                
                # Atualizar encontro FHIR
                self.fhir_client.update_resource(fhir_encounter)
            except Exception as e:
                print(f"Erro ao atualizar encontro FHIR: {e}")
                return False
        
        return True
    
    def add_patient(self, patient: Patient) -> None:
        """
        Adiciona um paciente ao sistema.
        
        Args:
            patient (Patient): O paciente a ser adicionado.
        """
        self.patients[patient.id] = patient
    
    def add_location(self, location: Location) -> None:
        """
        Adiciona uma localização ao sistema.
        
        Args:
            location (Location): A localização a ser adicionada.
        """
        self.locations[location.id] = location
    
    def get_patient(self, patient_id: str) -> Optional[Patient]:
        """
        Obtém um paciente pelo ID.
        
        Args:
            patient_id (str): ID do paciente.
            
        Returns:
            Optional[Patient]: O paciente, se encontrado.
        """
        return self.patients.get(patient_id)
    
    def get_location(self, location_id: str) -> Optional[Location]:
        """
        Obtém uma localização pelo ID.
        
        Args:
            location_id (str): ID da localização.
            
        Returns:
            Optional[Location]: A localização, se encontrada.
        """
        return self.locations.get(location_id)
    
    def get_encounter(self, encounter_id: str) -> Optional[Encounter]:
        """
        Obtém um encontro pelo ID.
        
        Args:
            encounter_id (str): ID do encontro.
            
        Returns:
            Optional[Encounter]: O encontro, se encontrado.
        """
        return self.encounters.get(encounter_id)
    
    def get_patient_encounters(self, patient_id: str, active_only: bool = False) -> List[Encounter]:
        """
        Obtém os encontros de um paciente.
        
        Args:
            patient_id (str): ID do paciente.
            active_only (bool): Se True, retorna apenas encontros ativos.
            
        Returns:
            List[Encounter]: Lista de encontros do paciente.
        """
        if patient_id not in self.patients:
            return []
        
        if active_only:
            return [self.encounters[e_id] for e_id in self.patients[patient_id].active_encounters 
                   if e_id in self.encounters]
        
        return [e for e in self.encounters.values() if e.patient_id == patient_id]
    
    def get_location_patients(self, location_id: str) -> List[Patient]:
        """
        Obtém os pacientes em uma localização.
        
        Args:
            location_id (str): ID da localização.
            
        Returns:
            List[Patient]: Lista de pacientes na localização.
        """
        if location_id not in self.locations:
            return []
        
        patient_ids = set()
        for encounter in self.encounters.values():
            if encounter.location_id == location_id and encounter.status == "in-progress":
                patient_ids.add(encounter.patient_id)
        
        return [self.patients[p_id] for p_id in patient_ids if p_id in self.patients]
    
    def save_to_file(self, filename: str) -> None:
        """
        Salva o estado atual do sistema em um arquivo JSON.
        
        Args:
            filename (str): Nome do arquivo.
        """
        data = {
            "patients": {p_id: p.to_dict() for p_id, p in self.patients.items()},
            "locations": {l_id: l.to_dict() for l_id, l in self.locations.items()},
            "encounters": {e_id: e.to_dict() for e_id, e in self.encounters.items()}
        }
        
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)
    
    def load_from_file(self, filename: str) -> None:
        """
        Carrega o estado do sistema de um arquivo JSON.
        
        Args:
            filename (str): Nome do arquivo.
        """
        with open(filename, 'r') as f:
            data = json.load(f)
        
        self.patients = {p_id: Patient.from_dict(p) for p_id, p in data.get("patients", {}).items()}
        self.locations = {l_id: Location.from_dict(l) for l_id, l in data.get("locations", {}).items()}
        self.encounters = {e_id: Encounter.from_dict(e) for e_id, e in data.get("encounters", {}).items()}


# Exemplo de uso
if __name__ == "__main__":
    # Criar gerenciador de workflows
    workflow = HospitalWorkflow()
    
    # Adicionar pacientes
    patient1 = Patient(
        id="P001",
        name="João Silva",
        birth_date="1980-05-15",
        gender="male",
        medical_record_number="MRN12345"
    )
    
    patient2 = Patient(
        id="P002",
        name="Maria Oliveira",
        birth_date="1975-10-20",
        gender="female",
        medical_record_number="MRN67890"
    )
    
    workflow.add_patient(patient1)
    workflow.add_patient(patient2)
    
    # Adicionar localizações
    ward = Location(
        id="L001",
        name="Ala A",
        type="ward",
        capacity=10
    )
    
    room1 = Location(
        id="L002",
        name="Quarto 101",
        type="room",
        parent_location="L001",
        capacity=2
    )
    
    room2 = Location(
        id="L003",
        name="Quarto 102",
        type="room",
        parent_location="L001",
        capacity=2
    )
    
    workflow.add_location(ward)
    workflow.add_location(room1)
    workflow.add_location(room2)
    
    # Internar paciente
    try:
        encounter_id = workflow.admit_patient(
            patient_id="P001",
            location_id="L002",
            reason="Pneumonia",
            practitioner_id="DR001"
        )
        
        print(f"Paciente internado com sucesso. ID do encontro: {encounter_id}")
        
        # Transferir paciente
        workflow.transfer_patient(
            encounter_id=encounter_id,
            new_location_id="L003",
            reason="Necessidade de monitoramento mais próximo"
        )
        
        print(f"Paciente transferido com sucesso para o quarto 102.")
        
        # Dar alta ao paciente
        workflow.discharge_patient(
            encounter_id=encounter_id,
            discharge_notes="Paciente recuperado. Recomendado repouso por 7 dias."
        )
        
        print(f"Paciente recebeu alta com sucesso.")
        
        # Agendar consulta ambulatorial
        appointment_id = workflow.schedule_appointment(
            patient_id="P002",
            practitioner_id="DR002",
            appointment_time="2023-05-20T10:00:00",
            reason="Consulta de rotina",
            duration_minutes=30
        )
        
        print(f"Consulta agendada com sucesso. ID do encontro: {appointment_id}")
        
    except ValueError as e:
        print(f"Erro: {e}")
