#!/usr/bin/env python3
"""
REPL (Read-Eval-Print Loop) para a Linguagem Charcot

Este módulo implementa um ambiente interativo para a linguagem Charcot,
permitindo que os usuários escrevam e executem código Charcot de forma interativa.
"""

import os
import sys
import cmd
import readline
import rlcompleter
import traceback
import re
import json
import importlib.util
from typing import Dict, List, Any, Optional, Tuple
import colorama
from colorama import Fore, Back, Style

# Importar componentes da linguagem Charcot
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.lexer import Lexer
from src.parser import Parser
from src.interpreter import Interpreter
from src.type_checker import TypeChecker

# Inicializar colorama para formatação de texto colorido
colorama.init()


class CharcotREPL(cmd.Cmd):
    """
    Implementação do REPL para a linguagem Charcot.
    """
    
    intro = f"""
{Fore.GREEN}╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║   {Fore.YELLOW}Charcot{Fore.GREEN} - Linguagem de Programação para Aplicações Médicas   ║
║                                                                   ║
║   Digite {Fore.CYAN}help{Fore.GREEN} para ver a lista de comandos disponíveis.           ║
║   Digite {Fore.CYAN}examples{Fore.GREEN} para ver exemplos de código.                    ║
║   Digite {Fore.CYAN}exit{Fore.GREEN} para sair.                                          ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝{Style.RESET_ALL}
"""
    prompt = f"{Fore.BLUE}charcot> {Style.RESET_ALL}"
    
    def __init__(self):
        """Inicializa o REPL."""
        super().__init__()
        self.lexer = Lexer()
        self.parser = Parser()
        self.type_checker = TypeChecker()
        self.interpreter = Interpreter()
        
        # Histórico de comandos
        self.history = []
        
        # Variáveis definidas na sessão atual
        self.variables = {}
        
        # Configurar histórico de comandos
        histfile = os.path.expanduser('~/.charcot_history')
        try:
            readline.read_history_file(histfile)
        except FileNotFoundError:
            pass
        
        # Configurar autocompletar
        if 'libedit' in readline.__doc__:
            readline.parse_and_bind("bind ^I rl_complete")
        else:
            readline.parse_and_bind("tab: complete")
        
        # Carregar exemplos
        self.examples = self._load_examples()
    
    def _load_examples(self) -> Dict[str, str]:
        """
        Carrega exemplos de código Charcot.
        
        Returns:
            Dict[str, str]: Dicionário de exemplos.
        """
        examples = {
            "hello": 'print("Olá, mundo da medicina!")',
            
            "patient": """
# Definir um paciente
patient Patient1 {
    name: "João Silva",
    birth_date: "1980-05-15",
    gender: "male",
    weight: 70.5,
    height: 175
}

# Calcular IMC
bmi = Patient1.weight / ((Patient1.height / 100) ** 2)
print(f"IMC do paciente: {bmi:.1f}")
""",
            
            "medication": """
# Definir um medicamento
medication Paracetamol {
    active_ingredient: "Acetaminophen",
    strength: "500 mg",
    form: "tablet",
    route: "oral",
    max_daily_dose: "4000 mg"
}

# Verificar dose
dose = 2 * 500  # 2 comprimidos de 500mg
frequency = 4   # 4 vezes ao dia
daily_dose = dose * frequency

if daily_dose > 4000:
    print("ALERTA: Dose diária excede o máximo recomendado!")
else:
    print(f"Dose diária: {daily_dose} mg (dentro do limite seguro)")
""",
            
            "prescription": """
# Criar uma prescrição
prescription new_rx {
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    frequency: "every 6 hours",
    duration: 5,  # dias
    instructions: "Take with water for pain relief"
}

# Verificar segurança
safety_check(new_rx)

# Emitir prescrição
if new_rx.is_safe:
    issue(new_rx)
    print("Prescrição emitida com sucesso")
else:
    print(f"Prescrição não emitida: {new_rx.safety_notes}")
""",
            
            "workflow": """
# Internar paciente
encounter = admit_patient(
    patient: Patient1,
    location: "Room 101",
    reason: "Pneumonia",
    attending: "Dr. Smith"
)

# Administrar medicação
administer_medication(
    patient: Patient1,
    medication: Paracetamol,
    dose: "500 mg",
    route: "oral",
    time: now()
)

# Dar alta ao paciente
discharge_patient(
    encounter: encounter,
    notes: "Patient recovered well. Follow up in 1 week."
)
"""
        }
        
        return examples
    
    def emptyline(self):
        """Não faz nada quando uma linha vazia é inserida."""
        pass
    
    def default(self, line):
        """
        Processa linhas que não correspondem a comandos conhecidos como código Charcot.
        
        Args:
            line (str): A linha de código a ser processada.
        """
        # Adicionar ao histórico
        self.history.append(line)
        
        try:
            # Processar o código
            tokens = self.lexer.tokenize(line)
            ast = self.parser.parse(tokens)
            
            # Verificar tipos
            self.type_checker.check(ast, self.variables)
            
            # Executar o código
            result = self.interpreter.interpret(ast, self.variables)
            
            # Exibir resultado, se houver
            if result is not None:
                print(f"{Fore.GREEN}=> {result}{Style.RESET_ALL}")
        
        except Exception as e:
            print(f"{Fore.RED}Erro: {str(e)}{Style.RESET_ALL}")
            if hasattr(e, 'line') and hasattr(e, 'column'):
                print(f"{Fore.YELLOW}  em linha {e.line}, coluna {e.column}{Style.RESET_ALL}")
    
    def do_exit(self, arg):
        """Sai do REPL."""
        print(f"{Fore.GREEN}Até logo!{Style.RESET_ALL}")
        return True
    
    def do_quit(self, arg):
        """Sai do REPL."""
        return self.do_exit(arg)
    
    def do_help(self, arg):
        """
        Exibe ajuda sobre comandos disponíveis.
        
        Args:
            arg (str): O comando para o qual exibir ajuda.
        """
        if not arg:
            print(f"""
{Fore.CYAN}Comandos disponíveis:{Style.RESET_ALL}
  {Fore.YELLOW}help{Style.RESET_ALL}      - Exibe esta mensagem de ajuda
  {Fore.YELLOW}examples{Style.RESET_ALL}  - Lista exemplos de código disponíveis
  {Fore.YELLOW}example{Style.RESET_ALL}   - Carrega um exemplo específico (ex: example patient)
  {Fore.YELLOW}load{Style.RESET_ALL}      - Carrega um arquivo Charcot (ex: load arquivo.ch)
  {Fore.YELLOW}save{Style.RESET_ALL}      - Salva o histórico de comandos em um arquivo (ex: save arquivo.ch)
  {Fore.YELLOW}clear{Style.RESET_ALL}     - Limpa a tela
  {Fore.YELLOW}reset{Style.RESET_ALL}     - Reinicia o ambiente (limpa variáveis)
  {Fore.YELLOW}vars{Style.RESET_ALL}      - Lista as variáveis definidas
  {Fore.YELLOW}history{Style.RESET_ALL}   - Exibe o histórico de comandos
  {Fore.YELLOW}exit{Style.RESET_ALL}      - Sai do REPL

{Fore.CYAN}Tipos de dados específicos para medicina:{Style.RESET_ALL}
  {Fore.YELLOW}patient{Style.RESET_ALL}   - Define um paciente
  {Fore.YELLOW}medication{Style.RESET_ALL} - Define um medicamento
  {Fore.YELLOW}prescription{Style.RESET_ALL} - Define uma prescrição
  {Fore.YELLOW}encounter{Style.RESET_ALL} - Define um encontro clínico

{Fore.CYAN}Funções específicas para medicina:{Style.RESET_ALL}
  {Fore.YELLOW}admit_patient(){Style.RESET_ALL} - Interna um paciente
  {Fore.YELLOW}discharge_patient(){Style.RESET_ALL} - Dá alta a um paciente
  {Fore.YELLOW}transfer_patient(){Style.RESET_ALL} - Transfere um paciente
  {Fore.YELLOW}prescribe(){Style.RESET_ALL} - Cria uma prescrição
  {Fore.YELLOW}safety_check(){Style.RESET_ALL} - Verifica a segurança de uma prescrição
  {Fore.YELLOW}administer_medication(){Style.RESET_ALL} - Administra um medicamento

Digite {Fore.YELLOW}help <comando>{Style.RESET_ALL} para obter ajuda sobre um comando específico.
""")
        elif arg == "patient":
            print(f"""
{Fore.CYAN}Tipo de dado: patient{Style.RESET_ALL}

Define um paciente no sistema.

{Fore.YELLOW}Sintaxe:{Style.RESET_ALL}
  patient <nome> {{
      name: <string>,
      birth_date: <string>,
      gender: <string>,
      [weight: <float>],
      [height: <float>],
      [allergies: [<string>, ...]],
      [conditions: [<string>, ...]]
  }}

{Fore.YELLOW}Exemplo:{Style.RESET_ALL}
  patient Patient1 {{
      name: "João Silva",
      birth_date: "1980-05-15",
      gender: "male",
      weight: 70.5,
      height: 175,
      allergies: ["penicillin"],
      conditions: ["hypertension"]
  }}

{Fore.YELLOW}Métodos:{Style.RESET_ALL}
  <paciente>.calculate_bmi() - Calcula o IMC do paciente
  <paciente>.calculate_age() - Calcula a idade do paciente
""")
        elif arg == "medication":
            print(f"""
{Fore.CYAN}Tipo de dado: medication{Style.RESET_ALL}

Define um medicamento no sistema.

{Fore.YELLOW}Sintaxe:{Style.RESET_ALL}
  medication <nome> {{
      name: <string>,
      active_ingredient: <string>,
      strength: <string>,
      form: <string>,
      route: <string>,
      [atc_code: <string>],
      [max_daily_dose: <string>],
      [contraindications: [<string>, ...]],
      [interactions: {{<string>: <string>, ...}}]
  }}

{Fore.YELLOW}Exemplo:{Style.RESET_ALL}
  medication Paracetamol {{
      active_ingredient: "Acetaminophen",
      strength: "500 mg",
      form: "tablet",
      route: "oral",
      max_daily_dose: "4000 mg",
      contraindications: ["liver failure"]
  }}
""")
        elif arg == "prescription":
            print(f"""
{Fore.CYAN}Tipo de dado: prescription{Style.RESET_ALL}

Define uma prescrição médica.

{Fore.YELLOW}Sintaxe:{Style.RESET_ALL}
  prescription <nome> {{
      patient: <patient>,
      medication: <medication>,
      dose: <string>,
      frequency: <string>,
      [duration: <int>],
      [instructions: <string>],
      [refills: <int>]
  }}

{Fore.YELLOW}Exemplo:{Style.RESET_ALL}
  prescription new_rx {{
      patient: Patient1,
      medication: Paracetamol,
      dose: "500 mg",
      frequency: "every 6 hours",
      duration: 5,
      instructions: "Take with water for pain relief"
  }}

{Fore.YELLOW}Funções relacionadas:{Style.RESET_ALL}
  safety_check(<prescription>) - Verifica a segurança da prescrição
  issue(<prescription>) - Emite a prescrição
  cancel(<prescription>, <reason>) - Cancela a prescrição
""")
        elif arg == "admit_patient":
            print(f"""
{Fore.CYAN}Função: admit_patient(){Style.RESET_ALL}

Interna um paciente no hospital.

{Fore.YELLOW}Sintaxe:{Style.RESET_ALL}
  admit_patient(
      patient: <patient>,
      location: <string>,
      reason: <string>,
      [attending: <string>]
  )

{Fore.YELLOW}Retorno:{Style.RESET_ALL}
  Um objeto encounter representando a internação.

{Fore.YELLOW}Exemplo:{Style.RESET_ALL}
  encounter = admit_patient(
      patient: Patient1,
      location: "Room 101",
      reason: "Pneumonia",
      attending: "Dr. Smith"
  )
""")
        else:
            print(f"{Fore.YELLOW}Não há ajuda disponível para '{arg}'.{Style.RESET_ALL}")
    
    def do_examples(self, arg):
        """
        Lista exemplos de código disponíveis.
        
        Args:
            arg (str): Não utilizado.
        """
        print(f"\n{Fore.CYAN}Exemplos disponíveis:{Style.RESET_ALL}")
        for name in self.examples:
            print(f"  {Fore.YELLOW}{name}{Style.RESET_ALL}")
        print(f"\nPara carregar um exemplo, digite: {Fore.YELLOW}example <nome>{Style.RESET_ALL}")
    
    def do_example(self, arg):
        """
        Carrega um exemplo específico.
        
        Args:
            arg (str): O nome do exemplo a ser carregado.
        """
        if not arg:
            print(f"{Fore.RED}Erro: Especifique o nome do exemplo.{Style.RESET_ALL}")
            self.do_examples("")
            return
        
        if arg not in self.examples:
            print(f"{Fore.RED}Erro: Exemplo '{arg}' não encontrado.{Style.RESET_ALL}")
            self.do_examples("")
            return
        
        print(f"{Fore.CYAN}Exemplo '{arg}':{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}{self.examples[arg]}{Style.RESET_ALL}")
        
        # Perguntar se o usuário deseja executar o exemplo
        response = input(f"\n{Fore.GREEN}Deseja executar este exemplo? (s/n) {Style.RESET_ALL}")
        if response.lower() in ['s', 'sim', 'y', 'yes']:
            # Executar cada linha do exemplo
            for line in self.examples[arg].strip().split('\n'):
                if line.strip() and not line.strip().startswith('#'):
                    print(f"{Fore.BLUE}charcot> {Style.RESET_ALL}{line}")
                    self.default(line)
    
    def do_load(self, arg):
        """
        Carrega um arquivo Charcot.
        
        Args:
            arg (str): O caminho do arquivo a ser carregado.
        """
        if not arg:
            print(f"{Fore.RED}Erro: Especifique o caminho do arquivo.{Style.RESET_ALL}")
            return
        
        try:
            with open(arg, 'r') as f:
                content = f.read()
            
            print(f"{Fore.GREEN}Carregando arquivo: {arg}{Style.RESET_ALL}")
            
            # Executar cada linha do arquivo
            for line in content.split('\n'):
                if line.strip() and not line.strip().startswith('#'):
                    print(f"{Fore.BLUE}charcot> {Style.RESET_ALL}{line}")
                    self.default(line)
            
            print(f"{Fore.GREEN}Arquivo carregado com sucesso.{Style.RESET_ALL}")
        
        except FileNotFoundError:
            print(f"{Fore.RED}Erro: Arquivo '{arg}' não encontrado.{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Erro ao carregar arquivo: {str(e)}{Style.RESET_ALL}")
    
    def do_save(self, arg):
        """
        Salva o histórico de comandos em um arquivo.
        
        Args:
            arg (str): O caminho do arquivo para salvar.
        """
        if not arg:
            print(f"{Fore.RED}Erro: Especifique o caminho do arquivo.{Style.RESET_ALL}")
            return
        
        try:
            with open(arg, 'w') as f:
                for cmd in self.history:
                    f.write(cmd + '\n')
            
            print(f"{Fore.GREEN}Histórico salvo em: {arg}{Style.RESET_ALL}")
        
        except Exception as e:
            print(f"{Fore.RED}Erro ao salvar arquivo: {str(e)}{Style.RESET_ALL}")
    
    def do_clear(self, arg):
        """
        Limpa a tela.
        
        Args:
            arg (str): Não utilizado.
        """
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def do_reset(self, arg):
        """
        Reinicia o ambiente (limpa variáveis).
        
        Args:
            arg (str): Não utilizado.
        """
        self.variables = {}
        print(f"{Fore.GREEN}Ambiente reiniciado.{Style.RESET_ALL}")
    
    def do_vars(self, arg):
        """
        Lista as variáveis definidas.
        
        Args:
            arg (str): Não utilizado.
        """
        if not self.variables:
            print(f"{Fore.YELLOW}Nenhuma variável definida.{Style.RESET_ALL}")
            return
        
        print(f"\n{Fore.CYAN}Variáveis definidas:{Style.RESET_ALL}")
        for name, value in self.variables.items():
            # Determinar o tipo da variável
            if hasattr(value, '__class__'):
                type_name = value.__class__.__name__
            else:
                type_name = type(value).__name__
            
            # Formatar o valor para exibição
            if isinstance(value, (str, int, float, bool)):
                val_str = str(value)
            elif hasattr(value, '__dict__'):
                val_str = "{...}"  # Objeto complexo
            elif isinstance(value, (list, tuple)):
                val_str = f"[{len(value)} items]"
            elif isinstance(value, dict):
                val_str = f"{{{len(value)} keys}}"
            else:
                val_str = str(value)
            
            print(f"  {Fore.YELLOW}{name}{Style.RESET_ALL} ({Fore.CYAN}{type_name}{Style.RESET_ALL}): {val_str}")
    
    def do_history(self, arg):
        """
        Exibe o histórico de comandos.
        
        Args:
            arg (str): Não utilizado.
        """
        if not self.history:
            print(f"{Fore.YELLOW}Histórico vazio.{Style.RESET_ALL}")
            return
        
        print(f"\n{Fore.CYAN}Histórico de comandos:{Style.RESET_ALL}")
        for i, cmd in enumerate(self.history, 1):
            print(f"  {Fore.YELLOW}{i}{Style.RESET_ALL}: {cmd}")
    
    def do_shell(self, arg):
        """
        Executa um comando no shell do sistema.
        
        Args:
            arg (str): O comando a ser executado.
        """
        os.system(arg)
    
    def completenames(self, text, *ignored):
        """
        Implementa autocompletar para nomes de comandos.
        
        Args:
            text (str): O texto a ser completado.
            *ignored: Argumentos ignorados.
            
        Returns:
            List[str]: Lista de possíveis completamentos.
        """
        dotext = 'do_' + text
        return [a[3:] for a in self.get_names() if a.startswith(dotext)]
    
    def completedefault(self, text, line, begidx, endidx):
        """
        Implementa autocompletar para código Charcot.
        
        Args:
            text (str): O texto a ser completado.
            line (str): A linha completa.
            begidx (int): Índice de início do texto.
            endidx (int): Índice de fim do texto.
            
        Returns:
            List[str]: Lista de possíveis completamentos.
        """
        # Completar variáveis
        if text:
            return [v for v in self.variables if v.startswith(text)]
        else:
            return list(self.variables.keys())


def main():
    """Função principal para iniciar o REPL."""
    try:
        repl = CharcotREPL()
        repl.cmdloop()
    except KeyboardInterrupt:
        print(f"\n{Fore.GREEN}Até logo!{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.RED}Erro fatal: {str(e)}{Style.RESET_ALL}")
        traceback.print_exc()


if __name__ == "__main__":
    main()
