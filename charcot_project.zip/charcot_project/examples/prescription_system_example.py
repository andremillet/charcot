#!/usr/bin/env python3
"""
Exemplo de Sistema de Prescrição Médica usando a Linguagem Charcot

Este exemplo demonstra a implementação de um sistema completo de prescrição médica
usando a linguagem Charcot, incluindo verificações de segurança, interações medicamentosas
e gerenciamento do ciclo de vida das prescrições.
"""

import os
import sys
import json
import datetime
from typing import Dict, List, Any, Optional

# Adicionar diretório de implementação ao path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Importar módulos da linguagem Charcot
from implementation.src.fhir_integration import FHIRClient, FHIRPatient, FHIRMedication, FHIRMedicationRequest
from implementation.src.prescription_system import (
    PrescriptionSystem, Patient, Medication, Prescriber, 
    Prescription, DosageSchedule, Dose, VerificationError
)
from implementation.src.hospital_workflow import HospitalWorkflow, Location, Encounter
from implementation.src.security import SecurityManager, DataProtection


def create_test_data():
    """
    Cria dados de teste para o sistema de prescrição.
    
    Returns:
        tuple: (prescription_system, patients, medications, prescribers)
    """
    # Criar sistema de prescrição
    prescription_system = PrescriptionSystem()
    
    # Criar pacientes
    patients = {}
    
    patients["P001"] = Patient(
        id="P001",
        name="João Silva",
        birth_date="1980-05-15",
        gender="male",
        weight=70.5,
        height=175,
        allergies=["penicillin"],
        conditions=["hypertension"]
    )
    
    patients["P002"] = Patient(
        id="P002",
        name="Maria Oliveira",
        birth_date="1975-10-20",
        gender="female",
        weight=65.0,
        height=160,
        allergies=["sulfa"],
        conditions=["diabetes", "asthma"]
    )
    
    patients["P003"] = Patient(
        id="P003",
        name="Carlos Santos",
        birth_date="1990-03-10",
        gender="male",
        weight=80.0,
        height=180,
        allergies=[],
        conditions=["peptic ulcer"]
    )
    
    # Adicionar pacientes ao sistema
    for patient in patients.values():
        prescription_system.add_patient(patient)
    
    # Criar medicamentos
    medications = {}
    
    medications["M001"] = Medication(
        id="M001",
        name="Paracetamol",
        active_ingredient="Acetaminophen",
        strength="500 mg",
        form="tablet",
        route="oral",
        atc_code="N02BE01",
        max_daily_dose="4000 mg"
    )
    
    medications["M002"] = Medication(
        id="M002",
        name="Ibuprofeno",
        active_ingredient="Ibuprofen",
        strength="400 mg",
        form="tablet",
        route="oral",
        atc_code="M01AE01",
        contraindications=["peptic ulcer", "asthma"],
        max_daily_dose="2400 mg",
        interactions={"Warfarin": "Aumenta o risco de sangramento"}
    )
    
    medications["M003"] = Medication(
        id="M003",
        name="Amoxicilina",
        active_ingredient="Amoxicillin",
        strength="500 mg",
        form="capsule",
        route="oral",
        atc_code="J01CA04",
        contraindications=["penicillin allergy"],
        max_daily_dose="3000 mg"
    )
    
    medications["M004"] = Medication(
        id="M004",
        name="Morfina",
        active_ingredient="Morphine",
        strength="10 mg",
        form="tablet",
        route="oral",
        atc_code="N02AA01",
        max_daily_dose="60 mg",
        controlled_substance=True
    )
    
    # Adicionar medicamentos ao sistema
    for medication in medications.values():
        prescription_system.add_medication(medication)
    
    # Criar prescritores
    prescribers = {}
    
    prescribers["DR001"] = Prescriber(
        id="DR001",
        name="Dra. Ana Pereira",
        license_number="CRM12345",
        specialty="Clínica Médica",
        prescribing_rights=["controlled_substances"]
    )
    
    prescribers["DR002"] = Prescriber(
        id="DR002",
        name="Dr. Roberto Almeida",
        license_number="CRM67890",
        specialty="Cardiologia",
        prescribing_rights=[]
    )
    
    prescribers["NR001"] = Prescriber(
        id="NR001",
        name="Enf. Juliana Costa",
        license_number="COREN54321",
        specialty="Enfermagem",
        prescribing_rights=[]
    )
    
    # Adicionar prescritores ao sistema
    for prescriber in prescribers.values():
        prescription_system.add_prescriber(prescriber)
    
    return prescription_system, patients, medications, prescribers


def create_prescriptions(prescription_system, patients, medications, prescribers):
    """
    Cria prescrições de exemplo e demonstra verificações de segurança.
    
    Args:
        prescription_system (PrescriptionSystem): Sistema de prescrição
        patients (Dict[str, Patient]): Dicionário de pacientes
        medications (Dict[str, Medication]): Dicionário de medicamentos
        prescribers (Dict[str, Prescriber]): Dicionário de prescritores
        
    Returns:
        Dict[str, Prescription]: Dicionário de prescrições criadas
    """
    prescriptions = {}
    
    print("\n=== Criando Prescrições ===")
    
    # Prescrição 1: Paracetamol para João Silva (deve ser segura)
    try:
        dosage_schedule = DosageSchedule(
            dose=Dose(500, "mg"),
            frequency="every 6 hours",
            duration=5,
            as_needed=True,
            timing_description="after meals"
        )
        
        prescription_id = prescription_system.create_prescription(
            patient_id="P001",
            prescriber_id="DR001",
            medication_id="M001",
            dosage_schedule=dosage_schedule,
            instructions="Take with water for pain relief",
            duration=5,
            refills=0
        )
        
        prescription = prescription_system.get_prescription(prescription_id)
        prescriptions[prescription_id] = prescription
        
        print(f"Prescrição 1 criada com sucesso. ID: {prescription_id}")
        print(f"  Paciente: {patients['P001'].name}")
        print(f"  Medicamento: {medications['M001'].name} {medications['M001'].strength}")
        print(f"  Dose: {dosage_schedule.dose} {dosage_schedule.frequency}")
        print(f"  Status de verificação: {prescription.verification_status}")
        print(f"  Notas: {prescription.verification_notes}")
        
    except (ValueError, VerificationError) as e:
        print(f"Erro ao criar prescrição 1: {e}")
    
    # Prescrição 2: Amoxicilina para João Silva (deve falhar - alergia a penicilina)
    try:
        dosage_schedule = DosageSchedule(
            dose=Dose(500, "mg"),
            frequency="every 8 hours",
            duration=7
        )
        
        prescription_id = prescription_system.create_prescription(
            patient_id="P001",
            prescriber_id="DR001",
            medication_id="M003",  # Amoxicilina (paciente alérgico a penicilina)
            dosage_schedule=dosage_schedule,
            instructions="Take with food for infection",
            duration=7,
            refills=0
        )
        
        prescription = prescription_system.get_prescription(prescription_id)
        prescriptions[prescription_id] = prescription
        
        print(f"Prescrição 2 criada com sucesso. ID: {prescription_id}")
        
    except (ValueError, VerificationError) as e:
        print(f"Erro ao criar prescrição 2: {e}")
    
    # Prescrição 3: Ibuprofeno para Maria Oliveira (deve falhar - paciente tem asma)
    try:
        dosage_schedule = DosageSchedule(
            dose=Dose(400, "mg"),
            frequency="every 8 hours",
            duration=5
        )
        
        prescription_id = prescription_system.create_prescription(
            patient_id="P002",
            prescriber_id="DR001",
            medication_id="M002",  # Ibuprofeno (contraindicado para asma)
            dosage_schedule=dosage_schedule,
            instructions="Take with food for pain and inflammation",
            duration=5,
            refills=0
        )
        
        prescription = prescription_system.get_prescription(prescription_id)
        prescriptions[prescription_id] = prescription
        
        print(f"Prescrição 3 criada com sucesso. ID: {prescription_id}")
        
    except (ValueError, VerificationError) as e:
        print(f"Erro ao criar prescrição 3: {e}")
    
    # Prescrição 4: Ibuprofeno para Carlos Santos (deve falhar - paciente tem úlcera péptica)
    try:
        dosage_schedule = DosageSchedule(
            dose=Dose(400, "mg"),
            frequency="every 8 hours",
            duration=5
        )
        
        prescription_id = prescription_system.create_prescription(
            patient_id="P003",
            prescriber_id="DR001",
            medication_id="M002",  # Ibuprofeno (contraindicado para úlcera péptica)
            dosage_schedule=dosage_schedule,
            instructions="Take with food for pain and inflammation",
            duration=5,
            refills=0
        )
        
        prescription = prescription_system.get_prescription(prescription_id)
        prescriptions[prescription_id] = prescription
        
        print(f"Prescrição 4 criada com sucesso. ID: {prescription_id}")
        
    except (ValueError, VerificationError) as e:
        print(f"Erro ao criar prescrição 4: {e}")
    
    # Prescrição 5: Morfina para Carlos Santos por Dr. Roberto (deve falhar - sem direitos para substâncias controladas)
    try:
        dosage_schedule = DosageSchedule(
            dose=Dose(10, "mg"),
            frequency="every 12 hours",
            duration=3
        )
        
        prescription_id = prescription_system.create_prescription(
            patient_id="P003",
            prescriber_id="DR002",  # Dr. Roberto (sem direitos para substâncias controladas)
            medication_id="M004",  # Morfina (substância controlada)
            dosage_schedule=dosage_schedule,
            instructions="Take for severe pain",
            duration=3,
            refills=0
        )
        
        prescription = prescription_system.get_prescription(prescription_id)
        prescriptions[prescription_id] = prescription
        
        print(f"Prescrição 5 criada com sucesso. ID: {prescription_id}")
        
    except (ValueError, VerificationError) as e:
        print(f"Erro ao criar prescrição 5: {e}")
    
    # Prescrição 6: Morfina para Carlos Santos por Dra. Ana (deve ser segura)
    try:
        dosage_schedule = DosageSchedule(
            dose=Dose(10, "mg"),
            frequency="every 12 hours",
            duration=3
        )
        
        prescription_id = prescription_system.create_prescription(
            patient_id="P003",
            prescriber_id="DR001",  # Dra. Ana (com direitos para substâncias controladas)
            medication_id="M004",  # Morfina (substância controlada)
            dosage_schedule=dosage_schedule,
            instructions="Take for severe pain",
            duration=3,
            refills=0
        )
        
        prescription = prescription_system.get_prescription(prescription_id)
        prescriptions[prescription_id] = prescription
        
        print(f"Prescrição 6 criada com sucesso. ID: {prescription_id}")
        print(f"  Paciente: {patients['P003'].name}")
        print(f"  Medicamento: {medications['M004'].name} {medications['M004'].strength}")
        print(f"  Dose: {dosage_schedule.dose} {dosage_schedule.frequency}")
        print(f"  Status de verificação: {prescription.verification_status}")
        print(f"  Notas: {prescription.verification_notes}")
        
    except (ValueError, VerificationError) as e:
        print(f"Erro ao criar prescrição 6: {e}")
    
    return prescriptions


def manage_prescription_lifecycle(prescription_system, prescriptions):
    """
    Demonstra o gerenciamento do ciclo de vida das prescrições.
    
    Args:
        prescription_system (PrescriptionSystem): Sistema de prescrição
        prescriptions (Dict[str, Prescription]): Dicionário de prescrições
    """
    if not prescriptions:
        print("\n=== Nenhuma prescrição para gerenciar ===")
        return
    
    print("\n=== Gerenciando Ciclo de Vida das Prescrições ===")
    
    # Obter IDs das prescrições ativas
    active_prescriptions = [p_id for p_id, p in prescriptions.items() if p.status == "active"]
    
    if not active_prescriptions:
        print("Nenhuma prescrição ativa para gerenciar.")
        return
    
    # Selecionar a primeira prescrição ativa
    prescription_id = active_prescriptions[0]
    prescription = prescriptions[prescription_id]
    
    print(f"Gerenciando prescrição: {prescription_id}")
    print(f"  Status atual: {prescription.status}")
    
    # Cancelar prescrição
    if len(active_prescriptions) > 1:
        cancel_id = active_prescriptions[1]
        try:
            success = prescription_system.cancel_prescription(
                prescription_id=cancel_id,
                reason="Medicamento substituído por alternativa mais adequada"
            )
            
            if success:
                print(f"Prescrição {cancel_id} cancelada com sucesso.")
                # Atualizar prescrição no dicionário local
                prescriptions[cancel_id] = prescription_system.get_prescription(cancel_id)
            else:
                print(f"Falha ao cancelar prescrição {cancel_id}.")
        
        except ValueError as e:
            print(f"Erro ao cancelar prescrição: {e}")
    
    # Completar prescrição
    try:
        success = prescription_system.complete_prescription(prescription_id)
        
        if success:
            print(f"Prescrição {prescription_id} marcada como concluída.")
            # Atualizar prescrição no dicionário local
            prescriptions[prescription_id] = prescription_system.get_prescription(prescription_id)
        else:
            print(f"Falha ao completar prescrição {prescription_id}.")
    
    except ValueError as e:
        print(f"Erro ao completar prescrição: {e}")
    
    # Renovar prescrição
    try:
        new_prescription_id = prescription_system.renew_prescription(
            prescription_id=prescription_id,
            duration=10,  # Nova duração
            refills=1     # Permitir uma recarga
        )
        
        print(f"Prescrição renovada com sucesso. Novo ID: {new_prescription_id}")
        # Adicionar nova prescrição ao dicionário local
        prescriptions[new_prescription_id] = prescription_system.get_prescription(new_prescription_id)
    
    except (ValueError, VerificationError) as e:
        print(f"Erro ao renovar prescrição: {e}")
    
    # Exibir status final das prescrições
    print("\nStatus final das prescrições:")
    for p_id, p in prescriptions.items():
        print(f"  {p_id}: {p.status}")


def integrate_with_hospital_workflow(prescription_system, patients, medications, prescriptions):
    """
    Demonstra a integração do sistema de prescrição com workflows hospitalares.
    
    Args:
        prescription_system (PrescriptionSystem): Sistema de prescrição
        patients (Dict[str, Patient]): Dicionário de pacientes
        medications (Dict[str, Medication]): Dicionário de medicamentos
        prescriptions (Dict[str, Prescription]): Dicionário de prescrições
    """
    print("\n=== Integrando com Workflows Hospitalares ===")
    
    # Criar gerenciador de workflows
    workflow = HospitalWorkflow()
    
    # Adicionar pacientes ao workflow
    for patient in patients.values():
        workflow_patient = Patient(
            id=patient.id,
            name=patient.name,
            birth_date=patient.birth_date,
            gender=patient.gender,
            allergies=patient.allergies,
            conditions=patient.conditions
        )
        workflow.add_patient(workflow_patient)
    
    # Adicionar localizações
    ward = Location(
        id="L001",
        name="Ala A",
        type="ward",
        capacity=10
    )
    
    room1 = Location(
        id="L002",
        name="Quarto 101",
        type="room",
        parent_location="L001",
        capacity=2
    )
    
    room2 = Location(
        id="L003",
        name="Quarto 102",
        type="room",
        parent_location="L001",
        capacity=2
    )
    
    workflow.add_location(ward)
    workflow.add_location(room1)
    workflow.add_location(room2)
    
    # Internar paciente
    try:
        patient_id = "P001"  # João Silva
        
        print(f"Internando paciente {patients[patient_id].name}")
        
        encounter_id = workflow.admit_patient(
            patient_id=patient_id,
            location_id="L002",  # Quarto 101
            reason="Pneumonia",
            practitioner_id="DR001"  # Dra. Ana
        )
        
        print(f"Paciente internado com sucesso. ID do encontro: {encounter_id}")
        
        # Obter encontro
        encounter = workflow.get_encounter(encounter_id)
        
        # Verificar prescrições ativas do paciente
        active_prescriptions = prescription_system.get_patient_prescriptions(patient_id, active_only=True)
        
        if active_prescriptions:
            print(f"Paciente tem {len(active_prescriptions)} prescrições ativas:")
            for rx in active_prescriptions:
                medication = medications[rx.medication_id]
                print(f"  - {medication.name} {rx.dosage_schedule.dose} {rx.dosage_schedule.frequency}")
        else:
            print("Paciente não tem prescrições ativas.")
            
            # Criar nova prescrição para o paciente internado
            try:
                dosage_schedule = DosageSchedule(
                    dose=Dose(500, "mg"),
                    frequency="every 8 hours",
                    duration=7
                )
                
                prescription_id = prescription_system.create_prescription(
                    patient_id=patient_id,
                    prescriber_id="DR001",
                    medication_id="M001",  # Paracetamol
                    dosage_schedule=dosage_schedule,
                    instructions="Take with water for fever",
                    duration=7,
                    refills=0
                )
                
                print(f"Nova prescrição criada para o paciente internado. ID: {prescription_id}")
                
                # Adicionar à lista de prescrições
                prescriptions[prescription_id] = prescription_system.get_prescription(prescription_id)
            
            except (ValueError, VerificationError) as e:
                print(f"Erro ao criar prescrição para paciente internado: {e}")
        
        # Transferir paciente
        print("Transferindo paciente para outro quarto")
        
        workflow.transfer_patient(
            encounter_id=encounter_id,
            new_location_id="L003",  # Quarto 102
            reason="Necessidade de monitoramento mais próximo"
        )
        
        print(f"Paciente transferido com sucesso para o quarto 102.")
        
        # Dar alta ao paciente
        print("Dando alta ao paciente")
        
        workflow.discharge_patient(
            encounter_id=encounter_id,
            discharge_notes="Paciente recuperado. Recomendado repouso por 7 dias."
        )
        
        print(f"Paciente recebeu alta com sucesso.")
        
    except ValueError as e:
        print(f"Erro no workflow hospitalar: {e}")


def demonstrate_security_features(prescription_system, patients, medications, prescriptions):
    """
    Demonstra os recursos de segurança e privacidade.
    
    Args:
        prescription_system (PrescriptionSystem): Sistema de prescrição
        patients (Dict[str, Patient]): Dicionário de pacientes
        medications (Dict[str, Medication]): Dicionário de medicamentos
        prescriptions (Dict[str, Prescription]): Dicionário de prescrições
    """
    print("\n=== Demonstrando Recursos de Segurança e Privacidade ===")
    
    # Criar gerenciador de segurança
    security_manager = SecurityManager()
    
    # Registrar usuários
    try:
        admin_id = security_manager.register_user(
            username="admin",
            password="admin123",
            role="admin"
        )
        
        doctor_id = security_manager.register_user(
            username="dr.ana",
            password="doctor123",
            role="doctor"
        )
        
        patient_id = security_manager.register_user(
            username="joao.silva",
            password="patient123",
            role="patient"
        )
        
        print("Usuários registrados:")
        print(f"  Admin: {admin_id}")
        print(f"  Médico: {doctor_id}")
        print(f"  Paciente: {patient_id}")
        
        # Autenticar como médico
        if security_manager.authenticate("dr.ana", "doctor123"):
            print("Autenticação bem-sucedida como médico")
            
            # Verificar permissão
            if security_manager.check_permission("prescription:create"):
                print("Médico tem permissão para criar prescrições")
            else:
                print("Médico não tem permissão para criar prescrições")
            
            # Tentar acessar logs de auditoria (deve falhar)
            try:
                security_manager.require_permission("audit:read")
                print("Médico tem permissão para ler logs de auditoria")
            except Exception as e:
                print(f"Acesso negado: {e}")
            
            # Logout
            security_manager.logout()
        
        # Autenticar como admin
        if security_manager.authenticate("admin", "admin123"):
            print("Autenticação bem-sucedida como admin")
            
            # Verificar permissão
            if security_manager.check_permission("audit:read"):
                print("Admin tem permissão para ler logs de auditoria")
            else:
                print("Admin não tem permissão para ler logs de auditoria")
            
            # Criptografar dados sensíveis
            patient_data = patients["P001"].to_dict()
            encrypted_data = security_manager.encrypt_data(json.dumps(patient_data))
            print(f"Dados do paciente criptografados: {encrypted_data[:50]}...")
            
            # Descriptografar dados
            decrypted_data = security_manager.decrypt_data(encrypted_data)
            decrypted_patient = json.loads(decrypted_data)
            print(f"Dados descriptografados: {decrypted_patient['name']}")
            
            # Anonimizar dados de paciente
            anonymized = security_manager.anonymize_patient_data(patient_data)
            print("Dados anonimizados:")
            print(f"  ID original: {patient_data['id']} -> ID anonimizado: {anonymized['id']}")
            print(f"  Nome original: {patient_data['name']} -> Nome anonimizado: {anonymized.get('name', 'REMOVIDO')}")
            
            # Logout
            security_manager.logout()
    
    except Exception as e:
        print(f"Erro de segurança: {e}")
    
    # Demonstrar proteção de dados
    text_with_phi = f"""
    O paciente {patients['P001'].name}, nascido em {patients['P001'].birth_date}, 
    tem histórico de {', '.join(patients['P001'].conditions)}.
    Seu telefone é 555-123-4567 e seu e-mail é joao.silva@example.com.
    MRN: 12345, SSN: 123-45-6789.
    Reside em Rua das Flores, 123, São Paulo.
    """
    
    print("\nTexto com informações de saúde protegidas (PHI):")
    print(text_with_phi)
    
    # Detectar PHI
    phi_detected = DataProtection.detect_phi(text_with_phi)
    print("\nPHI detectada:")
    for phi in phi_detected:
        print(f"  {phi}")
    
    # Mascarar PHI
    masked_text = DataProtection.mask_phi(text_with_phi)
    print("\nTexto com PHI mascarada:")
    print(masked_text)


def integrate_with_fhir(prescription_system, patients, medications, prescriptions):
    """
    Demonstra a integração com FHIR.
    
    Args:
        prescription_system (PrescriptionSystem): Sistema de prescrição
        patients (Dict[str, Patient]): Dicionário de pacientes
        medications (Dict[str, Medication]): Dicionário de medicamentos
        prescriptions (Dict[str, Prescription]): Dicionário de prescrições
    """
    print("\n=== Demonstrando Integração FHIR ===")
    
    # Criar cliente FHIR
    fhir_client = FHIRClient("http://hapi.fhir.org/baseR4")
    
    # Converter paciente para FHIR
    patient = patients["P001"]
    
    fhir_patient = FHIRPatient(
        id=patient.id,
        active=True
    )
    
    fhir_patient.add_name(
        given=[patient.name.split()[0]],
        family=patient.name.split()[1] if len(patient.name.split()) > 1 else ""
    )
    
    fhir_patient.gender = patient.gender
    fhir_patient.birthDate = patient.birth_date
    
    # Converter medicamento para FHIR
    medication = medications["M001"]
    
    fhir_medication = FHIRMedication(
        id=medication.id
    )
    
    fhir_medication.set_code(
        coding=[
            {
                "system": "http://www.nlm.nih.gov/research/umls/rxnorm",
                "code": "161",
                "display": medication.name
            }
        ],
        text=f"{medication.name} {medication.strength}"
    )
    
    fhir_medication.set_form(
        coding=[
            {
                "system": "http://terminology.hl7.org/CodeSystem/v3-orderableDrugForm",
                "code": "TAB",
                "display": "Tablet"
            }
        ],
        text=medication.form
    )
    
    # Criar prescrição FHIR
    if prescriptions:
        prescription_id = next(iter(prescriptions))
        prescription = prescriptions[prescription_id]
        
        fhir_medication_request = FHIRMedicationRequest(
            id=prescription.id,
            status=prescription.status,
            intent="order"
        )
        
        fhir_medication_request.set_medication(
            reference=f"Medication/{prescription.medication_id}",
            display=medications[prescription.medication_id].name
        )
        
        fhir_medication_request.set_subject(
            reference=f"Patient/{prescription.patient_id}",
            display=patients[prescription.patient_id].name
        )
        
        fhir_medication_request.authoredOn = prescription.date_written
        
        fhir_medication_request.add_dosage_instruction(
            text=f"{prescription.instructions}. {prescription.dosage_schedule.frequency}",
            dose_quantity={
                "value": prescription.dosage_schedule.dose.value,
                "unit": prescription.dosage_schedule.dose.unit,
                "system": "http://unitsofmeasure.org",
                "code": prescription.dosage_schedule.dose.unit
            }
        )
        
        print("Recursos FHIR criados:")
        print(f"  Patient: {fhir_patient.to_json()[:100]}...")
        print(f"  Medication: {fhir_medication.to_json()[:100]}...")
        print(f"  MedicationRequest: {fhir_medication_request.to_json()[:100]}...")
        
        # Não enviar para o servidor FHIR neste exemplo
        print("\nNota: Os recursos FHIR foram criados localmente, mas não foram enviados para um servidor FHIR.")
    else:
        print("Nenhuma prescrição disponível para converter para FHIR.")


def main():
    """Função principal do exemplo."""
    print("=== Sistema de Prescrição Médica usando a Linguagem Charcot ===")
    
    # Criar dados de teste
    prescription_system, patients, medications, prescribers = create_test_data()
    
    # Criar prescrições
    prescriptions = create_prescriptions(prescription_system, patients, medications, prescribers)
    
    # Gerenciar ciclo de vida das prescrições
    manage_prescription_lifecycle(prescription_system, prescriptions)
    
    # Integrar com workflows hospitalares
    integrate_with_hospital_workflow(prescription_system, patients, medications, prescriptions)
    
    # Demonstrar recursos de segurança
    demonstrate_security_features(prescription_system, patients, medications, prescriptions)
    
    # Integrar com FHIR
    integrate_with_fhir(prescription_system, patients, medications, prescriptions)
    
    print("\n=== Exemplo Concluído ===")


if __name__ == "__main__":
    main()
